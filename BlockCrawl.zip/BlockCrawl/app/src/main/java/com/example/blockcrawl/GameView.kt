package com.example.blockcrawl

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private fun cc(v: Long): Int = v.toInt()

private fun withA(col: Int, a: Float): Int =
    (col and 0x00FFFFFF) or ((a.coerceIn(0f, 1f) * 255f).toInt() shl 24)

private fun deg(r: Float): Float = r * 57.29578f

class GameView(ctx: Context) : View(ctx) {

    private class Theme(val floorA: Int, val floorB: Int, val wallTop: Int, val wallFace: Int, val bg: Int)

    private class Btn {
        var cx = 0f
        var cy = 0f
        var r = 0f
        fun set(x: Float, y: Float, radius: Float) {
            cx = x
            cy = y
            r = radius
        }

        fun hit(x: Float, y: Float): Boolean = hypot(x - cx, y - cy) <= r * 1.2f
    }

    private val g = Game()
    private val density = resources.displayMetrics.density
    private var d = density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint().apply { isFilterBitmap = false }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }
    private val rf = RectF()
    private var last = System.nanoTime()
    private var running = true
    private var menuT = 0f

    private val white = cc(0xFFFFFFFF)
    private val grey = cc(0xFFB0BEC5)
    private val gold = cc(0xFFFFD54F)

    private val themes = arrayOf(
        Theme(cc(0xFF55664F), cc(0xFF4D5E48), cc(0xFF2B3329), cc(0xFF1D241C), cc(0xFF0B0E0B)),
        Theme(cc(0xFF6B4540), cc(0xFF633F3A), cc(0xFF3A1F1C), cc(0xFF271210), cc(0xFF0F0605)),
        Theme(cc(0xFF4A4468), cc(0xFF433E5F), cc(0xFF241F38), cc(0xFF17132A), cc(0xFF08060F))
    )

    private val bAtk = Btn()
    private val bRoll = Btn()
    private val bBow = Btn()
    private val bPot = Btn()
    private val bInv = Btn()

    private var joyPtr = -1
    private var atkPtr = -1
    private var joyBX = 0f
    private var joyBY = 0f
    private var joyX = 0f
    private var joyY = 0f

    private val invPanel = RectF()
    private val invClose = RectF()
    private val invBuy = RectF()
    private val invEquip = RectF()
    private val invSell = RectF()
    private val cards = Array(12) { RectF() }
    private var sel = -1

    private val miniBmp: Bitmap = Bitmap.createBitmap(Game.MW, Game.MH, Bitmap.Config.ARGB_8888)
    private val miniPix = IntArray(Game.MW * Game.MH)

    // ------------------------------------------------------------------ ciclo de vida

    fun pauseGame() {
        running = false
        releaseAll()
        if (g.state == State.PLAY) g.openInventory()
    }

    fun resumeGame() {
        last = System.nanoTime()
        running = true
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val wf = w.toFloat()
        val hf = h.toFloat()
        d = density * min(1f, h / (360f * density))

        bAtk.set(wf - 80 * d, hf - 80 * d, 44 * d)
        bRoll.set(wf - 165 * d, hf - 52 * d, 30 * d)
        bBow.set(wf - 150 * d, hf - 128 * d, 28 * d)
        bPot.set(wf - 68 * d, hf - 160 * d, 28 * d)
        bInv.set(wf - 34 * d, 34 * d, 22 * d)

        val m = 10 * d
        invPanel.set(m, m, wf - m, hf - m)
        val leftW = (wf - 2 * m) * 0.36f
        val bx = invPanel.left + 12 * d
        val bw = leftW - 12 * d
        val bh = 36 * d
        invClose.set(bx, invPanel.bottom - 12 * d - bh, bx + bw, invPanel.bottom - 12 * d)
        invBuy.set(bx, invClose.top - 8 * d - bh, bx + bw, invClose.top - 8 * d)
        val half = (bw - 8 * d) / 2f
        invEquip.set(bx, invBuy.top - 8 * d - bh, bx + half, invBuy.top - 8 * d)
        invSell.set(bx + half + 8 * d, invEquip.top, bx + bw, invEquip.bottom)

        val gx = invPanel.left + leftW + 12 * d
        val gy = invPanel.top + 44 * d
        val gw = invPanel.right - 12 * d - gx
        val gh = invPanel.bottom - 12 * d - gy
        val gap = 8 * d
        val cw = (gw - 2 * gap) / 3f
        val ch = (gh - 3 * gap) / 4f
        for (i in 0 until 12) {
            val col = i % 3
            val row = i / 3
            val l = gx + col * (cw + gap)
            val t = gy + row * (ch + gap)
            cards[i].set(l, t, l + cw, t + ch)
        }
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        var dt = (now - last) / 1_000_000_000f
        last = now
        if (dt > 0.05f) dt = 0.05f
        if (running) {
            g.update(dt)
            menuT += dt
        }
        render(c)
        postInvalidateOnAnimation()
    }

    // ------------------------------------------------------------------ entrada

    private fun releaseAll() {
        joyPtr = -1
        atkPtr = -1
        g.moveX = 0f
        g.moveY = 0f
        g.attackHeld = false
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = ev.actionIndex
                onDown(ev.getPointerId(i), ev.getX(i), ev.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until ev.pointerCount) onMove(ev.getPointerId(i), ev.getX(i), ev.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> onUp(ev.getPointerId(ev.actionIndex))
            MotionEvent.ACTION_CANCEL -> releaseAll()
        }
        return true
    }

    private fun onDown(id: Int, x: Float, y: Float) {
        when (g.state) {
            State.MENU -> {
                if (g.stateT > 0.4f) {
                    releaseAll()
                    g.startRun()
                }
            }
            State.DEAD, State.WIN -> {
                if (g.stateT > 0.8f) g.toMenu()
            }
            State.INV -> invTouch(x, y)
            State.PLAY -> playTouch(id, x, y)
        }
    }

    private fun playTouch(id: Int, x: Float, y: Float) {
        if (bInv.hit(x, y)) {
            releaseAll()
            sel = -1
            g.openInventory()
            return
        }
        if (bAtk.hit(x, y)) {
            atkPtr = id
            g.attackHeld = true
            return
        }
        if (bRoll.hit(x, y)) {
            g.doRoll()
            return
        }
        if (bBow.hit(x, y)) {
            g.shootBow()
            return
        }
        if (bPot.hit(x, y)) {
            g.usePotion()
            return
        }
        if (x < width * 0.5f && joyPtr == -1) {
            joyPtr = id
            joyBX = x
            joyBY = y
            joyX = x
            joyY = y
            g.moveX = 0f
            g.moveY = 0f
        }
    }

    private fun onMove(id: Int, x: Float, y: Float) {
        if (id == joyPtr && g.state == State.PLAY) {
            val dx = x - joyBX
            val dy = y - joyBY
            val len = hypot(dx, dy)
            val r = 48 * d
            val k = if (len > r) r / len else 1f
            joyX = joyBX + dx * k
            joyY = joyBY + dy * k
            g.moveX = dx * k / r
            g.moveY = dy * k / r
        }
    }

    private fun onUp(id: Int) {
        if (id == -1) return
        if (id == joyPtr) {
            joyPtr = -1
            g.moveX = 0f
            g.moveY = 0f
        }
        if (id == atkPtr) {
            atkPtr = -1
            g.attackHeld = false
        }
    }

    private fun invTouch(x: Float, y: Float) {
        val bag = g.player.bag
        val valid = sel >= 0 && sel < bag.size
        if (invClose.contains(x, y)) {
            g.closeInventory()
            return
        }
        if (invBuy.contains(x, y)) {
            g.buyPotion()
            return
        }
        if (invEquip.contains(x, y) && valid) {
            g.equip(sel)
            sel = -1
            return
        }
        if (invSell.contains(x, y) && valid) {
            g.sell(sel)
            sel = -1
            return
        }
        for (i in cards.indices) {
            if (cards[i].contains(x, y)) {
                sel = if (i < bag.size) i else -1
                return
            }
        }
    }

    // ------------------------------------------------------------------ helpers de desenho

    private fun fr(c: Canvas, l: Float, t: Float, r: Float, b: Float, col: Int) {
        paint.style = Paint.Style.FILL
        paint.color = col
        c.drawRect(l, t, r, b, paint)
    }

    private fun sr(c: Canvas, l: Float, t: Float, r: Float, b: Float, col: Int, w: Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = w
        paint.color = col
        c.drawRect(l, t, r, b, paint)
    }

    private fun oval(c: Canvas, cx: Float, cy: Float, rx: Float, ry: Float, col: Int) {
        paint.style = Paint.Style.FILL
        paint.color = col
        rf.set(cx - rx, cy - ry, cx + rx, cy + ry)
        c.drawOval(rf, paint)
    }

    private fun circle(c: Canvas, cx: Float, cy: Float, r: Float, col: Int, stroke: Float = 0f) {
        if (stroke > 0f) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = stroke
        } else {
            paint.style = Paint.Style.FILL
        }
        paint.color = col
        c.drawCircle(cx, cy, r, paint)
    }

    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, col: Int, w: Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = w
        paint.color = col
        c.drawLine(x1, y1, x2, y2, paint)
    }

    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, col: Int, align: Paint.Align = Paint.Align.LEFT) {
        tp.textSize = size
        tp.color = col
        tp.textAlign = align
        c.drawText(s, x, y, tp)
    }

    private fun idx(x: Float, y: Float): Int {
        val tx = floor(x / Game.T).toInt()
        val ty = floor(y / Game.T).toInt()
        if (tx < 0 || ty < 0 || tx >= Game.MW || ty >= Game.MH) return 0
        return ty * Game.MW + tx
    }

    private fun nearFloor(tx: Int, ty: Int): Boolean {
        for (dy in -1..1) {
            for (dx in -1..1) {
                val x = tx + dx
                val y = ty + dy
                if (x < 0 || y < 0 || x >= Game.MW || y >= Game.MH) continue
                if (g.map[y * Game.MW + x] != 0) return true
            }
        }
        return false
    }

    // ------------------------------------------------------------------ render principal

    private fun render(c: Canvas) {
        val w = width
        val h = height
        c.drawColor(cc(0xFF000000))
        if (g.state == State.MENU) {
            drawMenu(c, w, h)
            return
        }
        drawWorld(c, w, h)
        drawHud(c, w, h)
        when (g.state) {
            State.INV -> drawInventory(c, w, h)
            State.DEAD -> drawEnd(c, w, h, false)
            State.WIN -> drawEnd(c, w, h, true)
            else -> {}
        }
    }

    private fun drawMenu(c: Canvas, w: Int, h: Int) {
        val wf = w.toFloat()
        val hf = h.toFloat()
        c.drawColor(cc(0xFF0B0E0B))
        val bs = 28 * d
        var ty = 0
        var y = 0f
        while (y < hf) {
            var tx = 0
            var x = 0f
            while (x < wf) {
                if ((tx * 7 + ty * 13) % 5 == 0) {
                    fr(c, x, y, x + bs, y + bs, if ((tx + ty) % 2 == 0) cc(0xFF121A12) else cc(0xFF0F150F))
                }
                x += bs
                tx++
            }
            y += bs
            ty++
        }
        val cx = wf / 2f
        txt(c, "BLOCKCRAWL", cx + 4 * d, hf * 0.34f + 4 * d, 56 * d, cc(0xFF1B5E20), Paint.Align.CENTER)
        txt(c, "BLOCKCRAWL", cx, hf * 0.34f, 56 * d, cc(0xFF8BC34A), Paint.Align.CENTER)
        txt(c, "Masmorras de Blocos", cx, hf * 0.34f + 28 * d, 18 * d, grey, Paint.Align.CENTER)
        val pulse = 0.55f + 0.45f * sin(menuT * 3f)
        txt(c, "Toque para jogar", cx, hf * 0.62f, 24 * d, withA(white, pulse), Paint.Align.CENTER)
        txt(c, "Esquerda da tela: mover   |   Botão grande: atacar", cx, hf * 0.76f, 13 * d, grey, Paint.Align.CENTER)
        txt(c, "ROL: rolar (invencível)   ARC: arco   POC: poção   INV: mochila", cx, hf * 0.76f + 20 * d, 13 * d, grey, Paint.Align.CENTER)
        txt(c, "3 fases  -  derrote o Guardião de Obsidiana", cx, hf * 0.76f + 40 * d, 13 * d, grey, Paint.Align.CENTER)
    }

    // ------------------------------------------------------------------ mundo

    private fun drawWorld(c: Canvas, w: Int, h: Int) {
        val p = g.player
        val th = themes[(g.level - 1).coerceIn(0, 2)]
        val zoom = h / (Game.T * 9f)
        var cx = p.x
        var cy = p.y
        if (g.shake > 0f) {
            val m = min(1f, g.shake * 4f) * 4f
            cx += (g.rng.nextFloat() - 0.5f) * m
            cy += (g.rng.nextFloat() - 0.5f) * m
        }
        c.drawColor(th.bg)
        c.save()
        c.translate(w / 2f, h / 2f)
        c.scale(zoom, zoom)
        c.translate(-cx, -cy)

        val t = Game.T
        val halfW = w / 2f / zoom
        val halfH = h / 2f / zoom
        val x0 = max(0, floor((cx - halfW) / t).toInt() - 1)
        val x1 = min(Game.MW - 1, floor((cx + halfW) / t).toInt() + 1)
        val y0 = max(0, floor((cy - halfH) / t).toInt() - 1)
        val y1 = min(Game.MH - 1, floor((cy + halfH) / t).toInt() + 1)

        for (ty in y0..y1) {
            for (tx in x0..x1) {
                val i = ty * Game.MW + tx
                if (!g.seen[i]) continue
                val px = tx * t
                val py = ty * t
                if (g.map[i] != 0) {
                    fr(c, px, py, px + t, py + t, if (((tx + ty) and 1) == 0) th.floorA else th.floorB)
                    val hsh = ((tx * 73856093) xor (ty * 19349663)) and 0x7fffffff
                    if (hsh % 9 == 0) {
                        val ox = (6 + hsh % 11).toFloat()
                        val oy = (8 + hsh % 7).toFloat()
                        fr(c, px + ox, py + oy, px + ox + 6f, py + oy + 3f, cc(0x2E000000))
                    }
                } else {
                    if (!nearFloor(tx, ty)) continue
                    fr(c, px, py, px + t, py + t, th.wallTop)
                    if (ty + 1 < Game.MH && g.map[i + Game.MW] != 0) {
                        fr(c, px, py + t * 0.55f, px + t, py + t, th.wallFace)
                        fr(c, px, py + t * 0.55f, px + t, py + t * 0.55f + 2f, cc(0x14FFFFFF))
                    }
                    if (ty > 0 && g.map[i - Game.MW] != 0) {
                        fr(c, px, py, px + t, py + 2f, cc(0x1FFFFFFF))
                    }
                }
            }
        }

        for (ch in g.chests) {
            if (g.seen[idx(ch.x, ch.y)]) drawChest(c, ch)
        }
        for (pk in g.pickups) drawPickup(c, pk)
        if (g.exitOpen && g.seen[idx(g.exitX, g.exitY)]) drawPortal(c)
        for (e in g.enemies) {
            if (e.dead || !g.seen[idx(e.x, e.y)]) continue
            drawEnemy(c, e)
        }
        drawPlayer(c, p)
        for (pr in g.projs) {
            oval(c, pr.x, pr.y, pr.radius * 2f, pr.radius * 2f, withA(pr.color, 0.25f))
            fr(c, pr.x - pr.radius, pr.y - pr.radius, pr.x + pr.radius, pr.y + pr.radius, pr.color)
        }
        for (q in g.parts) {
            val a = (q.life / 0.5f).coerceIn(0f, 1f)
            fr(c, q.x - q.size / 2f, q.y - q.size / 2f, q.x + q.size / 2f, q.y + q.size / 2f, withA(q.color, a))
        }
        for (ft in g.texts) {
            val a = (ft.life / 0.4f).coerceIn(0f, 1f)
            txt(c, ft.text, ft.x + 1f, ft.y + 1f, 9f, withA(cc(0xFF000000), a), Paint.Align.CENTER)
            txt(c, ft.text, ft.x, ft.y, 9f, withA(ft.color, a), Paint.Align.CENTER)
        }
        c.restore()
    }

    private fun drawChest(c: Canvas, ch: Chest) {
        val x = ch.x
        val y = ch.y
        oval(c, x, y + 7f, 11f, 4f, cc(0x55000000))
        if (!ch.opened) {
            fr(c, x - 9f, y - 6f, x + 9f, y + 6f, cc(0xFF8D5524))
            fr(c, x - 9f, y - 6f, x + 9f, y - 1f, cc(0xFFA9703A))
            fr(c, x - 2f, y - 3f, x + 2f, y + 1f, cc(0xFFFFD54F))
        } else {
            fr(c, x - 9f, y - 2f, x + 9f, y + 6f, cc(0xFF5D3A18))
            fr(c, x - 9f, y - 10f, x + 9f, y - 5f, cc(0xFF7A4C1E))
            fr(c, x - 6f, y - 1f, x + 6f, y + 2f, cc(0xFF2B1A0B))
        }
    }

    private fun drawPickup(c: Canvas, pk: Pickup) {
        val x = pk.x
        val b = sin(pk.t * 5f + pk.x) * 1.5f
        oval(c, x, pk.y + 6f, 5f, 2f, cc(0x44000000))
        val y = pk.y + b
        when (pk.kind) {
            0 -> {
                fr(c, x - 3f, y - 3f, x + 3f, y + 3f, cc(0xFF3DDC84))
                fr(c, x - 1f, y - 2f, x + 1f, y, cc(0xFFB9F6CA))
            }
            1 -> {
                fr(c, x - 3f, y - 4f, x + 3f, y + 4f, cc(0xFFE53935))
                fr(c, x - 2f, y - 6f, x + 2f, y - 4f, cc(0xFFBDBDBD))
            }
            2 -> {
                line(c, x - 5f, y + 3f, x + 5f, y - 3f, cc(0xFF8D6E63), 1.5f)
                fr(c, x + 4f, y - 4f, x + 6f, y - 2f, cc(0xFFE0E0E0))
            }
            else -> {
                val col = pk.item?.rarity?.color ?: white
                fr(c, x - 3f, y - 28f, x + 3f, y, withA(col, 0.22f))
                fr(c, x - 5f, y - 5f, x + 5f, y + 5f, col)
                sr(c, x - 5f, y - 5f, x + 5f, y + 5f, white, 1f)
            }
        }
    }

    private fun drawPortal(c: Canvas) {
        val x = g.exitX
        val y = g.exitY
        val tt = g.time
        val pulse = 0.55f + 0.45f * sin(tt * 4f)
        oval(c, x, y + 14f, 16f, 5f, cc(0x55000000))
        fr(c, x - 14f, y - 20f, x + 14f, y + 14f, cc(0xFF1A1030))
        fr(c, x - 10f, y - 16f, x + 10f, y + 10f, withA(cc(0xFFB388FF), pulse))
        for (k in 0 until 4) {
            val a = tt * 2f + k * 1.5708f
            val px = x + cos(a) * 8f
            val py = y - 3f + sin(a) * 11f
            fr(c, px - 1.5f, py - 1.5f, px + 1.5f, py + 1.5f, white)
        }
    }

    private fun drawPlayer(c: Canvas, p: Player) {
        if (p.hurt > 0f && ((p.hurt * 40f).toInt() % 2 == 0)) return
        val x = p.x
        val y = p.y
        oval(c, x, y + 8f, 8f, 3.5f, cc(0x55000000))
        if (p.rolling > 0f) {
            c.save()
            c.translate(x, y)
            c.rotate(p.rolling * 1700f)
            fr(c, -7f, -7f, 7f, 7f, cc(0xFF3F6FBF))
            fr(c, -7f, -7f, 7f, -3f, cc(0xFFF1C27D))
            c.restore()
            return
        }
        val sw = if (p.moving) sin(g.time * 16f) * 2f else 0f
        fr(c, x - 5f, y + 5f, x - 1f, y + 10f + sw * 0.5f, cc(0xFF263238))
        fr(c, x + 1f, y + 5f, x + 5f, y + 10f - sw * 0.5f, cc(0xFF263238))
        fr(c, x - 6f, y - 6f, x + 6f, y + 6f, cc(0xFF3F6FBF))
        val ar = p.armor
        if (ar != null) {
            fr(c, x - 6f, y - 6f, x + 6f, y - 4f, ar.rarity.color)
            fr(c, x - 6f, y + 2f, x + 6f, y + 4f, ar.rarity.color)
        }
        fr(c, x - 5f, y - 15f, x + 5f, y - 6f, cc(0xFFF1C27D))
        fr(c, x - 5f, y - 15f, x + 5f, y - 12f, cc(0xFF5D4037))
        val fe = cos(p.facing) * 1.5f
        fr(c, x - 3f + fe, y - 10f, x - 1f + fe, y - 8f, cc(0xFF263238))
        fr(c, x + 1f + fe, y - 10f, x + 3f + fe, y - 8f, cc(0xFF263238))

        val wt = p.weapon.wtype
        val range = wt?.range ?: 30f
        val half = wt?.halfArc ?: 0.9f
        val wcol = p.weapon.rarity.color
        if (p.atkAnim > 0f) {
            val prog = 1f - p.atkAnim / 0.18f
            val a = p.facing + (prog - 0.5f) * 2f * half
            val len = range * 0.85f
            val sa = (p.atkAnim / 0.18f).coerceIn(0f, 1f)
            rf.set(x - range * 0.9f, y - 3f - range * 0.9f, x + range * 0.9f, y - 3f + range * 0.9f)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 4f
            paint.color = withA(white, sa * 0.55f)
            c.drawArc(rf, deg(p.facing - half), deg(2f * half), false, paint)
            line(c, x, y - 3f, x + cos(a) * len, y - 3f + sin(a) * len, wcol, 3f)
        } else {
            val a = p.facing + 0.6f
            line(c, x, y - 3f, x + cos(a) * 12f, y - 3f + sin(a) * 12f, wcol, 3f)
        }
    }

    private fun drawEnemy(c: Canvas, e: Enemy) {
        val x = e.x
        val y = e.y
        val fl = e.flash > 0f
        val r = e.type.radius
        oval(c, x, y + r * 0.9f, r * 1.1f, r * 0.45f, cc(0x55000000))
        when (e.type) {
            EType.MOSS -> {
                val bob = sin(e.anim * 8f)
                val body = if (fl) white else cc(0xFF4E7D3A)
                val armUp = if (e.st == 1) -6f else 0f
                fr(c, x - 6f, y + 6f, x - 2f, y + 10f + bob, cc(0xFF2E4A22))
                fr(c, x + 2f, y + 6f, x + 6f, y + 10f - bob, cc(0xFF2E4A22))
                fr(c, x - 8f, y - 10f, x + 8f, y + 6f, body)
                fr(c, x - 12f, y - 8f + armUp, x - 8f, y + 2f + armUp, body)
                fr(c, x + 8f, y - 8f + armUp, x + 12f, y + 2f + armUp, body)
                if (!fl) {
                    fr(c, x - 8f, y - 10f, x - 3f, y - 6f, cc(0xFF3B6B2A))
                    fr(c, x + 2f, y - 3f, x + 8f, y + 2f, cc(0xFF3B6B2A))
                }
                fr(c, x - 6f, y - 18f, x + 6f, y - 8f, if (fl) white else cc(0xFF5E8F45))
                fr(c, x - 4f, y - 15f, x - 2f, y - 13f, cc(0xFFFF5252))
                fr(c, x + 2f, y - 15f, x + 4f, y - 13f, cc(0xFFFF5252))
                if (e.st == 1) {
                    val a = 0.4f + 0.4f * (1f - e.stT / 0.45f)
                    circle(c, x, y, 30f, withA(cc(0xFFFF5252), a), 2f)
                }
            }
            EType.ARCHER -> {
                val body = if (fl) white else cc(0xFFD8D4C4)
                fr(c, x - 4f, y + 5f, x - 1f, y + 10f, body)
                fr(c, x + 1f, y + 5f, x + 4f, y + 10f, body)
                fr(c, x - 5f, y - 8f, x + 5f, y + 6f, body)
                if (!fl) {
                    fr(c, x - 5f, y - 3f, x + 5f, y - 2f, cc(0xFF9E9A8A))
                    fr(c, x - 5f, y + 1f, x + 5f, y + 2f, cc(0xFF9E9A8A))
                }
                fr(c, x - 5f, y - 16f, x + 5f, y - 8f, if (fl) white else cc(0xFFEFEBDC))
                fr(c, x - 3f, y - 13f, x - 1f, y - 11f, cc(0xFF263238))
                fr(c, x + 1f, y - 13f, x + 3f, y - 11f, cc(0xFF263238))
                val pl = g.player
                val a = atan2(pl.y - y, pl.x - x)
                rf.set(x + cos(a) * 9f - 8f, y - 3f + sin(a) * 9f - 8f, x + cos(a) * 9f + 8f, y - 3f + sin(a) * 9f + 8f)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2f
                paint.color = cc(0xFF8D6E63)
                c.drawArc(rf, deg(a) - 60f, 120f, false, paint)
                if (e.st == 1) {
                    line(c, x, y - 3f, x + cos(a) * 120f, y - 3f + sin(a) * 120f, cc(0x66FF5252), 1.5f)
                }
            }
            EType.GLOOP -> {
                val sx = 1f + 0.15f * sin(e.anim * 8f)
                val sy = 1f / sx
                val hop = abs(sin(e.anim * 6f)) * 4f
                val l = x - 8f * sx
                val rr = x + 8f * sx
                val bt = y + 6f - hop
                val top = bt - 14f * sy
                fr(c, l, top, rr, bt, if (fl) white else cc(0xFF3FBFA0))
                if (!fl) fr(c, l, top, rr, top + 3f, cc(0xFF7FFFD4))
                fr(c, x - 4f, top + 5f, x - 2f, top + 8f, cc(0xFF004D40))
                fr(c, x + 2f, top + 5f, x + 4f, top + 8f, cc(0xFF004D40))
            }
            EType.BOSS -> {
                val stunned = e.st == 3
                val body = if (fl) white else if (stunned) cc(0xFF6A5490) else cc(0xFF3A2A4F)
                val bob = if (e.st == 0) sin(e.anim * 6f) * 1.5f else 0f
                fr(c, x - 14f, y + 12f, x - 6f, y + 20f + bob, cc(0xFF2B1D3D))
                fr(c, x + 6f, y + 12f, x + 14f, y + 20f - bob, cc(0xFF2B1D3D))
                fr(c, x - 26f, y - 22f, x - 18f, y + 4f, body)
                fr(c, x + 18f, y - 22f, x + 26f, y + 4f, body)
                fr(c, x - 18f, y - 26f, x + 18f, y + 12f, body)
                if (!fl) {
                    fr(c, x - 12f, y - 18f, x - 10f, y + 4f, cc(0xFFFF6D00))
                    fr(c, x + 8f, y - 14f, x + 10f, y + 8f, cc(0xFFFF6D00))
                    fr(c, x - 4f, y - 6f, x + 4f, y - 4f, cc(0xFFFF6D00))
                }
                fr(c, x - 12f, y - 40f, x + 12f, y - 24f, if (fl) white else cc(0xFF54406E))
                fr(c, x - 14f, y - 48f, x - 10f, y - 38f, cc(0xFF2B1D3D))
                fr(c, x + 10f, y - 48f, x + 14f, y - 38f, cc(0xFF2B1D3D))
                fr(c, x - 8f, y - 34f, x - 3f, y - 30f, cc(0xFFFFA000))
                fr(c, x + 3f, y - 34f, x + 8f, y - 30f, cc(0xFFFFA000))
                if (e.st == 1) {
                    c.save()
                    c.translate(x, y)
                    c.rotate(deg(atan2(e.dy, e.dx)))
                    val a = 0.2f + 0.3f * (1f - e.stT / 0.8f)
                    fr(c, 0f, -14f, 170f, 14f, withA(cc(0xFFFF5252), a))
                    c.restore()
                } else if (e.st == 4) {
                    val rad = (1f - e.stT / 0.7f) * 60f
                    circle(c, x, y, rad, withA(cc(0xFFFF8A65), 0.6f), 3f)
                }
            }
        }
        if (e.type != EType.BOSS && e.hp < e.maxHp) {
            val top = y - r - 14f
            fr(c, x - 10f, top, x + 10f, top + 3f, cc(0x99000000))
            fr(c, x - 10f, top, x - 10f + 20f * (e.hp / e.maxHp).coerceIn(0f, 1f), top + 3f, cc(0xFFE53935))
        }
    }

    // ------------------------------------------------------------------ HUD

    private fun drawBtn(c: Canvas, b: Btn, label: String, col: Int, frac: Float, sub: String?) {
        circle(c, b.cx, b.cy, b.r, withA(col, 0.45f))
        if (frac > 0f) {
            paint.style = Paint.Style.FILL
            paint.color = cc(0x99000000)
            rf.set(b.cx - b.r, b.cy - b.r, b.cx + b.r, b.cy + b.r)
            c.drawArc(rf, -90f, 360f * frac.coerceIn(0f, 1f), true, paint)
        }
        circle(c, b.cx, b.cy, b.r, withA(white, 0.6f), 2 * d)
        val size = if (b.r > 40 * d) 15 * d else 11 * d
        txt(c, label, b.cx, b.cy + size * 0.35f, size, white, Paint.Align.CENTER)
        if (sub != null) {
            txt(c, sub, b.cx + b.r * 0.62f, b.cy - b.r * 0.5f, 12 * d, gold, Paint.Align.CENTER)
        }
    }

    private fun drawHud(c: Canvas, w: Int, h: Int) {
        val p = g.player
        val wf = w.toFloat()
        val hf = h.toFloat()

        val bx = 12 * d
        val by = 12 * d
        val bw = 170 * d
        fr(c, bx - 2 * d, by - 2 * d, bx + bw + 2 * d, by + 26 * d, cc(0x99000000))
        fr(c, bx, by, bx + bw * (p.hp / p.maxHp).coerceIn(0f, 1f), by + 14 * d, cc(0xFFE53935))
        txt(c, "${p.hp.toInt().coerceAtLeast(0)}/${p.maxHp.toInt()}", bx + 6 * d, by + 11.5f * d, 11 * d, white)
        fr(c, bx, by + 17 * d, bx + bw * (p.xp.toFloat() / p.xpNeed()).coerceIn(0f, 1f), by + 23 * d, cc(0xFF42A5F5))
        txt(c, "Nv ${p.level}", bx + bw + 10 * d, by + 14 * d, 14 * d, gold)
        txt(c, "Gemas ${p.gems}   Poções ${p.potions}   Flechas ${p.arrows}", bx, by + 42 * d, 11 * d, white)

        if (g.bannerT > 0f) {
            val a = min(1f, g.bannerT)
            txt(c, g.banner, wf / 2f + 2 * d, hf * 0.22f + 2 * d, 22 * d, withA(cc(0xFF000000), a), Paint.Align.CENTER)
            txt(c, g.banner, wf / 2f, hf * 0.22f, 22 * d, withA(white, a), Paint.Align.CENTER)
        }

        val bs = g.boss
        if (bs != null && !bs.dead && bs.aggro) {
            val bwid = min(300 * d, wf * 0.35f)
            val l = wf / 2f - bwid / 2f
            val t = hf - 26 * d
            fr(c, l - 2 * d, t - 2 * d, l + bwid + 2 * d, t + 12 * d, cc(0xAA000000))
            fr(c, l, t, l + bwid * (bs.hp / bs.maxHp).coerceIn(0f, 1f), t + 10 * d, cc(0xFF8E24AA))
            txt(c, EType.BOSS.label, wf / 2f, t - 5 * d, 11 * d, white, Paint.Align.CENTER)
        }

        // minimapa
        if (g.seenDirty) {
            g.seenDirty = false
            for (i in miniPix.indices) {
                miniPix[i] = if (!g.seen[i]) 0 else if (g.map[i] != 0) cc(0xCCB0BEC5) else cc(0x55222222)
            }
            miniBmp.setPixels(miniPix, 0, Game.MW, 0, 0, Game.MW, Game.MH)
        }
        val ms = 84 * d
        val mr = wf - 56 * d - 8 * d
        val mt = 12 * d
        rf.set(mr - ms, mt, mr, mt + ms)
        fr(c, rf.left, rf.top, rf.right, rf.bottom, cc(0x88000000))
        c.drawBitmap(miniBmp, null, rf, bmpPaint)
        val mx = rf.left + (p.x / Game.T) / Game.MW * ms
        val my = rf.top + (p.y / Game.T) / Game.MH * ms
        fr(c, mx - 2 * d, my - 2 * d, mx + 2 * d, my + 2 * d, white)
        if (g.exitOpen && g.seen[idx(g.exitX, g.exitY)]) {
            val ex = rf.left + (g.exitX / Game.T) / Game.MW * ms
            val ey = rf.top + (g.exitY / Game.T) / Game.MH * ms
            fr(c, ex - 2 * d, ey - 2 * d, ex + 2 * d, ey + 2 * d, cc(0xFFB388FF))
        }

        if (g.state != State.PLAY) return

        drawBtn(c, bInv, "INV", cc(0xFF455A64), 0f, null)
        val acd = p.weapon.wtype?.cooldown ?: 0.35f
        drawBtn(c, bAtk, "ATQ", cc(0xFFD32F2F), p.atkCd / acd, null)
        drawBtn(c, bRoll, "ROL", cc(0xFF1976D2), p.rollCd / 0.8f, null)
        drawBtn(c, bBow, "ARC", cc(0xFF6D4C41), if (p.arrows <= 0) 1f else p.bowCd / 0.45f, "${p.arrows}")
        drawBtn(c, bPot, "POC", cc(0xFF388E3C), if (p.potions <= 0 || p.hp >= p.maxHp) 1f else 0f, "${p.potions}")

        if (joyPtr != -1) {
            circle(c, joyBX, joyBY, 48 * d, withA(white, 0.12f))
            circle(c, joyBX, joyBY, 48 * d, withA(white, 0.35f), 2 * d)
            circle(c, joyX, joyY, 22 * d, withA(white, 0.45f))
        } else {
            circle(c, 90 * d, hf - 90 * d, 48 * d, withA(white, 0.10f), 2 * d)
        }
    }

    // ------------------------------------------------------------------ telas sobrepostas

    private fun drawSimpleBtn(c: Canvas, r: RectF, label: String, enabled: Boolean) {
        paint.style = Paint.Style.FILL
        paint.color = if (enabled) cc(0xFF2E7D32) else cc(0xFF3A3F3A)
        c.drawRoundRect(r, 6 * d, 6 * d, paint)
        txt(c, label, r.centerX(), r.centerY() + 4.5f * d, 13 * d, if (enabled) white else cc(0xFF78807A), Paint.Align.CENTER)
    }

    private fun drawInventory(c: Canvas, w: Int, h: Int) {
        val p = g.player
        fr(c, 0f, 0f, w.toFloat(), h.toFloat(), cc(0xAA000000))
        paint.style = Paint.Style.FILL
        paint.color = cc(0xF01B1F1B)
        c.drawRoundRect(invPanel, 10 * d, 10 * d, paint)
        txt(c, "Mochila", invPanel.left + 12 * d, invPanel.top + 30 * d, 20 * d, white)

        val lx = invPanel.left + 12 * d
        var ly = invPanel.top + 54 * d
        txt(c, "Arma equipada", lx, ly, 10 * d, grey)
        ly += 14 * d
        txt(c, p.weapon.name, lx, ly, 13 * d, p.weapon.rarity.color)
        ly += 14 * d
        txt(c, p.weapon.stat, lx, ly, 11 * d, white)
        ly += 20 * d
        txt(c, "Armadura", lx, ly, 10 * d, grey)
        ly += 14 * d
        val ar = p.armor
        if (ar != null) {
            txt(c, ar.name, lx, ly, 13 * d, ar.rarity.color)
            ly += 14 * d
            txt(c, ar.stat, lx, ly, 11 * d, white)
        } else {
            txt(c, "Nenhuma", lx, ly, 13 * d, grey)
            ly += 14 * d
        }
        ly += 18 * d
        txt(c, "Nível ${p.level}   Vida ${p.hp.toInt()}/${p.maxHp.toInt()}", lx, ly, 11 * d, white)
        ly += 15 * d
        txt(c, "Gemas ${p.gems}   Poções ${p.potions}/5", lx, ly, 11 * d, white)

        val bag = p.bag
        val valid = sel >= 0 && sel < bag.size
        drawSimpleBtn(c, invEquip, "Equipar", valid)
        drawSimpleBtn(c, invSell, if (valid) "Vender ${bag[sel].sellPrice}" else "Vender", valid)
        drawSimpleBtn(c, invBuy, "Poção (30 gemas)", p.gems >= 30 && p.potions < 5)
        drawSimpleBtn(c, invClose, "Continuar", true)

        txt(c, "Itens (${bag.size}/12)", cards[0].left, invPanel.top + 30 * d, 13 * d, grey)
        for (i in 0 until 12) {
            val r = cards[i]
            paint.style = Paint.Style.FILL
            if (i < bag.size) {
                val it = bag[i]
                paint.color = if (i == sel) cc(0xFF34403A) else cc(0xFF262B26)
                c.drawRoundRect(r, 6 * d, 6 * d, paint)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = if (i == sel) 3 * d else 1.5f * d
                paint.color = it.rarity.color
                c.drawRoundRect(r, 6 * d, 6 * d, paint)
                txt(c, it.title, r.left + 8 * d, r.top + 20 * d, 13 * d, it.rarity.color)
                txt(c, it.suffix, r.left + 8 * d, r.top + 36 * d, 11 * d, white)
                txt(c, it.stat, r.left + 8 * d, r.top + 52 * d, 10 * d, grey)
            } else {
                paint.color = cc(0xFF1F231F)
                c.drawRoundRect(r, 6 * d, 6 * d, paint)
            }
        }
    }

    private fun drawEnd(c: Canvas, w: Int, h: Int, win: Boolean) {
        val p = g.player
        val wf = w.toFloat()
        val hf = h.toFloat()
        fr(c, 0f, 0f, wf, hf, cc(0xAA000000))
        txt(
            c, if (win) "VITÓRIA!" else "VOCÊ CAIU!", wf / 2f, hf * 0.34f, 44 * d,
            if (win) gold else cc(0xFFEF5350), Paint.Align.CENTER
        )
        txt(
            c, "Fase ${g.level}   Nível ${p.level}   Gemas ${p.gems}   Inimigos ${p.kills}",
            wf / 2f, hf * 0.5f, 15 * d, white, Paint.Align.CENTER
        )
        if (g.stateT > 0.8f) {
            val pulse = 0.55f + 0.45f * sin(g.stateT * 3f)
            txt(c, "Toque para voltar ao menu", wf / 2f, hf * 0.68f, 18 * d, withA(white, pulse), Paint.Align.CENTER)
        }
    }
}
