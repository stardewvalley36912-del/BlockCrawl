package com.example.blockcrawl

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

private fun cc(v: Long): Int = v.toInt()

private fun withA(col: Int, a: Float): Int =
    (col and 0x00FFFFFF) or ((a.coerceIn(0f, 1f) * 255f).toInt() shl 24)

private fun deg(r: Float): Float = r * 57.29578f

class GameView(ctx: Context) : View(ctx) {

    private class Theme(val floorA: Int, val floorB: Int, val wallTop: Int, val wallFace: Int, val bg: Int)

    private class Btn {
        var cx = 0f
        var cy = 0f
        var r = 0f
        fun set(x: Float, y: Float, radius: Float) {
            cx = x
            cy = y
            r = radius
        }

        fun hit(x: Float, y: Float): Boolean = hypot(x - cx, y - cy) <= r * 1.2f
    }

    private val g = Game()
    private val density = resources.displayMetrics.density
    private var d = density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint().apply { isFilterBitmap = false }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }
    private val rf = RectF()
    private val mrect = RectF()
    private var last = System.nanoTime()
    private var running = true
    private var menuT = 0f

    private val white = cc(0xFFFFFFFF)
    private val grey = cc(0xFFB0BEC5)
    private val gold = cc(0xFFFFD54F)

    private val themes = arrayOf(
        Theme(cc(0xFF6E8665), cc(0xFF647C5B), cc(0xFF3E4D3B), cc(0xFF2C392A), cc(0xFF0B0E0B)),
        Theme(cc(0xFF8C5C54), cc(0xFF82544D), cc(0xFF573229), cc(0xFF3C1F1A), cc(0xFF0F0605)),
        Theme(cc(0xFF6E669C), cc(0xFF635C90), cc(0xFF3E3763), cc(0xFF2B2449), cc(0xFF08060F))
    )

    private val bAtk = Btn()
    private val bRoll = Btn()
    private val bBow = Btn()
    private val bPot = Btn()
    private val bInv = Btn()
    private val bRotL = Btn()
    private val bRotR = Btn()
    private var camPtr = -1
    private var camLastX = 0f

    private var joyPtr = -1
    private var atkPtr = -1
    private var joyBX = 0f
    private var joyBY = 0f
    private var joyX = 0f
    private var joyY = 0f

    private val invPanel = RectF()
    private val invClose = RectF()
    private val invBuy = RectF()
    private val invEquip = RectF()
    private val invSell = RectF()
    private val cards = Array(12) { RectF() }
    private var sel = -1

    private val miniBmp: Bitmap = Bitmap.createBitmap(Game.MW, Game.MH, Bitmap.Config.ARGB_8888)
    private val miniPix = IntArray(Game.MW * Game.MH)

    // ------------------------------------------------------------------ ciclo de vida

    fun pauseGame() {
        running = false
        releaseAll()
        if (g.state == State.PLAY) g.openInventory()
    }

    fun resumeGame() {
        last = System.nanoTime()
        running = true
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val wf = w.toFloat()
        val hf = h.toFloat()
        d = density * min(1f, h / (360f * density))

        bAtk.set(wf - 80 * d, hf - 80 * d, 44 * d)
        bRoll.set(wf - 165 * d, hf - 52 * d, 30 * d)
        bBow.set(wf - 150 * d, hf - 128 * d, 28 * d)
        bPot.set(wf - 68 * d, hf - 160 * d, 28 * d)
        bInv.set(wf - 34 * d, 34 * d, 22 * d)
        bRotL.set(wf - 62 * d, 128 * d, 18 * d)
        bRotR.set(wf - 24 * d, 128 * d, 18 * d)

        val m = 10 * d
        invPanel.set(m, m, wf - m, hf - m)
        val leftW = (wf - 2 * m) * 0.36f
        val bx = invPanel.left + 12 * d
        val bw = leftW - 12 * d
        val bh = 36 * d
        invClose.set(bx, invPanel.bottom - 12 * d - bh, bx + bw, invPanel.bottom - 12 * d)
        invBuy.set(bx, invClose.top - 8 * d - bh, bx + bw, invClose.top - 8 * d)
        val half = (bw - 8 * d) / 2f
        invEquip.set(bx, invBuy.top - 8 * d - bh, bx + half, invBuy.top - 8 * d)
        invSell.set(bx + half + 8 * d, invEquip.top, bx + bw, invEquip.bottom)

        val gx = invPanel.left + leftW + 12 * d
        val gy = invPanel.top + 44 * d
        val gw = invPanel.right - 12 * d - gx
        val gh = invPanel.bottom - 12 * d - gy
        val gap = 8 * d
        val cw = (gw - 2 * gap) / 3f
        val ch = (gh - 3 * gap) / 4f
        for (i in 0 until 12) {
            val col = i % 3
            val row = i / 3
            val l = gx + col * (cw + gap)
            val t = gy + row * (ch + gap)
            cards[i].set(l, t, l + cw, t + ch)
        }
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        var dt = (now - last) / 1_000_000_000f
        last = now
        if (dt > 0.05f) dt = 0.05f
        frameDt = dt
        if (running) {
            g.update(dt)
            menuT += dt
        }
        render(c)
        postInvalidateOnAnimation()
    }

    // ------------------------------------------------------------------ entrada

    private fun releaseAll() {
        camPtr = -1
        joyPtr = -1
        atkPtr = -1
        g.moveX = 0f
        g.moveY = 0f
        g.attackHeld = false
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = ev.actionIndex
                onDown(ev.getPointerId(i), ev.getX(i), ev.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until ev.pointerCount) onMove(ev.getPointerId(i), ev.getX(i), ev.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> onUp(ev.getPointerId(ev.actionIndex))
            MotionEvent.ACTION_CANCEL -> releaseAll()
        }
        return true
    }

    private fun onDown(id: Int, x: Float, y: Float) {
        when (g.state) {
            State.MENU -> {
                if (g.stateT > 0.4f) {
                    releaseAll()
                    g.startRun()
                }
            }
            State.DEAD, State.WIN -> {
                if (g.stateT > 0.8f) g.toMenu()
            }
            State.INV -> invTouch(x, y)
            State.PLAY -> playTouch(id, x, y)
        }
    }

    private fun playTouch(id: Int, x: Float, y: Float) {
        if (bInv.hit(x, y)) {
            releaseAll()
            sel = -1
            g.openInventory()
            return
        }
        if (bRotL.hit(x, y)) {
            yawT -= 0.7853982f
            return
        }
        if (bRotR.hit(x, y)) {
            yawT += 0.7853982f
            return
        }
        if (bAtk.hit(x, y)) {
            atkPtr = id
            g.attackHeld = true
            return
        }
        if (bRoll.hit(x, y)) {
            g.doRoll()
            return
        }
        if (bBow.hit(x, y)) {
            g.shootBow()
            return
        }
        if (bPot.hit(x, y)) {
            g.usePotion()
            return
        }
        if (x >= width * 0.5f && camPtr == -1) {
            camPtr = id
            camLastX = x
            return
        }
        if (x < width * 0.5f && joyPtr == -1) {
            joyPtr = id
            joyBX = x
            joyBY = y
            joyX = x
            joyY = y
            g.moveX = 0f
            g.moveY = 0f
        }
    }

    private fun onMove(id: Int, x: Float, y: Float) {
        if (id == camPtr && g.state == State.PLAY) {
            val dxm = x - camLastX
            camLastX = x
            yawT += dxm * 0.008f
            yaw += dxm * 0.008f
        }
        if (id == joyPtr && g.state == State.PLAY) {
            val dx = x - joyBX
            val dy = y - joyBY
            val len = hypot(dx, dy)
            val r = 48 * d
            val k = if (len > r) r / len else 1f
            joyX = joyBX + dx * k
            joyY = joyBY + dy * k
            val jx = dx * k / r
            val jy = dy * k / r
            g.moveX = jx * cYaw + jy * sYaw
            g.moveY = jy * cYaw - jx * sYaw
        }
    }

    private fun onUp(id: Int) {
        if (id == -1) return
        if (id == joyPtr) {
            joyPtr = -1
            g.moveX = 0f
            g.moveY = 0f
        }
        if (id == atkPtr) {
            atkPtr = -1
            g.attackHeld = false
        }
        if (id == camPtr) camPtr = -1
    }

    private fun invTouch(x: Float, y: Float) {
        val bag = g.player.bag
        val valid = sel >= 0 && sel < bag.size
        if (invClose.contains(x, y)) {
            g.closeInventory()
            return
        }
        if (invBuy.contains(x, y)) {
            g.buyPotion()
            return
        }
        if (invEquip.contains(x, y) && valid) {
            g.equip(sel)
            sel = -1
            return
        }
        if (invSell.contains(x, y) && valid) {
            g.sell(sel)
            sel = -1
            return
        }
        for (i in cards.indices) {
            if (cards[i].contains(x, y)) {
                sel = if (i < bag.size) i else -1
                return
            }
        }
    }

    // ------------------------------------------------------------------ helpers de desenho

    private fun fr(c: Canvas, l: Float, t: Float, r: Float, b: Float, col: Int) {
        paint.style = Paint.Style.FILL
        paint.color = col
        c.drawRect(l, t, r, b, paint)
    }

    private fun sr(c: Canvas, l: Float, t: Float, r: Float, b: Float, col: Int, w: Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = w
        paint.color = col
        c.drawRect(l, t, r, b, paint)
    }

    private fun oval(c: Canvas, cx: Float, cy: Float, rx: Float, ry: Float, col: Int) {
        paint.style = Paint.Style.FILL
        paint.color = col
        rf.set(cx - rx, cy - ry, cx + rx, cy + ry)
        c.drawOval(rf, paint)
    }

    private fun circle(c: Canvas, cx: Float, cy: Float, r: Float, col: Int, stroke: Float = 0f) {
        if (stroke > 0f) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = stroke
        } else {
            paint.style = Paint.Style.FILL
        }
        paint.color = col
        c.drawCircle(cx, cy, r, paint)
    }

    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, col: Int, w: Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = w
        paint.color = col
        c.drawLine(x1, y1, x2, y2, paint)
    }

    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, col: Int, align: Paint.Align = Paint.Align.LEFT) {
        tp.textSize = size
        tp.color = col
        tp.textAlign = align
        c.drawText(s, x, y, tp)
    }

    private fun idx(x: Float, y: Float): Int {
        val tx = floor(x / Game.T).toInt()
        val ty = floor(y / Game.T).toInt()
        if (tx < 0 || ty < 0 || tx >= Game.MW || ty >= Game.MH) return 0
        return ty * Game.MW + tx
    }

    private fun nearFloor(tx: Int, ty: Int): Boolean {
        for (dy in -1..1) {
            for (dx in -1..1) {
                val x = tx + dx
                val y = ty + dy
                if (x < 0 || y < 0 || x >= Game.MW || y >= Game.MH) continue
                if (g.map[y * Game.MW + x] != 0) return true
            }
        }
        return false
    }

    // ------------------------------------------------------------------ render principal

    private fun render(c: Canvas) {
        val w = width
        val h = height
        c.drawColor(cc(0xFF000000))
        if (g.state == State.MENU) {
            drawMenu(c, w, h)
            return
        }
        drawWorld(c, w, h)
        drawHud(c, w, h)
        when (g.state) {
            State.INV -> drawInventory(c, w, h)
            State.DEAD -> drawEnd(c, w, h, false)
            State.WIN -> drawEnd(c, w, h, true)
            else -> {}
        }
    }

    private fun drawMenu(c: Canvas, w: Int, h: Int) {
        val wf = w.toFloat()
        val hf = h.toFloat()
        c.drawColor(cc(0xFF0B0E0B))
        val bs = 28 * d
        var ty = 0
        var y = 0f
        while (y < hf) {
            var tx = 0
            var x = 0f
            while (x < wf) {
                if ((tx * 7 + ty * 13) % 5 == 0) {
                    fr(c, x, y, x + bs, y + bs, if ((tx + ty) % 2 == 0) cc(0xFF121A12) else cc(0xFF0F150F))
                }
                x += bs
                tx++
            }
            y += bs
            ty++
        }
        val cx = wf / 2f
        txt(c, "BLOCKCRAWL", cx + 4 * d, hf * 0.34f + 4 * d, 56 * d, cc(0xFF1B5E20), Paint.Align.CENTER)
        txt(c, "BLOCKCRAWL", cx, hf * 0.34f, 56 * d, cc(0xFF8BC34A), Paint.Align.CENTER)
        txt(c, "Masmorras de Blocos em 3D", cx, hf * 0.34f + 28 * d, 18 * d, grey, Paint.Align.CENTER)
        val pulse = 0.55f + 0.45f * sin(menuT * 3f)
        txt(c, "Toque para jogar", cx, hf * 0.62f, 24 * d, withA(white, pulse), Paint.Align.CENTER)
        txt(c, "Esquerda: mover   |   Arraste na direita ou use < >: girar a câmera", cx, hf * 0.76f, 13 * d, grey, Paint.Align.CENTER)
        txt(c, "ROL: rolar (invencível)   ARC: arco   POC: poção   INV: mochila", cx, hf * 0.76f + 20 * d, 13 * d, grey, Paint.Align.CENTER)
        txt(c, "3 fases  -  11 tipos de arma  -  derrote o Guardião de Obsidiana", cx, hf * 0.76f + 40 * d, 13 * d, grey, Paint.Align.CENTER)
    }

    // ------------------------------------------------------------------ mundo 3D

    private class DrawItem {
        var kind = 0
        var ref: Any? = null
        var key = 0f
        var ix = 0
        var iy = 0
    }

    private var yaw = 0.62f
    private var yawT = 0.62f
    private var cYaw = cos(0.62f)
    private var sYaw = sin(0.62f)
    private var faceAng = -0.62f
    private val PITCH = 0.96f
    private val SPN = sin(PITCH)
    private val CPN = cos(PITCH)
    private val WALL_H = 46f
    private val PI_F = 3.1415927f

    private var camX = 0f
    private var camY = 0f
    private var scl = 3f
    private var ocx = 0f
    private var ocy = 0f
    private var frameDt = 0.016f
    private lateinit var cv: Canvas
    private val path = Path()
    private val sx4 = FloatArray(4)
    private val sy4 = FloatArray(4)
    private val wx4 = FloatArray(4)
    private val wy4 = FloatArray(4)
    private val items = ArrayList<DrawItem>()
    private var itemCount = 0
    private val itemCmp = Comparator<DrawItem> { a, b -> a.key.compareTo(b.key) }

    private var fx = 0f
    private var fy = 0f
    private var fa = 0f
    private var fca = 1f
    private var fsa = 0f
    private var ffog = 1f
    private var flashOn = false

    private fun projX(x: Float, y: Float): Float = ((x - camX) * cYaw - (y - camY) * sYaw) * scl + ocx

    private fun projY(x: Float, y: Float, z: Float): Float =
        (((x - camX) * sYaw + (y - camY) * cYaw) * SPN - z * CPN) * scl + ocy

    private fun depthKey(x: Float, y: Float): Float = x * sYaw + y * cYaw

    private fun shade(c: Int, f: Float): Int {
        val ff = if (f < 0f) 0f else f
        var r = ((c shr 16) and 255) * ff
        var gg = ((c shr 8) and 255) * ff
        var b = (c and 255) * ff
        if (r > 255f) r = 255f
        if (gg > 255f) gg = 255f
        if (b > 255f) b = 255f
        return (0xFF shl 24) or (r.toInt() shl 16) or (gg.toInt() shl 8) or b.toInt()
    }

    private fun fogAt(x: Float, y: Float): Float {
        val dx = x - camX
        val dy = y - camY
        val dist = sqrt(dx * dx + dy * dy) / Game.T
        val t = ((dist - 6.5f) / 7f).coerceIn(0f, 1f)
        return 1f - t * 0.45f
    }

    private fun onScr(x: Float, y: Float): Boolean {
        val m = Game.T * scl * 2.5f
        val sx = projX(x, y)
        val sy = projY(x, y, 0f)
        return sx > -m && sx < width + m && sy > -m && sy < height + m
    }

    private fun fillQuad(
        x1: Float, y1: Float, x2: Float, y2: Float,
        x3: Float, y3: Float, x4: Float, y4: Float, col: Int
    ) {
        path.reset()
        path.moveTo(x1, y1)
        path.lineTo(x2, y2)
        path.lineTo(x3, y3)
        path.lineTo(x4, y4)
        path.close()
        paint.style = Paint.Style.FILL
        paint.color = col
        cv.drawPath(path, paint)
    }

    /** Retangulo plano no chao (alinhado aos eixos do mundo). */
    private fun flatQuad(xa: Float, ya: Float, xb: Float, yb: Float, z: Float, col: Int) {
        fillQuad(
            projX(xa, ya), projY(xa, ya, z), projX(xb, ya), projY(xb, ya, z),
            projX(xb, yb), projY(xb, yb, z), projX(xa, yb), projY(xa, yb, z), col
        )
    }

    private fun groundOval(x: Float, y: Float, r: Float, col: Int) {
        val sx = projX(x, y)
        val sy = projY(x, y, 0f)
        paint.style = Paint.Style.FILL
        paint.color = col
        rf.set(sx - r * scl, sy - r * scl * SPN, sx + r * scl, sy + r * scl * SPN)
        cv.drawOval(rf, paint)
    }

    private fun groundRing(x: Float, y: Float, r: Float, col: Int, stroke: Float) {
        val sx = projX(x, y)
        val sy = projY(x, y, 1f)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = stroke
        paint.color = col
        rf.set(sx - r * scl, sy - r * scl * SPN, sx + r * scl, sy + r * scl * SPN)
        cv.drawOval(rf, paint)
    }

    private fun groundSector(x: Float, y: Float, a0: Float, a1: Float, r: Float, col: Int) {
        path.reset()
        path.moveTo(projX(x, y), projY(x, y, 3f))
        val n = 10
        for (i in 0..n) {
            val a = a0 + (a1 - a0) * i / n
            val wx = x + cos(a) * r
            val wy = y + sin(a) * r
            path.lineTo(projX(wx, wy), projY(wx, wy, 3f))
        }
        path.close()
        paint.style = Paint.Style.FILL
        paint.color = col
        cv.drawPath(path, paint)
    }

    private fun groundRect(x: Float, y: Float, ang: Float, len: Float, halfW: Float, col: Int) {
        val ca = cos(ang)
        val sa = sin(ang)
        val ax = x - sa * halfW
        val ay = y + ca * halfW
        val bx = x + sa * halfW
        val by = y - ca * halfW
        val cx = bx + ca * len
        val cy = by + sa * len
        val dx = ax + ca * len
        val dy = ay + sa * len
        fillQuad(
            projX(ax, ay), projY(ax, ay, 2f), projX(bx, by), projY(bx, by, 2f),
            projX(cx, cy), projY(cx, cy, 2f), projX(dx, dy), projY(dx, dy, 2f), col
        )
    }

    private fun glow(x: Float, y: Float, z: Float, r: Float, col: Int, a: Float) {
        paint.style = Paint.Style.FILL
        paint.color = withA(col, a)
        cv.drawCircle(projX(x, y), projY(x, y, z), r * scl, paint)
    }

    /** Caixa 3D (prisma) girada em torno do eixo vertical. w = eixo local x, dp = eixo local y. */
    private fun box(
        x: Float, y: Float, z0: Float, w: Float, dp: Float, h: Float,
        ang: Float, col: Int, fog: Float, skip: Int = 0, topCol: Int = 0
    ) {
        val ca = cos(ang)
        val sa = sin(ang)
        val hw = w * 0.5f
        val hd = dp * 0.5f
        wx4[0] = x - hw * ca + hd * sa
        wy4[0] = y - hw * sa - hd * ca
        wx4[1] = x + hw * ca + hd * sa
        wy4[1] = y + hw * sa - hd * ca
        wx4[2] = x + hw * ca - hd * sa
        wy4[2] = y + hw * sa + hd * ca
        wx4[3] = x - hw * ca - hd * sa
        wy4[3] = y - hw * sa + hd * ca
        for (i in 0 until 4) {
            sx4[i] = projX(wx4[i], wy4[i])
            sy4[i] = projY(wx4[i], wy4[i], z0)
        }
        val hh = h * CPN * scl
        for (i in 0 until 4) {
            val nx = when (i) {
                0 -> sa
                1 -> ca
                2 -> -sa
                else -> -ca
            }
            val ny = when (i) {
                0 -> -ca
                1 -> sa
                2 -> ca
                else -> -sa
            }
            if (((skip shr i) and 1) != 0) continue
            if (nx * sYaw + ny * cYaw <= 0.001f) continue
            var f = 0.52f + 0.33f * (nx * 0.95f + ny * 0.31f)
            if (f < 0.4f) f = 0.4f
            if (f > 0.95f) f = 0.95f
            val j = (i + 1) and 3
            fillQuad(
                sx4[i], sy4[i], sx4[j], sy4[j],
                sx4[j], sy4[j] - hh, sx4[i], sy4[i] - hh, shade(col, fog * f)
            )
        }
        fillQuad(
            sx4[0], sy4[0] - hh, sx4[1], sy4[1] - hh,
            sx4[2], sy4[2] - hh, sx4[3], sy4[3] - hh, shade(if (topCol != 0) topCol else col, fog * 1.06f)
        )
    }

    private fun frame(x: Float, y: Float, a: Float, fog: Float) {
        fx = x
        fy = y
        fa = a
        fca = cos(a)
        fsa = sin(a)
        ffog = fog
    }

    /** Peca no referencial atual: ox para frente, oy para a direita do personagem. */
    private fun part(ox: Float, oy: Float, z0: Float, w: Float, dp: Float, h: Float, col: Int) {
        box(
            fx + ox * fca - oy * fsa, fy + ox * fsa + oy * fca,
            z0, w, dp, h, fa, if (flashOn) -1 else col, ffog
        )
    }

    private fun hpBar(x: Float, y: Float, z: Float, frac: Float, wdt: Float) {
        val sx = projX(x, y)
        val sy = projY(x, y, z)
        val hgt = 4f * d
        fr(cv, sx - wdt / 2f - 1f, sy - 1f, sx + wdt / 2f + 1f, sy + hgt + 1f, cc(0xAA000000))
        fr(cv, sx - wdt / 2f, sy, sx - wdt / 2f + wdt * frac.coerceIn(0f, 1f), sy + hgt, cc(0xFFE53935))
    }

    private fun addItem(kind: Int, ref: Any?, key: Float, ix: Int = 0, iy: Int = 0) {
        val di: DrawItem
        if (itemCount < items.size) {
            di = items[itemCount]
        } else {
            di = DrawItem()
            items.add(di)
        }
        di.kind = kind
        di.ref = ref
        di.key = key
        di.ix = ix
        di.iy = iy
        itemCount++
    }

    private fun drawWorld(c: Canvas, w: Int, h: Int) {
        cv = c
        val p = g.player
        val th = themes[(g.level - 1).coerceIn(0, 2)]
        val t = Game.T
        scl = h / (t * 7.6f)
        yaw += (yawT - yaw) * min(1f, 10f * frameDt)
        cYaw = cos(yaw)
        sYaw = sin(yaw)
        faceAng = -yaw
        var shx = 0f
        var shy = 0f
        if (g.shake > 0f) {
            val m = min(1f, g.shake * 4f) * 5f * scl
            shx = (g.rng.nextFloat() - 0.5f) * m
            shy = (g.rng.nextFloat() - 0.5f) * m
        }
        ocx = w / 2f + shx
        ocy = h * 0.56f + shy
        if (hypot(p.x - camX, p.y - camY) > 160f) {
            camX = p.x
            camY = p.y
        } else {
            val k = min(1f, 7f * frameDt)
            camX += (p.x - camX) * k
            camY += (p.y - camY) * k
        }
        c.drawColor(th.bg)

        val rw = ((w * 0.5f) / scl + (h * 0.5f) / (scl * SPN) + 70f) * 0.9f + t
        val tcx = floor(camX / t).toInt()
        val tcy = floor(camY / t).toInt()
        val rt = (rw / t).toInt() + 1
        val tx0 = max(0, tcx - rt)
        val tx1 = min(Game.MW - 1, tcx + rt)
        val ty0 = max(0, tcy - rt)
        val ty1 = min(Game.MH - 1, tcy + rt)

        // 1) chao
        val cullM = t * scl * 1.6f
        for (ty in ty0..ty1) {
            for (tx in tx0..tx1) {
                val i = ty * Game.MW + tx
                if (!g.seen[i] || g.map[i] == 0) continue
                val xa = tx * t
                val ya = ty * t
                val xb = xa + t
                val yb = ya + t
                val csx = projX(xa + t / 2f, ya + t / 2f)
                val csy = projY(xa + t / 2f, ya + t / 2f, 0f)
                if (csx < -cullM || csx > w + cullM || csy < -cullM || csy > h + cullM) continue
                val fog = fogAt(xa + t / 2f, ya + t / 2f)
                val base = if (((tx + ty) and 1) == 0) th.floorA else th.floorB
                flatQuad(xa, ya, xb, yb, 0f, shade(base, fog))
                val hsh = ((tx * 73856093) xor (ty * 19349663)) and 0x7fffffff
                if (hsh % 9 == 0) {
                    val ox = xa + 6f + (hsh % 11)
                    val oy = ya + 8f + (hsh % 7)
                    flatQuad(ox, oy, ox + 8f, oy + 4f, 0f, shade(base, fog * 0.78f))
                }
            }
        }

        // 2) objetos e paredes ordenados por profundidade (algoritmo do pintor)
        itemCount = 0
        for (ch in g.chests) {
            if (g.seen[idx(ch.x, ch.y)] && onScr(ch.x, ch.y)) addItem(0, ch, depthKey(ch.x, ch.y))
        }
        for (pk in g.pickups) {
            if (onScr(pk.x, pk.y)) addItem(1, pk, depthKey(pk.x, pk.y))
        }
        if (g.exitOpen && g.seen[idx(g.exitX, g.exitY)] && onScr(g.exitX, g.exitY)) {
            addItem(5, null, depthKey(g.exitX, g.exitY))
        }
        for (e in g.enemies) {
            if (!e.dead && g.seen[idx(e.x, e.y)] && onScr(e.x, e.y)) addItem(2, e, depthKey(e.x, e.y))
        }
        addItem(3, p, depthKey(p.x, p.y))
        for (pr in g.projs) {
            if (onScr(pr.x, pr.y)) addItem(4, pr, depthKey(pr.x, pr.y))
        }
        for (ty in ty0..ty1) {
            for (tx in tx0..tx1) {
                val i = ty * Game.MW + tx
                if (g.map[i] != 0 || !g.seen[i] || !nearFloor(tx, ty)) continue
                val cxw = tx * t + t / 2f
                val cyw = ty * t + t / 2f
                if (onScr(cxw, cyw)) addItem(6, null, depthKey(cxw, cyw), tx, ty)
            }
        }
        if (itemCount > 1) items.subList(0, itemCount).sortWith(itemCmp)

        // 3) desenho
        for (k in 0 until itemCount) drawItem(items[k], th, p)

        // 4) particulas e textos (espaco da tela)
        for (q in g.parts) {
            val a = (q.life / 0.5f).coerceIn(0f, 1f)
            val sx = projX(q.x, q.y)
            val sy = projY(q.x, q.y, q.z)
            val sz = q.size * scl * 0.5f
            paint.style = Paint.Style.FILL
            paint.color = withA(q.color, a)
            c.drawRect(sx - sz, sy - sz, sx + sz, sy + sz, paint)
        }
        for (ft in g.texts) {
            val a = (ft.life / 0.4f).coerceIn(0f, 1f)
            val sx = projX(ft.x, ft.y)
            val sy = projY(ft.x, ft.y, ft.z)
            txt(c, ft.text, sx + 1f, sy + 1f, 12 * d, withA(cc(0xFF000000), a), Paint.Align.CENTER)
            txt(c, ft.text, sx, sy, 12 * d, withA(ft.color, a), Paint.Align.CENTER)
        }
    }

    private fun drawWallTile(tx: Int, ty: Int, th: Theme, p: Player) {
        val t = Game.T
        val cxw = tx * t + t / 2f
        val cyw = ty * t + t / 2f
        val hsh = ((tx * 73856093) xor (ty * 19349663)) and 0x7fffffff
        var wallH = WALL_H + (hsh % 5)
        // paredes entre a camera e o jogador ficam baixas para nao esconder o personagem
        val dxp = cxw - p.x
        val dyp = cyw - p.y
        val front = dxp * sYaw + dyp * cYaw
        val side = dxp * cYaw - dyp * sYaw
        if (front > 0f && sqrt(dxp * dxp + dyp * dyp) < t * 3.4f && abs(side) < t * 2.4f) {
            wallH = 12f
        }
        val fog = fogAt(cxw, cyw)
        var skip = 0
        if (g.solid(tx, ty - 1)) skip = skip or 1
        if (g.solid(tx + 1, ty)) skip = skip or 2
        if (g.solid(tx, ty + 1)) skip = skip or 4
        if (g.solid(tx - 1, ty)) skip = skip or 8
        val top = if (hsh % 7 == 0) shade(th.wallTop, 1.5f) else shade(th.wallTop, 1.3f)
        box(cxw, cyw, 0f, t, t, wallH, 0f, shade(th.wallFace, 1.9f), fog, skip, top)
    }

    private fun drawItem(di: DrawItem, th: Theme, p: Player) {
        when (di.kind) {
            6 -> drawWallTile(di.ix, di.iy, th, p)
            0 -> drawChest3D(di.ref as Chest)
            1 -> drawPickup3D(di.ref as Pickup)
            2 -> drawEnemy3D(di.ref as Enemy)
            3 -> drawPlayer3D(di.ref as Player)
            4 -> drawProj3D(di.ref as Projectile)
            else -> drawPortal3D()
        }
    }

    private fun drawChest3D(ch: Chest) {
        val fog = fogAt(ch.x, ch.y)
        groundOval(ch.x, ch.y, 12f, 0x55000000)
        frame(ch.x, ch.y, faceAng, fog)
        if (!ch.opened) {
            part(0f, 0f, 0f, 18f, 10f, 8f, cc(0xFF8D5524))
            part(0f, 0f, 8f, 18f, 10f, 4f, cc(0xFFA9703A))
            part(0f, 5.2f, 6.5f, 3f, 1f, 3.2f, cc(0xFFFFD54F))
        } else {
            part(0f, 0f, 0f, 18f, 10f, 8f, cc(0xFF6D4118))
            part(0f, 0f, 8f, 15f, 7f, 0.6f, cc(0xFF24150A))
            part(0f, -5f, 8f, 18f, 1.6f, 8f, cc(0xFF8A5A2B))
        }
    }

    private fun drawPickup3D(pk: Pickup) {
        val fog = fogAt(pk.x, pk.y)
        val bob = 6f + sin(pk.t * 5f + pk.x) * 1.8f
        groundOval(pk.x, pk.y, 4.5f, 0x44000000)
        frame(pk.x, pk.y, pk.t * 3f, fog)
        when (pk.kind) {
            0 -> {
                part(0f, 0f, bob, 4.5f, 4.5f, 6f, cc(0xFF3DDC84))
                part(0f, 0f, bob + 6f, 2.2f, 2.2f, 1.6f, cc(0xFFB9F6CA))
            }
            1 -> {
                part(0f, 0f, bob, 5f, 5f, 6f, cc(0xFFE53935))
                part(0f, 0f, bob + 6f, 2.6f, 2.6f, 3f, cc(0xFFBDBDBD))
            }
            2 -> {
                part(0f, 0f, bob, 10f, 1.8f, 1.8f, cc(0xFF8D6E63))
                part(5.5f, 0f, bob, 3f, 3f, 2.6f, cc(0xFFE0E0E0))
            }
            else -> {
                val col = pk.item?.rarity?.color ?: white
                val sx = projX(pk.x, pk.y)
                val sy0 = projY(pk.x, pk.y, 0f)
                val sy1 = projY(pk.x, pk.y, 34f)
                paint.style = Paint.Style.FILL
                paint.color = withA(col, 0.22f)
                cv.drawRect(sx - 3f * scl, sy1, sx + 3f * scl, sy0, paint)
                glow(pk.x, pk.y, bob + 3f, 7f, col, 0.25f)
                part(0f, 0f, bob, 7f, 7f, 7f, col)
            }
        }
    }

    private fun drawPortal3D() {
        val x = g.exitX
        val y = g.exitY
        val fog = fogAt(x, y)
        val tt = g.time
        val pulse = 0.55f + 0.45f * sin(tt * 4f)
        groundOval(x, y, 18f, 0x66000000)
        val lx = cYaw
        val ly = -sYaw
        // vao interno
        val l = 12f
        val top = 30f
        fillQuad(
            projX(x - lx * l, y - ly * l), projY(x - lx * l, y - ly * l, 2f),
            projX(x + lx * l, y + ly * l), projY(x + lx * l, y + ly * l, 2f),
            projX(x + lx * l, y + ly * l), projY(x + lx * l, y + ly * l, top),
            projX(x - lx * l, y - ly * l), projY(x - lx * l, y - ly * l, top),
            withA(cc(0xFFB388FF), pulse)
        )
        glow(x, y, 16f, 16f, cc(0xFFB388FF), 0.18f * pulse)
        val stone = cc(0xFF2A1F44)
        box(x - lx * 14f, y - ly * 14f, 0f, 6f, 6f, 36f, faceAng, stone, fog)
        box(x + lx * 14f, y + ly * 14f, 0f, 6f, 6f, 36f, faceAng, stone, fog)
        box(x, y, 33f, 34f, 6f, 6f, faceAng, cc(0xFF3A2C5C), fog)
        for (k in 0 until 5) {
            val a = tt * 2f + k * 1.2566f
            val zz = 6f + (sin(tt * 3f + k) * 0.5f + 0.5f) * 22f
            val ox = x + lx * cos(a) * 9f
            val oy = y + ly * cos(a) * 9f
            box(ox, oy, zz, 2f, 2f, 2f, 0f, white, 1f)
        }
    }

    private fun drawProj3D(pr: Projectile) {
        val fog = fogAt(pr.x, pr.y)
        groundOval(pr.x, pr.y, 3.5f, 0x44000000)
        if (pr.kind <= 1) {
            frame(pr.x, pr.y, atan2(pr.vy, pr.vx), fog)
            val tip = if (pr.kind == 0) cc(0xFFFFE082) else cc(0xFFFFF59D)
            part(0f, 0f, 11f, 10f, 1.8f, 1.8f, cc(0xFF8D6E63))
            part(5.5f, 0f, 10.8f, 3f, 2.8f, 2.8f, tip)
        } else {
            val sz = pr.radius * 1.8f
            glow(pr.x, pr.y, 11f, pr.radius * 2.6f, pr.color, 0.28f)
            frame(pr.x, pr.y, g.time * 6f, 1f)
            part(0f, 0f, 9f, sz, sz, sz, pr.color)
        }
    }

    // ------------------------------------------------------------------ jogador

    private fun drawPlayer3D(p: Player) {
        if (p.hurt > 0f && ((p.hurt * 40f).toInt() % 2 == 0)) return
        val fog = fogAt(p.x, p.y)
        groundOval(p.x, p.y, 9f, 0x55000000)
        val skin = cc(0xFFF1C27D)
        val blue = cc(0xFF3F6FBF)
        val dark = cc(0xFF263238)
        if (p.rolling > 0f) {
            frame(p.x, p.y, p.rolling * 28f, fog)
            part(0f, 0f, 1f, 11f, 11f, 11f, blue)
            part(0f, 0f, 9f, 11.4f, 11.4f, 3f, skin)
            return
        }
        frame(p.x, p.y, p.facing, fog)
        val sw = if (p.moving) sin(g.time * 14f) * 3.4f else 0f
        part(sw, 3f, 0f, 4f, 4f, 10f, dark)
        part(-sw, -3f, 0f, 4f, 4f, 10f, dark)
        part(0f, 0f, 10f, 6f, 11f, 12f, blue)
        part(-sw * 0.6f, -7.5f, 10f, 3.6f, 3.6f, 12f, blue)
        part(-sw * 0.6f, -7.5f, 10f, 3.6f, 3.6f, 3f, skin)
        part(sw * 0.6f, 7.5f, 10f, 3.6f, 3.6f, 12f, blue)
        part(sw * 0.6f, 7.5f, 10f, 3.6f, 3.6f, 3f, skin)
        val ar = p.armor
        if (ar != null) {
            val rc = ar.rarity.color
            part(0.3f, 0f, 14f, 6.6f, 11.4f, 4f, rc)
            part(0f, -7.5f, 19.5f, 4.4f, 4.4f, 2.6f, rc)
            part(0f, 7.5f, 19.5f, 4.4f, 4.4f, 2.6f, rc)
        }
        part(0f, 0f, 22f, 8f, 8f, 8f, skin)
        part(-0.3f, 0f, 28f, 8.6f, 8.6f, 2.8f, cc(0xFF5D4037))
        part(4.1f, 2f, 25f, 0.8f, 1.7f, 1.9f, dark)
        part(4.1f, -2f, 25f, 0.8f, 1.7f, 1.9f, dark)
        drawWeapon(p, fog)
    }

    private fun drawWeapon(p: Player, fog: Float) {
        val wt = p.weapon.wtype ?: return
        val half = min(wt.halfArc, 1.5f)
        val thrustType = wt.halfArc < 0.5f || wt.ranged
        var ang = p.facing + 0.5f * p.swingSign
        var thrust = 0f
        var swinging = false
        var prog = 0f
        if (p.atkAnim > 0f) {
            prog = 1f - p.atkAnim / p.atkDur
            swinging = true
            if (thrustType) {
                ang = p.facing
                thrust = sin(prog * PI_F) * 13f
            } else if (wt.slam) {
                ang = p.facing + (prog - 0.5f) * 0.5f
                thrust = sin(prog * PI_F) * 6f
            } else {
                ang = p.facing + p.swingSign * (prog - 0.5f) * 2f * half
            }
        }
        val hx: Float
        val hy: Float
        if (swinging && !thrustType && !wt.slam) {
            hx = p.x + cos(ang) * 7f
            hy = p.y + sin(ang) * 7f
        } else {
            val fwd = 2f + thrust
            hx = p.x + fwd * cos(p.facing) - 7.5f * sin(p.facing)
            hy = p.y + fwd * sin(p.facing) + 7.5f * cos(p.facing)
        }
        // rastro do golpe no chao
        if (swinging) {
            val sa = (p.atkAnim / p.atkDur).coerceIn(0f, 1f)
            if (thrustType) {
                groundRect(p.x, p.y, p.facing, wt.range * 0.95f, 2.5f, withA(white, 0.35f * sa))
            } else if (!wt.slam) {
                groundSector(
                    p.x, p.y, p.facing - half, p.facing + half,
                    wt.range * 0.9f, withA(white, 0.30f * sa)
                )
            }
        }
        frame(hx, hy, ang, fog)
        val z = 13f
        val brown = cc(0xFF6D4C41)
        val gold = cc(0xFFFFC107)
        val m = p.weapon.rarity.color
        when (wt) {
            WeaponType.SWORD -> {
                part(2f, 0f, z, 5f, 2f, 2f, brown)
                part(4.8f, 0f, z - 0.4f, 1.6f, 7f, 2.6f, gold)
                part(16f, 0f, z, 22f, 3f, 2.2f, m)
            }
            WeaponType.AXE -> {
                part(11f, 0f, z, 24f, 2.2f, 2.2f, brown)
                part(21f, 0f, z - 1f, 6f, 13f, 4f, m)
            }
            WeaponType.SPEAR -> {
                part(17f, 0f, z, 42f, 2f, 2f, brown)
                part(40f, 0f, z - 0.3f, 8f, 3.6f, 2.6f, m)
            }
            WeaponType.DAGGER -> {
                part(1.5f, 0f, z, 4f, 2f, 2f, brown)
                part(8.5f, 0f, z, 11f, 2.6f, 2f, m)
            }
            WeaponType.HAMMER -> {
                part(13f, 0f, z, 28f, 2.4f, 2.4f, brown)
                part(27f, 0f, z - 4f, 10f, 14f, 10f, m)
            }
            WeaponType.RAPIER -> {
                part(1.5f, 0f, z, 5f, 2f, 2f, brown)
                part(4f, 0f, z - 0.3f, 2f, 9f, 2.6f, gold)
                part(22f, 0f, z + 0.2f, 36f, 1.6f, 1.6f, m)
            }
            WeaponType.SCYTHE -> {
                part(17f, 0f, z, 36f, 2.2f, 2.2f, brown)
                part(34f, 0f, z - 0.5f, 3f, 18f, 3f, m)
                part(36f, 8.5f, z - 0.5f, 6f, 3f, 3f, m)
            }
            WeaponType.CLAYMORE -> {
                part(2.5f, 0f, z, 6f, 2.4f, 2.4f, brown)
                part(5.5f, 0f, z - 0.6f, 2f, 11f, 3.4f, gold)
                part(21f, 0f, z - 0.2f, 30f, 5.2f, 2.8f, m)
            }
            WeaponType.HALBERD -> {
                part(20f, 0f, z, 44f, 2.2f, 2.2f, brown)
                part(36f, 0f, z - 1f, 8f, 12f, 3.6f, m)
                part(46f, 0f, z, 6f, 2.6f, 2.6f, m)
            }
            WeaponType.MACE -> {
                part(9f, 0f, z, 20f, 2.4f, 2.4f, brown)
                part(21f, 0f, z - 3f, 8f, 8f, 8f, m)
                part(21f, 0f, z + 5f, 2.4f, 2.4f, 3f, m)
            }
            WeaponType.STAFF -> {
                part(14f, 0f, z, 32f, 2.4f, 2.4f, brown)
                part(31f, 0f, z - 2f, 5.5f, 5.5f, 5.5f, cc(0xFFCE93D8))
                val ox = fx + 31f * fca
                val oy = fy + 31f * fsa
                glow(ox, oy, z + 1f, 8f, cc(0xFFCE93D8), 0.30f + 0.15f * sin(g.time * 8f))
            }
        }
    }

    // ------------------------------------------------------------------ inimigos

    private fun drawEnemy3D(e: Enemy) {
        val pl = g.player
        val ang = atan2(pl.y - e.y, pl.x - e.x)
        val fog = fogAt(e.x, e.y)
        val r = e.type.radius
        groundOval(e.x, e.y, r * 1.15f, 0x55000000)
        // avisos de ataque no chao
        if (e.type == EType.MOSS && e.st == 1) {
            val a = 0.35f + 0.4f * (1f - e.stT / 0.45f)
            groundRing(e.x, e.y, 30f, withA(cc(0xFFFF5252), a), 2f * d)
        } else if (e.type == EType.BOSS) {
            if (e.st == 1) {
                val a = 0.2f + 0.3f * (1f - e.stT / 0.8f)
                groundRect(e.x, e.y, atan2(e.dy, e.dx), 170f, 14f, withA(cc(0xFFFF5252), a))
            } else if (e.st == 4) {
                groundRing(e.x, e.y, (1f - e.stT / 0.7f) * 60f, withA(cc(0xFFFF8A65), 0.7f), 3f * d)
            }
        }
        flashOn = e.flash > 0f
        frame(e.x, e.y, ang, fog)
        var top = 24f
        when (e.type) {
            EType.MOSS -> {
                val bob = sin(e.anim * 8f) * 2.2f
                val body = cc(0xFF4E7D3A)
                val legc = cc(0xFF2E4A22)
                val armZ = if (e.st == 1) 19f else 13f
                part(bob, 3.5f, 0f, 5f, 5f, 8f, legc)
                part(-bob, -3.5f, 0f, 5f, 5f, 8f, legc)
                part(0f, 0f, 8f, 8f, 12f, 11f, body)
                part(-0.5f, -2f, 19f, 5f, 5f, 1.2f, cc(0xFF3B6B2A))
                part(7f, 7.5f, armZ, 11f, 3.6f, 3.6f, body)
                part(7f, -7.5f, armZ, 11f, 3.6f, 3.6f, body)
                part(0f, 0f, 19f, 9f, 9f, 9f, cc(0xFF5E8F45))
                part(0f, 0f, 28f, 9.6f, 9.6f, 1.8f, cc(0xFF3B6B2A))
                part(4.6f, 2.3f, 23f, 0.8f, 1.7f, 1.9f, cc(0xFFFF5252))
                part(4.6f, -2.3f, 23f, 0.8f, 1.7f, 1.9f, cc(0xFFFF5252))
                top = 31f
            }
            EType.ARCHER -> {
                val bone = cc(0xFFD8D4C4)
                part(0f, 2.2f, 0f, 3f, 3f, 9f, bone)
                part(0f, -2.2f, 0f, 3f, 3f, 9f, bone)
                part(0f, 0f, 9f, 5f, 8f, 9f, bone)
                part(0f, 0f, 12f, 5.4f, 8.4f, 1.2f, cc(0xFF9E9A8A))
                part(0f, 0f, 15f, 5.4f, 8.4f, 1.2f, cc(0xFF9E9A8A))
                part(0f, -5.5f, 10f, 2.8f, 2.8f, 8f, bone)
                part(5f, 5.5f, 12f, 8f, 2.8f, 2.8f, bone)
                part(0f, 0f, 18f, 7f, 7f, 7f, cc(0xFFEFEBDC))
                part(3.6f, 1.8f, 21f, 0.8f, 1.6f, 1.8f, cc(0xFF263238))
                part(3.6f, -1.8f, 21f, 0.8f, 1.6f, 1.8f, cc(0xFF263238))
                part(9f, 5.5f, 7f, 2f, 1.6f, 14f, cc(0xFF8D6E63))
                if (e.st == 1) {
                    groundRect(e.x, e.y, ang, 140f, 1.5f, withA(cc(0xFFFF5252), 0.35f))
                }
                top = 27f
            }
            EType.GLOOP -> {
                val sq = 1f + 0.15f * sin(e.anim * 8f)
                val hop = abs(sin(e.anim * 6f)) * 4f
                val s1 = 14f * sq
                val hg = 13f / sq
                part(0f, 0f, hop, s1, s1, hg, cc(0xFF3FBFA0))
                part(0f, 0f, hop + hg - 2.4f, s1 * 0.82f, s1 * 0.82f, 2.4f, cc(0xFF7FFFD4))
                part(s1 / 2f + 0.2f, 3f, hop + hg * 0.5f, 0.8f, 2f, 2.6f, cc(0xFF004D40))
                part(s1 / 2f + 0.2f, -3f, hop + hg * 0.5f, 0.8f, 2f, 2.6f, cc(0xFF004D40))
                top = hop + hg + 3f
            }
            EType.BOSS -> {
                val stunned = e.st == 3
                val body = if (stunned) cc(0xFFA58CCB) else cc(0xFF7A5CA8)
                val dk = cc(0xFF4A3470)
                val glowc = cc(0xFFFF6D00)
                val bob = if (e.st == 0) sin(e.anim * 6f) * 1.6f else 0f
                part(bob, 7f, 0f, 9f, 9f, 14f, dk)
                part(-bob, -7f, 0f, 9f, 9f, 14f, dk)
                part(0f, 0f, 14f, 16f, 28f, 22f, body)
                part(8.2f, -5f, 20f, 0.8f, 2f, 12f, glowc)
                part(8.2f, 6f, 16f, 0.8f, 2f, 12f, glowc)
                part(8.2f, 0f, 24f, 0.8f, 8f, 2f, glowc)
                part(0f, -18f, 14f, 9f, 9f, 24f, body)
                part(0f, 18f, 14f, 9f, 9f, 24f, body)
                part(0f, -18f, 36f, 10f, 10f, 5f, dk)
                part(0f, 18f, 36f, 10f, 10f, 5f, dk)
                part(0f, 0f, 36f, 15f, 15f, 14f, cc(0xFF8D6CC0))
                part(0f, -7f, 49f, 3f, 3f, 9f, dk)
                part(0f, 7f, 49f, 3f, 3f, 9f, dk)
                part(7.7f, 3.5f, 43f, 0.8f, 4f, 3f, cc(0xFFFFA000))
                part(7.7f, -3.5f, 43f, 0.8f, 4f, 3f, cc(0xFFFFA000))
                top = 60f
            }
        }
        flashOn = false
        if (e.burn > 0f) {
            val tt = g.time * 18f
            for (k in 0 until 3) {
                val ox = e.x + sin(tt + k * 2.1f) * r * 0.7f
                val oy = e.y + cos(tt * 0.8f + k * 1.7f) * r * 0.7f
                val col = if (((tt + k).toInt() and 1) == 0) cc(0xFFFF7043) else cc(0xFFFFD54F)
                box(ox, oy, top * 0.4f + k * 4f + (tt % 3f), 3f, 3f, 4f, 0f, col, 1f)
            }
        }
        if (e.stun > 0f) {
            for (k in 0 until 3) {
                val a = g.time * 6f + k * 2.0944f
                box(e.x + cos(a) * 9f, e.y + sin(a) * 9f, top + 4f, 2.6f, 2.6f, 2.6f, 0f, cc(0xFFFFEB3B), 1f)
            }
        }
        if (e.type == EType.BOSS) return
        if (e.hp < e.maxHp) hpBar(e.x, e.y, top + 6f, e.hp / e.maxHp, 24f * d)
    }

    // ------------------------------------------------------------------ HUD

    private fun drawBtn(c: Canvas, b: Btn, label: String, col: Int, frac: Float, sub: String?) {
        circle(c, b.cx, b.cy, b.r, withA(col, 0.45f))
        if (frac > 0f) {
            paint.style = Paint.Style.FILL
            paint.color = cc(0x99000000)
            rf.set(b.cx - b.r, b.cy - b.r, b.cx + b.r, b.cy + b.r)
            c.drawArc(rf, -90f, 360f * frac.coerceIn(0f, 1f), true, paint)
        }
        circle(c, b.cx, b.cy, b.r, withA(white, 0.6f), 2 * d)
        val size = if (b.r > 40 * d) 15 * d else 11 * d
        txt(c, label, b.cx, b.cy + size * 0.35f, size, white, Paint.Align.CENTER)
        if (sub != null) {
            txt(c, sub, b.cx + b.r * 0.62f, b.cy - b.r * 0.5f, 12 * d, gold, Paint.Align.CENTER)
        }
    }

    private fun drawHud(c: Canvas, w: Int, h: Int) {
        val p = g.player
        val wf = w.toFloat()
        val hf = h.toFloat()

        val bx = 12 * d
        val by = 12 * d
        val bw = 170 * d
        fr(c, bx - 2 * d, by - 2 * d, bx + bw + 2 * d, by + 26 * d, cc(0x99000000))
        fr(c, bx, by, bx + bw * (p.hp / p.maxHp).coerceIn(0f, 1f), by + 14 * d, cc(0xFFE53935))
        txt(c, "${p.hp.toInt().coerceAtLeast(0)}/${p.maxHp.toInt()}", bx + 6 * d, by + 11.5f * d, 11 * d, white)
        fr(c, bx, by + 17 * d, bx + bw * (p.xp.toFloat() / p.xpNeed()).coerceIn(0f, 1f), by + 23 * d, cc(0xFF42A5F5))
        txt(c, "Nv ${p.level}", bx + bw + 10 * d, by + 14 * d, 14 * d, gold)
        txt(c, "Gemas ${p.gems}   Poções ${p.potions}   Flechas ${p.arrows}", bx, by + 42 * d, 11 * d, white)
        val wl = p.weapon.name + (if (p.weapon.affix > 0) " - " + p.weapon.affixName else "")
        txt(c, wl, bx, by + 57 * d, 11 * d, p.weapon.rarity.color)

        if (g.bannerT > 0f) {
            val a = min(1f, g.bannerT)
            txt(c, g.banner, wf / 2f + 2 * d, hf * 0.22f + 2 * d, 22 * d, withA(cc(0xFF000000), a), Paint.Align.CENTER)
            txt(c, g.banner, wf / 2f, hf * 0.22f, 22 * d, withA(white, a), Paint.Align.CENTER)
        }

        val bs = g.boss
        if (bs != null && !bs.dead && bs.aggro) {
            val bwid = min(300 * d, wf * 0.35f)
            val l = wf / 2f - bwid / 2f
            val t = hf - 26 * d
            fr(c, l - 2 * d, t - 2 * d, l + bwid + 2 * d, t + 12 * d, cc(0xAA000000))
            fr(c, l, t, l + bwid * (bs.hp / bs.maxHp).coerceIn(0f, 1f), t + 10 * d, cc(0xFF8E24AA))
            txt(c, EType.BOSS.label, wf / 2f, t - 5 * d, 11 * d, white, Paint.Align.CENTER)
        }

        // minimapa
        if (g.seenDirty) {
            g.seenDirty = false
            for (i in miniPix.indices) {
                miniPix[i] = if (!g.seen[i]) 0 else if (g.map[i] != 0) cc(0xCCB0BEC5) else cc(0x55222222)
            }
            miniBmp.setPixels(miniPix, 0, Game.MW, 0, 0, Game.MW, Game.MH)
        }
        val ms = 84 * d
        val mr = wf - 56 * d - 8 * d
        val mt = 12 * d
        mrect.set(mr - ms, mt, mr, mt + ms)
        fr(c, mrect.left, mrect.top, mrect.right, mrect.bottom, cc(0x88000000))
        c.save()
        c.clipRect(mrect)
        c.translate(mrect.centerX(), mrect.centerY())
        c.rotate(deg(yaw))
        val pxm = (p.x / Game.T) / Game.MW * ms * 2f
        val pym = (p.y / Game.T) / Game.MH * ms * 2f
        c.translate(-pxm, -pym)
        rf.set(0f, 0f, ms * 2f, ms * 2f)
        c.drawBitmap(miniBmp, null, rf, bmpPaint)
        if (g.exitOpen && g.seen[idx(g.exitX, g.exitY)]) {
            val ex = (g.exitX / Game.T) / Game.MW * ms * 2f
            val ey = (g.exitY / Game.T) / Game.MH * ms * 2f
            fr(c, ex - 2 * d, ey - 2 * d, ex + 2 * d, ey + 2 * d, cc(0xFFB388FF))
        }
        c.restore()
        fr(c, mrect.centerX() - 2 * d, mrect.centerY() - 2 * d, mrect.centerX() + 2 * d, mrect.centerY() + 2 * d, white)

        if (g.state != State.PLAY) return

        drawBtn(c, bInv, "INV", cc(0xFF455A64), 0f, null)
        drawBtn(c, bRotL, "<", cc(0xFF546E7A), 0f, null)
        drawBtn(c, bRotR, ">", cc(0xFF546E7A), 0f, null)
        val acd = p.weapon.wtype?.cooldown ?: 0.35f
        drawBtn(c, bAtk, "ATQ", cc(0xFFD32F2F), p.atkCd / acd, null)
        drawBtn(c, bRoll, "ROL", cc(0xFF1976D2), p.rollCd / 0.8f, null)
        drawBtn(c, bBow, "ARC", cc(0xFF6D4C41), if (p.arrows <= 0) 1f else p.bowCd / 0.45f, "${p.arrows}")
        drawBtn(c, bPot, "POC", cc(0xFF388E3C), if (p.potions <= 0 || p.hp >= p.maxHp) 1f else 0f, "${p.potions}")

        if (joyPtr != -1) {
            circle(c, joyBX, joyBY, 48 * d, withA(white, 0.12f))
            circle(c, joyBX, joyBY, 48 * d, withA(white, 0.35f), 2 * d)
            circle(c, joyX, joyY, 22 * d, withA(white, 0.45f))
        } else {
            circle(c, 90 * d, hf - 90 * d, 48 * d, withA(white, 0.10f), 2 * d)
        }
    }

    // ------------------------------------------------------------------ telas sobrepostas

    private fun drawSimpleBtn(c: Canvas, r: RectF, label: String, enabled: Boolean) {
        paint.style = Paint.Style.FILL
        paint.color = if (enabled) cc(0xFF2E7D32) else cc(0xFF3A3F3A)
        c.drawRoundRect(r, 6 * d, 6 * d, paint)
        txt(c, label, r.centerX(), r.centerY() + 4.5f * d, 13 * d, if (enabled) white else cc(0xFF78807A), Paint.Align.CENTER)
    }

    private fun drawInventory(c: Canvas, w: Int, h: Int) {
        val p = g.player
        fr(c, 0f, 0f, w.toFloat(), h.toFloat(), cc(0xAA000000))
        paint.style = Paint.Style.FILL
        paint.color = cc(0xF01B1F1B)
        c.drawRoundRect(invPanel, 10 * d, 10 * d, paint)
        txt(c, "Mochila", invPanel.left + 12 * d, invPanel.top + 30 * d, 20 * d, white)

        val lx = invPanel.left + 12 * d
        var ly = invPanel.top + 54 * d
        txt(c, "Arma equipada", lx, ly, 10 * d, grey)
        ly += 14 * d
        txt(c, p.weapon.name, lx, ly, 13 * d, p.weapon.rarity.color)
        ly += 14 * d
        txt(c, p.weapon.stat, lx, ly, 11 * d, white)
        if (p.weapon.affix > 0) {
            ly += 13 * d
            txt(c, p.weapon.affixName, lx, ly, 11 * d, gold)
        }
        ly += 20 * d
        txt(c, "Armadura", lx, ly, 10 * d, grey)
        ly += 14 * d
        val ar = p.armor
        if (ar != null) {
            txt(c, ar.name, lx, ly, 13 * d, ar.rarity.color)
            ly += 14 * d
            txt(c, ar.stat, lx, ly, 11 * d, white)
        } else {
            txt(c, "Nenhuma", lx, ly, 13 * d, grey)
            ly += 14 * d
        }
        ly += 18 * d
        txt(c, "Nível ${p.level}   Vida ${p.hp.toInt()}/${p.maxHp.toInt()}", lx, ly, 11 * d, white)
        ly += 15 * d
        txt(c, "Gemas ${p.gems}   Poções ${p.potions}/5", lx, ly, 11 * d, white)

        val bag = p.bag
        val valid = sel >= 0 && sel < bag.size
        drawSimpleBtn(c, invEquip, "Equipar", valid)
        drawSimpleBtn(c, invSell, if (valid) "Vender ${bag[sel].sellPrice}" else "Vender", valid)
        drawSimpleBtn(c, invBuy, "Poção (30 gemas)", p.gems >= 30 && p.potions < 5)
        drawSimpleBtn(c, invClose, "Continuar", true)

        txt(c, "Itens (${bag.size}/12)", cards[0].left, invPanel.top + 30 * d, 13 * d, grey)
        for (i in 0 until 12) {
            val r = cards[i]
            paint.style = Paint.Style.FILL
            if (i < bag.size) {
                val it = bag[i]
                paint.color = if (i == sel) cc(0xFF34403A) else cc(0xFF262B26)
                c.drawRoundRect(r, 6 * d, 6 * d, paint)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = if (i == sel) 3 * d else 1.5f * d
                paint.color = it.rarity.color
                c.drawRoundRect(r, 6 * d, 6 * d, paint)
                txt(c, it.title, r.left + 8 * d, r.top + 17 * d, 13 * d, it.rarity.color)
                txt(c, it.suffix, r.left + 8 * d, r.top + 31 * d, 11 * d, white)
                txt(c, it.stat, r.left + 8 * d, r.top + 44 * d, 10 * d, grey)
                if (it.affix > 0) txt(c, it.affixName, r.left + 8 * d, r.top + 57 * d, 10 * d, gold)
            } else {
                paint.color = cc(0xFF1F231F)
                c.drawRoundRect(r, 6 * d, 6 * d, paint)
            }
        }
    }

    private fun drawEnd(c: Canvas, w: Int, h: Int, win: Boolean) {
        val p = g.player
        val wf = w.toFloat()
        val hf = h.toFloat()
        fr(c, 0f, 0f, wf, hf, cc(0xAA000000))
        txt(
            c, if (win) "VITÓRIA!" else "VOCÊ CAIU!", wf / 2f, hf * 0.34f, 44 * d,
            if (win) gold else cc(0xFFEF5350), Paint.Align.CENTER
        )
        txt(
            c, "Fase ${g.level}   Nível ${p.level}   Gemas ${p.gems}   Inimigos ${p.kills}",
            wf / 2f, hf * 0.5f, 15 * d, white, Paint.Align.CENTER
        )
        if (g.stateT > 0.8f) {
            val pulse = 0.55f + 0.45f * sin(g.stateT * 3f)
            txt(c, "Toque para voltar ao menu", wf / 2f, hf * 0.68f, 18 * d, withA(white, pulse), Paint.Align.CENTER)
        }
    }
}
