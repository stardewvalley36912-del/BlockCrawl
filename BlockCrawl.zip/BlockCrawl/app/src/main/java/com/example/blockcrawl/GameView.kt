package com.example.blockcrawl

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

private fun cc(v: Long): Int = v.toInt()

private fun withA(col: Int, a: Float): Int =
    (col and 0x00FFFFFF) or ((a.coerceIn(0f, 1f) * 255f).toInt() shl 24)

private fun deg(r: Float): Float = r * 57.29578f

class GameView(ctx: Context) : View(ctx) {

    private class Theme(val floorA: Int, val floorB: Int, val wallTop: Int, val wallFace: Int, val bg: Int)

    private class Btn {
        var cx = 0f
        var cy = 0f
        var r = 0f
        fun set(x: Float, y: Float, radius: Float) {
            cx = x
            cy = y
            r = radius
        }

        fun hit(x: Float, y: Float): Boolean = hypot(x - cx, y - cy) <= r * 1.2f
    }

    private val g = Game()
    private val density = resources.displayMetrics.density
    private var d = density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint().apply { isFilterBitmap = false }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }
    private val rf = RectF()
    private val mrect = RectF()
    private var last = System.nanoTime()
    private var running = true
    private var menuT = 0f

    private val white = cc(0xFFFFFFFF)
    private val grey = cc(0xFFB0BEC5)
    private val gold = cc(0xFFFFD54F)

    private val themes = arrayOf(
        Theme(cc(0xFFE6D29A), cc(0xFFDFC98E), cc(0xFF8D8F94), cc(0xFF6F7177), cc(0xFF0B1A2A)),
        Theme(cc(0xFF6E8665), cc(0xFF647C5B), cc(0xFF3E4D3B), cc(0xFF2C392A), cc(0xFF0B0E0B)),
        Theme(cc(0xFF8C5C54), cc(0xFF82544D), cc(0xFF573229), cc(0xFF3C1F1A), cc(0xFF0F0605)),
        Theme(cc(0xFF6E669C), cc(0xFF635C90), cc(0xFF3E3763), cc(0xFF2B2449), cc(0xFF08060F)),
        Theme(cc(0xFF72B456), cc(0xFF69AA4E), cc(0xFF8D8F94), cc(0xFF6F7177), cc(0xFF0B1A2A))
    )

    private val bAtk = Btn()
    private val bRoll = Btn()
    private val bBow = Btn()
    private val bPot = Btn()
    private val bInv = Btn()
    private val bRotL = Btn()
    private val bRotR = Btn()
    private val bAct = Btn()
    private val menuPlay = RectF()
    private val menuNew = RectF()
    private var newConfirm = 0f
    private var camPtr = -1
    private var camLastX = 0f

    private var joyPtr = -1
    private var atkPtr = -1
    private var joyBX = 0f
    private var joyBY = 0f
    private var joyX = 0f
    private var joyY = 0f

    private val invPanel = RectF()
    private val invClose = RectF()
    private val invBuy = RectF()
    private val invMyst = RectF()
    private val invEquip = RectF()
    private val invSell = RectF()
    private val cards = Array(12) { RectF() }
    private var sel = -1

    private val miniBmp: Bitmap = Bitmap.createBitmap(Game.MW, Game.MH, Bitmap.Config.ARGB_8888)
    private val miniPix = IntArray(Game.MW * Game.MH)

    // ------------------------------------------------------------------ ciclo de vida

    fun pauseGame() {
        running = false
        releaseAll()
        if (g.state == State.PLAY) g.openInventory()
    }

    fun resumeGame() {
        last = System.nanoTime()
        running = true
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val wf = w.toFloat()
        val hf = h.toFloat()
        d = density * min(1f, h / (360f * density))

        bAtk.set(wf - 80 * d, hf - 80 * d, 44 * d)
        bRoll.set(wf - 165 * d, hf - 52 * d, 30 * d)
        bBow.set(wf - 150 * d, hf - 128 * d, 28 * d)
        bPot.set(wf - 68 * d, hf - 160 * d, 28 * d)
        bInv.set(wf - 34 * d, 34 * d, 22 * d)
        bRotL.set(wf - 62 * d, 128 * d, 18 * d)
        bRotR.set(wf - 24 * d, 128 * d, 18 * d)
        bAct.set(wf - 238 * d, hf - 124 * d, 30 * d)
        menuPlay.set(wf / 2f - 110 * d, hf * 0.52f, wf / 2f + 110 * d, hf * 0.52f + 40 * d)
        menuNew.set(wf / 2f - 110 * d, hf * 0.52f + 48 * d, wf / 2f + 110 * d, hf * 0.52f + 84 * d)

        val m = 10 * d
        invPanel.set(m, m, wf - m, hf - m)
        val leftW = (wf - 2 * m) * 0.36f
        val bx = invPanel.left + 12 * d
        val bw = leftW - 12 * d
        val bh = 30 * d
        invClose.set(bx, invPanel.bottom - 12 * d - bh, bx + bw, invPanel.bottom - 12 * d)
        invBuy.set(bx, invClose.top - 6 * d - bh, bx + bw, invClose.top - 6 * d)
        invMyst.set(bx, invBuy.top - 6 * d - bh, bx + bw, invBuy.top - 6 * d)
        val half = (bw - 8 * d) / 2f
        invEquip.set(bx, invMyst.top - 6 * d - bh, bx + half, invMyst.top - 6 * d)
        invSell.set(bx + half + 8 * d, invEquip.top, bx + bw, invEquip.bottom)

        val gx = invPanel.left + leftW + 12 * d
        val gy = invPanel.top + 44 * d
        val gw = invPanel.right - 12 * d - gx
        val gh = invPanel.bottom - 12 * d - gy
        val gap = 8 * d
        val cw = (gw - 2 * gap) / 3f
        val ch = (gh - 3 * gap) / 4f
        for (i in 0 until 12) {
            val col = i % 3
            val row = i / 3
            val l = gx + col * (cw + gap)
            val t = gy + row * (ch + gap)
            cards[i].set(l, t, l + cw, t + ch)
        }
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        var dt = (now - last) / 1_000_000_000f
        last = now
        if (dt > 0.05f) dt = 0.05f
        frameDt = dt
        if (running) {
            g.update(dt)
            menuT += dt
        }
        render(c)
        postInvalidateOnAnimation()
    }

    // ------------------------------------------------------------------ entrada

    private fun releaseAll() {
        camPtr = -1
        joyPtr = -1
        atkPtr = -1
        g.moveX = 0f
        g.moveY = 0f
        g.attackHeld = false
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = ev.actionIndex
                onDown(ev.getPointerId(i), ev.getX(i), ev.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until ev.pointerCount) onMove(ev.getPointerId(i), ev.getX(i), ev.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> onUp(ev.getPointerId(ev.actionIndex))
            MotionEvent.ACTION_CANCEL -> releaseAll()
        }
        return true
    }

    private fun onDown(id: Int, x: Float, y: Float) {
        when (g.state) {
            State.MENU -> menuTouch(x, y)
            State.CUT -> if (g.stateT > 0.15f) g.advanceCut()
            State.WORLD -> worldTouch(x, y)
            State.DEAD, State.WIN -> {
                if (g.stateT > 0.8f) {
                    releaseAll()
                    g.afterEnd()
                }
            }
            State.INV -> invTouch(x, y)
            State.PLAY -> playTouch(id, x, y)
        }
    }

    private fun playTouch(id: Int, x: Float, y: Float) {
        if (bInv.hit(x, y)) {
            releaseAll()
            sel = -1
            g.openInventory()
            return
        }
        if (g.near != null && bAct.hit(x, y)) {
            g.interact()
            return
        }
        if (bRotL.hit(x, y)) {
            yawT -= 0.7853982f
            return
        }
        if (bRotR.hit(x, y)) {
            yawT += 0.7853982f
            return
        }
        if (bAtk.hit(x, y)) {
            atkPtr = id
            g.attackHeld = true
            return
        }
        if (bRoll.hit(x, y)) {
            g.doRoll()
            return
        }
        if (bBow.hit(x, y)) {
            g.shootBow()
            return
        }
        if (bPot.hit(x, y)) {
            g.usePotion()
            return
        }
        if (x >= width * 0.5f && camPtr == -1) {
            camPtr = id
            camLastX = x
            return
        }
        if (x < width * 0.5f && joyPtr == -1) {
            joyPtr = id
            joyBX = x
            joyBY = y
            joyX = x
            joyY = y
            g.moveX = 0f
            g.moveY = 0f
        }
    }

    private fun onMove(id: Int, x: Float, y: Float) {
        if (id == camPtr && g.state == State.PLAY) {
            val dxm = x - camLastX
            camLastX = x
            yawT += dxm * 0.008f
            yaw += dxm * 0.008f
        }
        if (id == joyPtr && g.state == State.PLAY) {
            val dx = x - joyBX
            val dy = y - joyBY
            val len = hypot(dx, dy)
            val r = 48 * d
            val k = if (len > r) r / len else 1f
            joyX = joyBX + dx * k
            joyY = joyBY + dy * k
            val jx = dx * k / r
            val jy = dy * k / r
            g.moveX = jx * cYaw + jy * sYaw
            g.moveY = jy * cYaw - jx * sYaw
        }
    }

    private fun onUp(id: Int) {
        if (id == -1) return
        if (id == joyPtr) {
            joyPtr = -1
            g.moveX = 0f
            g.moveY = 0f
        }
        if (id == atkPtr) {
            atkPtr = -1
            g.attackHeld = false
        }
        if (id == camPtr) camPtr = -1
    }

    private fun invTouch(x: Float, y: Float) {
        val bag = g.player.bag
        val valid = sel >= 0 && sel < bag.size
        if (invClose.contains(x, y)) {
            g.closeInventory()
            return
        }
        if (invBuy.contains(x, y)) {
            g.buyPotion()
            return
        }
        if (invMyst.contains(x, y)) {
            g.buyMystery()
            return
        }
        if (invEquip.contains(x, y) && valid) {
            g.equip(sel)
            sel = -1
            return
        }
        if (invSell.contains(x, y) && valid) {
            g.sell(sel)
            sel = -1
            return
        }
        for (i in cards.indices) {
            if (cards[i].contains(x, y)) {
                sel = if (i < bag.size) i else -1
                return
            }
        }
    }

    // ------------------------------------------------------------------ helpers de desenho

    private fun fr(c: Canvas, l: Float, t: Float, r: Float, b: Float, col: Int) {
        paint.style = Paint.Style.FILL
        paint.color = col
        c.drawRect(l, t, r, b, paint)
    }

    private fun sr(c: Canvas, l: Float, t: Float, r: Float, b: Float, col: Int, w: Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = w
        paint.color = col
        c.drawRect(l, t, r, b, paint)
    }

    private fun oval(c: Canvas, cx: Float, cy: Float, rx: Float, ry: Float, col: Int) {
        paint.style = Paint.Style.FILL
        paint.color = col
        rf.set(cx - rx, cy - ry, cx + rx, cy + ry)
        c.drawOval(rf, paint)
    }

    private fun circle(c: Canvas, cx: Float, cy: Float, r: Float, col: Int, stroke: Float = 0f) {
        if (stroke > 0f) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = stroke
        } else {
            paint.style = Paint.Style.FILL
        }
        paint.color = col
        c.drawCircle(cx, cy, r, paint)
    }

    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, col: Int, w: Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = w
        paint.color = col
        c.drawLine(x1, y1, x2, y2, paint)
    }

    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, col: Int, align: Paint.Align = Paint.Align.LEFT) {
        tp.textSize = size
        tp.color = col
        tp.textAlign = align
        c.drawText(s, x, y, tp)
    }

    private fun idx(x: Float, y: Float): Int {
        val tx = floor(x / Game.T).toInt()
        val ty = floor(y / Game.T).toInt()
        if (tx < 0 || ty < 0 || tx >= Game.MW || ty >= Game.MH) return 0
        return ty * Game.MW + tx
    }

    private fun nearFloor(tx: Int, ty: Int): Boolean {
        for (dy in -1..1) {
            for (dx in -1..1) {
                val x = tx + dx
                val y = ty + dy
                if (x < 0 || y < 0 || x >= Game.MW || y >= Game.MH) continue
                if (g.map[y * Game.MW + x] != 0) return true
            }
        }
        return false
    }

    // ------------------------------------------------------------------ render principal

    private fun render(c: Canvas) {
        val w = width
        val h = height
        c.drawColor(cc(0xFF000000))
        if (g.state == State.MENU) {
            drawMenu(c, w, h)
            return
        }
        if (g.state != State.WORLD) worldInit = false
        if (g.state == State.WORLD) {
            drawMap(c, w, h)
            return
        }
        drawWorld(c, w, h)
        drawHud(c, w, h)
        when (g.state) {
            State.INV -> drawInventory(c, w, h)
            State.CUT -> drawCut(c, w, h)
            State.DEAD -> drawEnd(c, w, h, false)
            State.WIN -> drawEnd(c, w, h, true)
            else -> {}
        }
    }

    private fun drawMenu(c: Canvas, w: Int, h: Int) {
        val wf = w.toFloat()
        val hf = h.toFloat()
        c.drawColor(cc(0xFF0B0E0B))
        val bs = 28 * d
        var ty = 0
        var y = 0f
        while (y < hf) {
            var tx = 0
            var x = 0f
            while (x < wf) {
                if ((tx * 7 + ty * 13) % 5 == 0) {
                    fr(c, x, y, x + bs, y + bs, if ((tx + ty) % 2 == 0) cc(0xFF121A12) else cc(0xFF0F150F))
                }
                x += bs
                tx++
            }
            y += bs
            ty++
        }
        val cx = wf / 2f
        txt(c, "BLOCKCRAWL", cx + 4 * d, hf * 0.34f + 4 * d, 56 * d, cc(0xFF1B5E20), Paint.Align.CENTER)
        txt(c, "BLOCKCRAWL", cx, hf * 0.34f, 56 * d, cc(0xFF8BC34A), Paint.Align.CENTER)
        txt(c, "Masmorras de Blocos em 3D", cx, hf * 0.34f + 28 * d, 18 * d, grey, Paint.Align.CENTER)
        if (newConfirm > 0f) newConfirm -= frameDt
        drawSimpleBtn(c, menuPlay, if (g.started) "Continuar" else "Jogar", true)
        if (g.started) drawSimpleBtn(c, menuNew, if (newConfirm > 0f) "Toque de novo: apagar tudo" else "Novo jogo", true)
        txt(c, "Esquerda: mover   |   Arraste na direita ou use < >: girar a câmera", cx, hf * 0.76f, 13 * d, grey, Paint.Align.CENTER)
        txt(c, "ROL: rolar (invencível)   ARC: arco   POC: poção   INV: mochila", cx, hf * 0.76f + 20 * d, 13 * d, grey, Paint.Align.CENTER)
        txt(c, "Acampamento, mapa-múndi, 4 missões, 11 armas e o Guardião de Obsidiana", cx, hf * 0.76f + 40 * d, 13 * d, grey, Paint.Align.CENTER)
    }

    private fun menuTouch(x: Float, y: Float) {
        if (g.stateT < 0.3f) return
        if (menuPlay.contains(x, y)) {
            releaseAll()
            if (g.started) {
                g.state = State.PLAY
                g.stateT = 0f
            } else g.newGame()
        } else if (g.started && menuNew.contains(x, y)) {
            if (newConfirm > 0f) {
                newConfirm = 0f
                releaseAll()
                g.newGame()
            } else newConfirm = 3f
        }
    }

    // ------------------------------------------------------------------ mundo 3D

    private class DrawItem {
        var kind = 0
        var ref: Any? = null
        var key = 0f
        var ix = 0
        var iy = 0
    }

    private var yaw = 0.62f
    private var yawT = 0.62f
    private var cYaw = cos(0.62f)
    private var sYaw = sin(0.62f)
    private var faceAng = -0.62f
    private val PITCH = 0.96f
    private val SPN = sin(PITCH)
    private val CPN = cos(PITCH)
    private val WALL_H = 46f
    private val PI_F = 3.1415927f

    private var camX = 0f
    private var camY = 0f
    private var scl = 3f
    private var ocx = 0f
    private var ocy = 0f
    private var frameDt = 0.016f
    private lateinit var cv: Canvas
    private val path = Path()
    private val sx4 = FloatArray(4)
    private val sy4 = FloatArray(4)
    private val wx4 = FloatArray(4)
    private val wy4 = FloatArray(4)
    private val items = ArrayList<DrawItem>()
    private var itemCount = 0
    private val itemCmp = Comparator<DrawItem> { a, b -> a.key.compareTo(b.key) }

    private var fx = 0f
    private var fy = 0f
    private var fa = 0f
    private var fca = 1f
    private var fsa = 0f
    private var ffog = 1f
    private var flashOn = false

    private fun projX(x: Float, y: Float): Float = ((x - camX) * cYaw - (y - camY) * sYaw) * scl + ocx

    private fun projY(x: Float, y: Float, z: Float): Float =
        (((x - camX) * sYaw + (y - camY) * cYaw) * SPN - z * CPN) * scl + ocy

    private fun depthKey(x: Float, y: Float): Float = x * sYaw + y * cYaw

    private fun shade(c: Int, f: Float): Int {
        val ff = if (f < 0f) 0f else f
        var r = ((c shr 16) and 255) * ff
        var gg = ((c shr 8) and 255) * ff
        var b = (c and 255) * ff
        if (r > 255f) r = 255f
        if (gg > 255f) gg = 255f
        if (b > 255f) b = 255f
        return (0xFF shl 24) or (r.toInt() shl 16) or (gg.toInt() shl 8) or b.toInt()
    }

    private fun fogAt(x: Float, y: Float): Float {
        val dx = x - camX
        val dy = y - camY
        val dist = sqrt(dx * dx + dy * dy) / Game.T
        val t = ((dist - 6.5f) / 7f).coerceIn(0f, 1f)
        return 1f - t * 0.45f
    }

    private fun onScr(x: Float, y: Float): Boolean {
        val m = Game.T * scl * 2.5f
        val sx = projX(x, y)
        val sy = projY(x, y, 0f)
        return sx > -m && sx < width + m && sy > -m && sy < height + m
    }

    private fun fillQuad(
        x1: Float, y1: Float, x2: Float, y2: Float,
        x3: Float, y3: Float, x4: Float, y4: Float, col: Int
    ) {
        path.reset()
        path.moveTo(x1, y1)
        path.lineTo(x2, y2)
        path.lineTo(x3, y3)
        path.lineTo(x4, y4)
        path.close()
        paint.style = Paint.Style.FILL
        paint.color = col
        cv.drawPath(path, paint)
    }

    /** Retangulo plano no chao (alinhado aos eixos do mundo). */
    private fun flatQuad(xa: Float, ya: Float, xb: Float, yb: Float, z: Float, col: Int) {
        fillQuad(
            projX(xa, ya), projY(xa, ya, z), projX(xb, ya), projY(xb, ya, z),
            projX(xb, yb), projY(xb, yb, z), projX(xa, yb), projY(xa, yb, z), col
        )
    }

    private fun groundOval(x: Float, y: Float, r: Float, col: Int) {
        val sx = projX(x, y)
        val sy = projY(x, y, 0f)
        paint.style = Paint.Style.FILL
        paint.color = col
        rf.set(sx - r * scl, sy - r * scl * SPN, sx + r * scl, sy + r * scl * SPN)
        cv.drawOval(rf, paint)
    }

    private fun groundRing(x: Float, y: Float, r: Float, col: Int, stroke: Float) {
        val sx = projX(x, y)
        val sy = projY(x, y, 1f)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = stroke
        paint.color = col
        rf.set(sx - r * scl, sy - r * scl * SPN, sx + r * scl, sy + r * scl * SPN)
        cv.drawOval(rf, paint)
    }

    private fun groundSector(x: Float, y: Float, a0: Float, a1: Float, r: Float, col: Int) {
        path.reset()
        path.moveTo(projX(x, y), projY(x, y, 3f))
        val n = 10
        for (i in 0..n) {
            val a = a0 + (a1 - a0) * i / n
            val wx = x + cos(a) * r
            val wy = y + sin(a) * r
            path.lineTo(projX(wx, wy), projY(wx, wy, 3f))
        }
        path.close()
        paint.style = Paint.Style.FILL
        paint.color = col
        cv.drawPath(path, paint)
    }

    private fun groundRect(x: Float, y: Float, ang: Float, len: Float, halfW: Float, col: Int) {
        val ca = cos(ang)
        val sa = sin(ang)
        val ax = x - sa * halfW
        val ay = y + ca * halfW
        val bx = x + sa * halfW
        val by = y - ca * halfW
        val cx = bx + ca * len
        val cy = by + sa * len
        val dx = ax + ca * len
        val dy = ay + sa * len
        fillQuad(
            projX(ax, ay), projY(ax, ay, 2f), projX(bx, by), projY(bx, by, 2f),
            projX(cx, cy), projY(cx, cy, 2f), projX(dx, dy), projY(dx, dy, 2f), col
        )
    }

    private fun glow(x: Float, y: Float, z: Float, r: Float, col: Int, a: Float) {
        paint.style = Paint.Style.FILL
        paint.color = withA(col, a)
        cv.drawCircle(projX(x, y), projY(x, y, z), r * scl, paint)
    }

    /** Caixa 3D (prisma) girada em torno do eixo vertical. w = eixo local x, dp = eixo local y. */
    private fun box(
        x: Float, y: Float, z0: Float, w: Float, dp: Float, h: Float,
        ang: Float, col: Int, fog: Float, skip: Int = 0, topCol: Int = 0
    ) {
        val ca = cos(ang)
        val sa = sin(ang)
        val hw = w * 0.5f
        val hd = dp * 0.5f
        wx4[0] = x - hw * ca + hd * sa
        wy4[0] = y - hw * sa - hd * ca
        wx4[1] = x + hw * ca + hd * sa
        wy4[1] = y + hw * sa - hd * ca
        wx4[2] = x + hw * ca - hd * sa
        wy4[2] = y + hw * sa + hd * ca
        wx4[3] = x - hw * ca - hd * sa
        wy4[3] = y - hw * sa + hd * ca
        for (i in 0 until 4) {
            sx4[i] = projX(wx4[i], wy4[i])
            sy4[i] = projY(wx4[i], wy4[i], z0)
        }
        val hh = h * CPN * scl
        for (i in 0 until 4) {
            val nx = when (i) {
                0 -> sa
                1 -> ca
                2 -> -sa
                else -> -ca
            }
            val ny = when (i) {
                0 -> -ca
                1 -> sa
                2 -> ca
                else -> -sa
            }
            if (((skip shr i) and 1) != 0) continue
            if (nx * sYaw + ny * cYaw <= 0.001f) continue
            var f = 0.52f + 0.33f * (nx * 0.95f + ny * 0.31f)
            if (f < 0.4f) f = 0.4f
            if (f > 0.95f) f = 0.95f
            val j = (i + 1) and 3
            fillQuad(
                sx4[i], sy4[i], sx4[j], sy4[j],
                sx4[j], sy4[j] - hh, sx4[i], sy4[i] - hh, shade(col, fog * f)
            )
        }
        fillQuad(
            sx4[0], sy4[0] - hh, sx4[1], sy4[1] - hh,
            sx4[2], sy4[2] - hh, sx4[3], sy4[3] - hh, shade(if (topCol != 0) topCol else col, fog * 1.06f)
        )
    }

    private fun frame(x: Float, y: Float, a: Float, fog: Float) {
        fx = x
        fy = y
        fa = a
        fca = cos(a)
        fsa = sin(a)
        ffog = fog
    }

    /** Peca no referencial atual: ox para frente, oy para a direita do personagem. */
    private fun part(ox: Float, oy: Float, z0: Float, w: Float, dp: Float, h: Float, col: Int) {
        box(
            fx + ox * fca - oy * fsa, fy + ox * fsa + oy * fca,
            z0, w, dp, h, fa, if (flashOn) -1 else col, ffog
        )
    }

    private fun hpBar(x: Float, y: Float, z: Float, frac: Float, wdt: Float) {
        val sx = projX(x, y)
        val sy = projY(x, y, z)
        val hgt = 4f * d
        fr(cv, sx - wdt / 2f - 1f, sy - 1f, sx + wdt / 2f + 1f, sy + hgt + 1f, cc(0xAA000000))
        fr(cv, sx - wdt / 2f, sy, sx - wdt / 2f + wdt * frac.coerceIn(0f, 1f), sy + hgt, cc(0xFFE53935))
    }

    private fun addItem(kind: Int, ref: Any?, key: Float, ix: Int = 0, iy: Int = 0) {
        val di: DrawItem
        if (itemCount < items.size) {
            di = items[itemCount]
        } else {
            di = DrawItem()
            items.add(di)
        }
        di.kind = kind
        di.ref = ref
        di.key = key
        di.ix = ix
        di.iy = iy
        itemCount++
    }

    private fun drawWorld(c: Canvas, w: Int, h: Int) {
        cv = c
        val p = g.player
        val th = themes[g.themeIdx.coerceIn(0, 4)]
        val t = Game.T
        scl = h / (t * 7.6f)
        yaw += (yawT - yaw) * min(1f, 10f * frameDt)
        cYaw = cos(yaw)
        sYaw = sin(yaw)
        faceAng = -yaw
        var shx = 0f
        var shy = 0f
        if (g.shake > 0f) {
            val m = min(1f, g.shake * 4f) * 5f * scl
            shx = (g.rng.nextFloat() - 0.5f) * m
            shy = (g.rng.nextFloat() - 0.5f) * m
        }
        ocx = w / 2f + shx
        ocy = h * 0.56f + shy
        if (hypot(p.x - camX, p.y - camY) > 160f) {
            camX = p.x
            camY = p.y
        } else {
            val k = min(1f, 7f * frameDt)
            camX += (p.x - camX) * k
            camY += (p.y - camY) * k
        }
        c.drawColor(th.bg)

        val rw = ((w * 0.5f) / scl + (h * 0.5f) / (scl * SPN) + 70f) * 0.9f + t
        val tcx = floor(camX / t).toInt()
        val tcy = floor(camY / t).toInt()
        val rt = (rw / t).toInt() + 1
        val tx0 = max(0, tcx - rt)
        val tx1 = min(Game.MW - 1, tcx + rt)
        val ty0 = max(0, tcy - rt)
        val ty1 = min(Game.MH - 1, tcy + rt)

        // 1) chao
        val cullM = t * scl * 1.6f
        for (ty in ty0..ty1) {
            for (tx in tx0..tx1) {
                val i = ty * Game.MW + tx
                if (!g.seen[i] || g.map[i] == 0) continue
                val xa = tx * t
                val ya = ty * t
                val xb = xa + t
                val yb = ya + t
                val csx = projX(xa + t / 2f, ya + t / 2f)
                val csy = projY(xa + t / 2f, ya + t / 2f, 0f)
                if (csx < -cullM || csx > w + cullM || csy < -cullM || csy > h + cullM) continue
                val fog = fogAt(xa + t / 2f, ya + t / 2f)
                drawTerrain(tx, ty, g.map[i].toInt(), xa, ya, xb, yb, fog, th)
            }
        }

        for (pl in g.plates) {
            val pxa = pl.tx * t
            val pya = pl.ty * t
            if (!onScr(pxa + t / 2f, pya + t / 2f) || !g.seen[pl.ty * Game.MW + pl.tx]) continue
            val pf = fogAt(pxa + t / 2f, pya + t / 2f)
            val pc = if (pl.down) cc(0xFF66BB6A) else if (pl.t > 0f) cc(0xFFFFB74D) else cc(0xFFFFC107)
            flatQuad(pxa + 3f, pya + 3f, pxa + t - 3f, pya + t - 3f, 0.4f, shade(cc(0xFF4E4E55), pf))
            flatQuad(pxa + 7f, pya + 7f, pxa + t - 7f, pya + t - 7f, 0.8f, shade(pc, pf))
        }

        // 2) objetos e paredes ordenados por profundidade (algoritmo do pintor)
        itemCount = 0
        for (ch in g.chests) {
            if (g.seen[idx(ch.x, ch.y)] && onScr(ch.x, ch.y)) addItem(0, ch, depthKey(ch.x, ch.y))
        }
        for (pk in g.pickups) {
            if (onScr(pk.x, pk.y)) addItem(1, pk, depthKey(pk.x, pk.y))
        }
        if (g.exitOpen && g.seen[idx(g.exitX, g.exitY)] && onScr(g.exitX, g.exitY)) {
            addItem(5, null, depthKey(g.exitX, g.exitY))
        }
        for (e in g.enemies) {
            if (!e.dead && g.seen[idx(e.x, e.y)] && onScr(e.x, e.y)) addItem(2, e, depthKey(e.x, e.y))
        }
        addItem(3, p, depthKey(p.x, p.y))
        for (pr in g.projs) {
            if (onScr(pr.x, pr.y)) addItem(4, pr, depthKey(pr.x, pr.y))
        }
        for (ty in ty0..ty1) {
            for (tx in tx0..tx1) {
                val i = ty * Game.MW + tx
                if (g.map[i].toInt() != 0 || !g.seen[i] || !nearFloor(tx, ty)) continue
                val cxw = tx * t + t / 2f
                val cyw = ty * t + t / 2f
                if (onScr(cxw, cyw)) addItem(6, null, depthKey(cxw, cyw), tx, ty)
            }
        }
        for (ty in ty0..ty1) {
            for (tx in tx0..tx1) {
                val i = ty * Game.MW + tx
                val dc = g.deco[i].toInt()
                if (dc == 0 || dc == Game.D_BLOCK || !g.seen[i]) continue
                val cxw = tx * t + t / 2f
                val cyw = ty * t + t / 2f
                if (onScr(cxw, cyw)) addItem(7, null, depthKey(cxw, cyw), tx, ty)
            }
        }
        for (sp in g.spots) {
            if (sp.npc && onScr(sp.x, sp.y)) addItem(8, sp, depthKey(sp.x, sp.y))
        }
        if (itemCount > 1) items.subList(0, itemCount).sortWith(itemCmp)

        // 3) desenho
        for (k in 0 until itemCount) drawItem(items[k], th, p)

        // 4) particulas e textos (espaco da tela)
        for (q in g.parts) {
            val a = (q.life / 0.5f).coerceIn(0f, 1f)
            val sx = projX(q.x, q.y)
            val sy = projY(q.x, q.y, q.z)
            val sz = q.size * scl * 0.5f
            paint.style = Paint.Style.FILL
            paint.color = withA(q.color, a)
            c.drawRect(sx - sz, sy - sz, sx + sz, sy + sz, paint)
        }
        for (sp in g.spots) {
            if (!onScr(sp.x, sp.y)) continue
            if (sp.kind >= 4 && g.near !== sp) continue
            val sx = projX(sp.x, sp.y)
            val sy = projY(sp.x, sp.y, 52f)
            val col = if (g.near === sp) gold else white
            txt(c, sp.name, sx + 1f, sy + 1f, 11 * d, cc(0xFF000000), Paint.Align.CENTER)
            txt(c, sp.name, sx, sy, 11 * d, col, Paint.Align.CENTER)
        }
        for (ft in g.texts) {
            val a = (ft.life / 0.4f).coerceIn(0f, 1f)
            val sx = projX(ft.x, ft.y)
            val sy = projY(ft.x, ft.y, ft.z)
            txt(c, ft.text, sx + 1f, sy + 1f, 12 * d, withA(cc(0xFF000000), a), Paint.Align.CENTER)
            txt(c, ft.text, sx, sy, 12 * d, withA(ft.color, a), Paint.Align.CENTER)
        }
    }

    private fun drawWallTile(tx: Int, ty: Int, th: Theme, p: Player) {
        val t = Game.T
        val cxw = tx * t + t / 2f
        val cyw = ty * t + t / 2f
        val hsh = ((tx * 73856093) xor (ty * 19349663)) and 0x7fffffff
        var wallH = WALL_H + (hsh % 5)
        // paredes entre a camera e o jogador ficam baixas para nao esconder o personagem
        val dxp = cxw - p.x
        val dyp = cyw - p.y
        val front = dxp * sYaw + dyp * cYaw
        val side = dxp * cYaw - dyp * sYaw
        if (front > 0f && sqrt(dxp * dxp + dyp * dyp) < t * 3.4f && abs(side) < t * 2.4f) {
            wallH = 12f
        }
        val fog = fogAt(cxw, cyw)
        var skip = 0
        if (g.isWall(tx, ty - 1)) skip = skip or 1
        if (g.isWall(tx + 1, ty)) skip = skip or 2
        if (g.isWall(tx, ty + 1)) skip = skip or 4
        if (g.isWall(tx - 1, ty)) skip = skip or 8
        val top = if (hsh % 7 == 0) shade(th.wallTop, 1.5f) else shade(th.wallTop, 1.3f)
        box(cxw, cyw, 0f, t, t, wallH, 0f, shade(th.wallFace, 1.9f), fog, skip, top)
    }

    private fun drawItem(di: DrawItem, th: Theme, p: Player) {
        when (di.kind) {
            6 -> drawWallTile(di.ix, di.iy, th, p)
            7 -> drawDeco3D(di.ix, di.iy)
            8 -> drawNpc3D(di.ref as Spot)
            0 -> drawChest3D(di.ref as Chest)
            1 -> drawPickup3D(di.ref as Pickup)
            2 -> drawEnemy3D(di.ref as Enemy)
            3 -> drawPlayer3D(di.ref as Player)
            4 -> drawProj3D(di.ref as Projectile)
            else -> drawPortal3D()
        }
    }

    private fun drawChest3D(ch: Chest) {
        val fog = fogAt(ch.x, ch.y)
        groundOval(ch.x, ch.y, 12f, 0x55000000)
        frame(ch.x, ch.y, faceAng, fog)
        if (!ch.opened) {
            part(0f, 0f, 0f, 18f, 10f, 8f, cc(0xFF8D5524))
            part(0f, 0f, 8f, 18f, 10f, 4f, cc(0xFFA9703A))
            part(0f, 5.2f, 6.5f, 3f, 1f, 3.2f, cc(0xFFFFD54F))
        } else {
            part(0f, 0f, 0f, 18f, 10f, 8f, cc(0xFF6D4118))
            part(0f, 0f, 8f, 15f, 7f, 0.6f, cc(0xFF24150A))
            part(0f, -5f, 8f, 18f, 1.6f, 8f, cc(0xFF8A5A2B))
        }
    }

    private fun drawPickup3D(pk: Pickup) {
        val fog = fogAt(pk.x, pk.y)
        val bob = 6f + sin(pk.t * 5f + pk.x) * 1.8f
        groundOval(pk.x, pk.y, 4.5f, 0x44000000)
        frame(pk.x, pk.y, pk.t * 3f, fog)
        when (pk.kind) {
            0 -> {
                part(0f, 0f, bob, 4.5f, 4.5f, 6f, cc(0xFF3DDC84))
                part(0f, 0f, bob + 6f, 2.2f, 2.2f, 1.6f, cc(0xFFB9F6CA))
            }
            1 -> {
                part(0f, 0f, bob, 5f, 5f, 6f, cc(0xFFE53935))
                part(0f, 0f, bob + 6f, 2.6f, 2.6f, 3f, cc(0xFFBDBDBD))
            }
            2 -> {
                part(0f, 0f, bob, 10f, 1.8f, 1.8f, cc(0xFF8D6E63))
                part(5.5f, 0f, bob, 3f, 3f, 2.6f, cc(0xFFE0E0E0))
            }
            4 -> {
                val kc = when (pk.amount) {
                    0 -> cc(0xFFE53935)
                    1 -> cc(0xFF42A5F5)
                    else -> cc(0xFFFFC107)
                }
                val sx = projX(pk.x, pk.y)
                val sy0 = projY(pk.x, pk.y, 0f)
                val sy1 = projY(pk.x, pk.y, 40f)
                paint.style = Paint.Style.FILL
                paint.color = withA(kc, 0.28f)
                cv.drawRect(sx - 3f * scl, sy1, sx + 3f * scl, sy0, paint)
                glow(pk.x, pk.y, bob + 4f, 12f, kc, 0.3f)
                part(0f, 0f, bob, 3f, 3f, 11f, kc)
                part(0f, 0f, bob + 11f, 8f, 3f, 5f, kc)
                part(0f, 0f, bob + 13f, 3f, 3f, 1.4f, cc(0xFF263238))
                part(2.6f, 0f, bob + 1f, 4f, 2f, 2f, kc)
                part(2.6f, 0f, bob + 5f, 3f, 2f, 2f, kc)
            }
            else -> {
                val col = pk.item?.rarity?.color ?: white
                val sx = projX(pk.x, pk.y)
                val sy0 = projY(pk.x, pk.y, 0f)
                val sy1 = projY(pk.x, pk.y, 34f)
                paint.style = Paint.Style.FILL
                paint.color = withA(col, 0.22f)
                cv.drawRect(sx - 3f * scl, sy1, sx + 3f * scl, sy0, paint)
                glow(pk.x, pk.y, bob + 3f, 7f, col, 0.25f)
                part(0f, 0f, bob, 7f, 7f, 7f, col)
            }
        }
    }

    private fun drawPortal3D() {
        val x = g.exitX
        val y = g.exitY
        val fog = fogAt(x, y)
        val tt = g.time
        val pulse = 0.55f + 0.45f * sin(tt * 4f)
        groundOval(x, y, 18f, 0x66000000)
        val lx = cYaw
        val ly = -sYaw
        // vao interno
        val l = 12f
        val top = 30f
        fillQuad(
            projX(x - lx * l, y - ly * l), projY(x - lx * l, y - ly * l, 2f),
            projX(x + lx * l, y + ly * l), projY(x + lx * l, y + ly * l, 2f),
            projX(x + lx * l, y + ly * l), projY(x + lx * l, y + ly * l, top),
            projX(x - lx * l, y - ly * l), projY(x - lx * l, y - ly * l, top),
            withA(cc(0xFFB388FF), pulse)
        )
        glow(x, y, 16f, 16f, cc(0xFFB388FF), 0.18f * pulse)
        val stone = cc(0xFF2A1F44)
        box(x - lx * 14f, y - ly * 14f, 0f, 6f, 6f, 36f, faceAng, stone, fog)
        box(x + lx * 14f, y + ly * 14f, 0f, 6f, 6f, 36f, faceAng, stone, fog)
        box(x, y, 33f, 34f, 6f, 6f, faceAng, cc(0xFF3A2C5C), fog)
        for (k in 0 until 5) {
            val a = tt * 2f + k * 1.2566f
            val zz = 6f + (sin(tt * 3f + k) * 0.5f + 0.5f) * 22f
            val ox = x + lx * cos(a) * 9f
            val oy = y + ly * cos(a) * 9f
            box(ox, oy, zz, 2f, 2f, 2f, 0f, white, 1f)
        }
    }

    private fun drawProj3D(pr: Projectile) {
        val fog = fogAt(pr.x, pr.y)
        groundOval(pr.x, pr.y, 3.5f, 0x44000000)
        if (pr.kind <= 1) {
            frame(pr.x, pr.y, atan2(pr.vy, pr.vx), fog)
            val tip = if (pr.kind == 0) cc(0xFFFFE082) else cc(0xFFFFF59D)
            part(0f, 0f, 11f, 10f, 1.8f, 1.8f, cc(0xFF8D6E63))
            part(5.5f, 0f, 10.8f, 3f, 2.8f, 2.8f, tip)
        } else {
            val sz = pr.radius * 1.8f
            glow(pr.x, pr.y, 11f, pr.radius * 2.6f, pr.color, 0.28f)
            frame(pr.x, pr.y, g.time * 6f, 1f)
            part(0f, 0f, 9f, sz, sz, sz, pr.color)
        }
    }

    // ------------------------------------------------------------------ jogador

    private fun drawPlayer3D(p: Player) {
        if (p.hurt > 0f && ((p.hurt * 40f).toInt() % 2 == 0)) return
        val fog = fogAt(p.x, p.y)
        groundOval(p.x, p.y, 9f, 0x55000000)
        val skin = cc(0xFFF1C27D)
        val blue = cc(0xFF3F6FBF)
        val dark = cc(0xFF263238)
        if (p.rolling > 0f) {
            frame(p.x, p.y, p.rolling * 28f, fog)
            part(0f, 0f, 1f, 11f, 11f, 11f, blue)
            part(0f, 0f, 9f, 11.4f, 11.4f, 3f, skin)
            return
        }
        frame(p.x, p.y, p.facing, fog)
        val sw = if (p.moving) sin(g.time * 14f) * 3.4f else 0f
        part(sw, 3f, 0f, 4f, 4f, 10f, dark)
        part(-sw, -3f, 0f, 4f, 4f, 10f, dark)
        part(0f, 0f, 10f, 6f, 11f, 12f, blue)
        part(-sw * 0.6f, -7.5f, 10f, 3.6f, 3.6f, 12f, blue)
        part(-sw * 0.6f, -7.5f, 10f, 3.6f, 3.6f, 3f, skin)
        part(sw * 0.6f, 7.5f, 10f, 3.6f, 3.6f, 12f, blue)
        part(sw * 0.6f, 7.5f, 10f, 3.6f, 3.6f, 3f, skin)
        val ar = p.armor
        if (ar != null) {
            val rc = ar.rarity.color
            part(0.3f, 0f, 14f, 6.6f, 11.4f, 4f, rc)
            part(0f, -7.5f, 19.5f, 4.4f, 4.4f, 2.6f, rc)
            part(0f, 7.5f, 19.5f, 4.4f, 4.4f, 2.6f, rc)
        }
        part(0f, 0f, 22f, 8f, 8f, 8f, skin)
        part(-0.3f, 0f, 28f, 8.6f, 8.6f, 2.8f, cc(0xFF5D4037))
        part(4.1f, 2f, 25f, 0.8f, 1.7f, 1.9f, dark)
        part(4.1f, -2f, 25f, 0.8f, 1.7f, 1.9f, dark)
        drawWeapon(p, fog)
    }

    private fun drawWeapon(p: Player, fog: Float) {
        val wt = p.weapon.wtype ?: return
        val half = min(wt.halfArc, 1.5f)
        val thrustType = wt.halfArc < 0.5f || wt.ranged
        var ang = p.facing + 0.5f * p.swingSign
        var thrust = 0f
        var swinging = false
        var prog = 0f
        if (p.atkAnim > 0f) {
            prog = 1f - p.atkAnim / p.atkDur
            swinging = true
            if (thrustType) {
                ang = p.facing
                thrust = sin(prog * PI_F) * 13f
            } else if (wt.slam) {
                ang = p.facing + (prog - 0.5f) * 0.5f
                thrust = sin(prog * PI_F) * 6f
            } else {
                ang = p.facing + p.swingSign * (prog - 0.5f) * 2f * half
            }
        }
        val hx: Float
        val hy: Float
        if (swinging && !thrustType && !wt.slam) {
            hx = p.x + cos(ang) * 7f
            hy = p.y + sin(ang) * 7f
        } else {
            val fwd = 2f + thrust
            hx = p.x + fwd * cos(p.facing) - 7.5f * sin(p.facing)
            hy = p.y + fwd * sin(p.facing) + 7.5f * cos(p.facing)
        }
        // rastro do golpe no chao
        if (swinging) {
            val sa = (p.atkAnim / p.atkDur).coerceIn(0f, 1f)
            if (thrustType) {
                groundRect(p.x, p.y, p.facing, wt.range * 0.95f, 2.5f, withA(white, 0.35f * sa))
            } else if (!wt.slam) {
                groundSector(
                    p.x, p.y, p.facing - half, p.facing + half,
                    wt.range * 0.9f, withA(white, 0.30f * sa)
                )
            }
        }
        frame(hx, hy, ang, fog)
        val z = 13f
        val brown = cc(0xFF6D4C41)
        val gold = cc(0xFFFFC107)
        val m = p.weapon.rarity.color
        when (wt) {
            WeaponType.SWORD -> {
                part(2f, 0f, z, 5f, 2f, 2f, brown)
                part(4.8f, 0f, z - 0.4f, 1.6f, 7f, 2.6f, gold)
                part(16f, 0f, z, 22f, 3f, 2.2f, m)
            }
            WeaponType.AXE -> {
                part(11f, 0f, z, 24f, 2.2f, 2.2f, brown)
                part(21f, 0f, z - 1f, 6f, 13f, 4f, m)
            }
            WeaponType.SPEAR -> {
                part(17f, 0f, z, 42f, 2f, 2f, brown)
                part(40f, 0f, z - 0.3f, 8f, 3.6f, 2.6f, m)
            }
            WeaponType.DAGGER -> {
                part(1.5f, 0f, z, 4f, 2f, 2f, brown)
                part(8.5f, 0f, z, 11f, 2.6f, 2f, m)
            }
            WeaponType.HAMMER -> {
                part(13f, 0f, z, 28f, 2.4f, 2.4f, brown)
                part(27f, 0f, z - 4f, 10f, 14f, 10f, m)
            }
            WeaponType.RAPIER -> {
                part(1.5f, 0f, z, 5f, 2f, 2f, brown)
                part(4f, 0f, z - 0.3f, 2f, 9f, 2.6f, gold)
                part(22f, 0f, z + 0.2f, 36f, 1.6f, 1.6f, m)
            }
            WeaponType.SCYTHE -> {
                part(17f, 0f, z, 36f, 2.2f, 2.2f, brown)
                part(34f, 0f, z - 0.5f, 3f, 18f, 3f, m)
                part(36f, 8.5f, z - 0.5f, 6f, 3f, 3f, m)
            }
            WeaponType.CLAYMORE -> {
                part(2.5f, 0f, z, 6f, 2.4f, 2.4f, brown)
                part(5.5f, 0f, z - 0.6f, 2f, 11f, 3.4f, gold)
                part(21f, 0f, z - 0.2f, 30f, 5.2f, 2.8f, m)
            }
            WeaponType.HALBERD -> {
                part(20f, 0f, z, 44f, 2.2f, 2.2f, brown)
                part(36f, 0f, z - 1f, 8f, 12f, 3.6f, m)
                part(46f, 0f, z, 6f, 2.6f, 2.6f, m)
            }
            WeaponType.MACE -> {
                part(9f, 0f, z, 20f, 2.4f, 2.4f, brown)
                part(21f, 0f, z - 3f, 8f, 8f, 8f, m)
                part(21f, 0f, z + 5f, 2.4f, 2.4f, 3f, m)
            }
            WeaponType.STAFF -> {
                part(14f, 0f, z, 32f, 2.4f, 2.4f, brown)
                part(31f, 0f, z - 2f, 5.5f, 5.5f, 5.5f, cc(0xFFCE93D8))
                val ox = fx + 31f * fca
                val oy = fy + 31f * fsa
                glow(ox, oy, z + 1f, 8f, cc(0xFFCE93D8), 0.30f + 0.15f * sin(g.time * 8f))
            }
        }
    }

    // ------------------------------------------------------------------ inimigos

    private fun drawEnemy3D(e: Enemy) {
        val pl = g.player
        val ang = atan2(pl.y - e.y, pl.x - e.x)
        val fog = fogAt(e.x, e.y)
        val r = e.type.radius
        groundOval(e.x, e.y, r * 1.15f, 0x55000000)
        // avisos de ataque no chao
        if (e.type == EType.MOSS && e.st == 1) {
            val a = 0.35f + 0.4f * (1f - e.stT / 0.45f)
            groundRing(e.x, e.y, 30f, withA(cc(0xFFFF5252), a), 2f * d)
        } else if (e.type.isBoss) {
            if (e.st == 5) {
                groundRect(e.x, e.y, atan2(e.dy, e.dx), 150f, 8f, withA(cc(0xFFFFB74D), 0.3f))
            } else if (e.st == 1) {
                val a = 0.2f + 0.3f * (1f - e.stT / 0.8f)
                groundRect(e.x, e.y, atan2(e.dy, e.dx), 170f, 14f, withA(cc(0xFFFF5252), a))
            } else if (e.st == 4) {
                groundRing(e.x, e.y, (1f - e.stT / 0.7f) * 60f, withA(cc(0xFFFF8A65), 0.7f), 3f * d)
            }
        }
        flashOn = e.flash > 0f
        frame(e.x, e.y, ang, fog)
        var top = 24f
        when (e.type) {
            EType.MOSS -> {
                val bob = sin(e.anim * 8f) * 2.2f
                val body = cc(0xFF4E7D3A)
                val legc = cc(0xFF2E4A22)
                val armZ = if (e.st == 1) 19f else 13f
                part(bob, 3.5f, 0f, 5f, 5f, 8f, legc)
                part(-bob, -3.5f, 0f, 5f, 5f, 8f, legc)
                part(0f, 0f, 8f, 8f, 12f, 11f, body)
                part(-0.5f, -2f, 19f, 5f, 5f, 1.2f, cc(0xFF3B6B2A))
                part(7f, 7.5f, armZ, 11f, 3.6f, 3.6f, body)
                part(7f, -7.5f, armZ, 11f, 3.6f, 3.6f, body)
                part(0f, 0f, 19f, 9f, 9f, 9f, cc(0xFF5E8F45))
                part(0f, 0f, 28f, 9.6f, 9.6f, 1.8f, cc(0xFF3B6B2A))
                part(4.6f, 2.3f, 23f, 0.8f, 1.7f, 1.9f, cc(0xFFFF5252))
                part(4.6f, -2.3f, 23f, 0.8f, 1.7f, 1.9f, cc(0xFFFF5252))
                top = 31f
            }
            EType.ARCHER -> {
                val bone = cc(0xFFD8D4C4)
                part(0f, 2.2f, 0f, 3f, 3f, 9f, bone)
                part(0f, -2.2f, 0f, 3f, 3f, 9f, bone)
                part(0f, 0f, 9f, 5f, 8f, 9f, bone)
                part(0f, 0f, 12f, 5.4f, 8.4f, 1.2f, cc(0xFF9E9A8A))
                part(0f, 0f, 15f, 5.4f, 8.4f, 1.2f, cc(0xFF9E9A8A))
                part(0f, -5.5f, 10f, 2.8f, 2.8f, 8f, bone)
                part(5f, 5.5f, 12f, 8f, 2.8f, 2.8f, bone)
                part(0f, 0f, 18f, 7f, 7f, 7f, cc(0xFFEFEBDC))
                part(3.6f, 1.8f, 21f, 0.8f, 1.6f, 1.8f, cc(0xFF263238))
                part(3.6f, -1.8f, 21f, 0.8f, 1.6f, 1.8f, cc(0xFF263238))
                part(9f, 5.5f, 7f, 2f, 1.6f, 14f, cc(0xFF8D6E63))
                if (e.st == 1) {
                    groundRect(e.x, e.y, ang, 140f, 1.5f, withA(cc(0xFFFF5252), 0.35f))
                }
                top = 27f
            }
            EType.GLOOP -> {
                val sq = 1f + 0.15f * sin(e.anim * 8f)
                val hop = abs(sin(e.anim * 6f)) * 4f
                val s1 = 14f * sq
                val hg = 13f / sq
                part(0f, 0f, hop, s1, s1, hg, cc(0xFF3FBFA0))
                part(0f, 0f, hop + hg - 2.4f, s1 * 0.82f, s1 * 0.82f, 2.4f, cc(0xFF7FFFD4))
                part(s1 / 2f + 0.2f, 3f, hop + hg * 0.5f, 0.8f, 2f, 2.6f, cc(0xFF004D40))
                part(s1 / 2f + 0.2f, -3f, hop + hg * 0.5f, 0.8f, 2f, 2.6f, cc(0xFF004D40))
                top = hop + hg + 3f
            }
            EType.CRAB -> {
                val sc = cc(0xFFE2573F)
                val sd = cc(0xFFB23A27)
                val sk = sin(e.anim * 10f) * 1.5f
                part(0f, 0f, 3f, 18f, 24f, 8f, sc)
                part(0f, 0f, 11f, 14f, 20f, 3f, cc(0xFFF4785F))
                part(2f, 8f + sk, 3f, 4f, 4f, 3f, sd)
                part(2f, -8f - sk, 3f, 4f, 4f, 3f, sd)
                part(9f, 13f, 4f, 9f, 8f, 7f, sd)
                part(9f, -13f, 4f, 9f, 8f, 7f, sd)
                part(13f, 13f, 6f, 4f, 3f, 3f, cc(0xFFF4785F))
                part(13f, -13f, 6f, 4f, 3f, 3f, cc(0xFFF4785F))
                part(7f, 4f, 14f, 1.6f, 1.6f, 4f, cc(0xFF212121))
                part(7f, -4f, 14f, 1.6f, 1.6f, 4f, cc(0xFF212121))
                top = 20f
            }
            EType.JELLY -> {
                val fl = 14f + sin(e.anim * 3f) * 2.5f
                glow(e.x, e.y, fl, 20f, cc(0xFFB388FF), 0.10f)
                part(0f, 0f, fl, 14f, 14f, 8f, cc(0xFFCE93D8))
                part(0f, 0f, fl + 8f, 10f, 10f, 4f, cc(0xFFE1BEE7))
                for (k in 0 until 4) {
                    val a = k * 1.5708f + e.anim
                    part(cos(a) * 3.5f, sin(a) * 3.5f, fl - 9f, 2f, 2f, 9f + sin(e.anim * 4f + k) * 2f, cc(0xFFAB47BC))
                }
                part(5f, 2.4f, fl + 4f, 0.8f, 1.8f, 1.8f, cc(0xFF311B92))
                part(5f, -2.4f, fl + 4f, 0.8f, 1.8f, 1.8f, cc(0xFF311B92))
                top = fl + 12f
            }
            EType.DUMMY -> {
                part(0f, 0f, 0f, 10f, 10f, 4f, cc(0xFF6D4C2F))
                part(0f, 0f, 4f, 4f, 4f, 22f, cc(0xFF8D6E4A))
                part(0f, 0f, 16f, 5f, 18f, 3f, cc(0xFF8D6E4A))
                part(0f, 0f, 24f, 11f, 11f, 10f, cc(0xFFE0B972))
                part(5.6f, 0f, 27f, 0.8f, 7f, 2f, cc(0xFFD84343))
                top = 36f
            }
            EType.IMP -> {
                val bob = sin(e.anim * 9f) * 1.5f
                val dk = cc(0xFF3E1F14)
                part(0f, 3f, 0f, 3.5f, 3.5f, 6f, dk)
                part(0f, -3f, 0f, 3.5f, 3.5f, 6f, dk)
                part(0f, 0f, 6f, 8f, 9f, 9f, cc(0xFFE64A19))
                part(0f, 0f, 15f + bob, 8f, 8f, 7f, cc(0xFFFF7043))
                part(4.1f, 2f, 18f + bob, 0.8f, 1.6f, 1.8f, cc(0xFFFFEB3B))
                part(4.1f, -2f, 18f + bob, 0.8f, 1.6f, 1.8f, cc(0xFFFFEB3B))
                part(0f, 3f, 22f + bob, 2f, 2f, 4f, dk)
                part(0f, -3f, 22f + bob, 2f, 2f, 4f, dk)
                part(-3f, 8f, 9f + bob, 1f, 7f, 7f, cc(0xFFBF360C))
                part(-3f, -8f, 9f + bob, 1f, 7f, 7f, cc(0xFFBF360C))
                top = 28f
            }
            EType.WRAITH -> {
                val fl = 4f + sin(e.anim * 4f) * 2f
                part(0f, 0f, fl, 8f, 8f, 6f, cc(0xFF7E57C2))
                part(0f, 0f, fl + 6f, 10f, 10f, 10f, cc(0xFF9575CD))
                part(0f, 0f, fl + 16f, 8f, 8f, 7f, cc(0xFFB39DDB))
                part(4.1f, 2f, fl + 19f, 0.8f, 1.6f, 1.8f, cc(0xFFE0F7FA))
                part(4.1f, -2f, fl + 19f, 0.8f, 1.6f, 1.8f, cc(0xFFE0F7FA))
                part(3f, 7f, fl + 10f, 6f, 2.5f, 2.5f, cc(0xFF7E57C2))
                part(3f, -7f, fl + 10f, 6f, 2.5f, 2.5f, cc(0xFF7E57C2))
                glow(e.x, e.y, fl + 10f, 14f, cc(0xFFB39DDB), 0.08f)
                top = fl + 28f
            }
            EType.KCRAB -> {
                val sc = cc(0xFFD84315)
                val sd = cc(0xFF8E2A12)
                val sk = sin(e.anim * 9f) * 2f
                part(0f, 0f, 4f, 30f, 38f, 12f, sc)
                part(0f, 0f, 16f, 24f, 32f, 5f, cc(0xFFEF6C45))
                part(2f, 17f + sk, 3f, 6f, 6f, 4f, sd)
                part(2f, -17f - sk, 3f, 6f, 6f, 4f, sd)
                part(16f, 22f, 5f, 16f, 12f, 11f, sd)
                part(16f, -22f, 5f, 16f, 12f, 11f, sd)
                part(25f, 22f, 8f, 8f, 5f, 5f, cc(0xFFEF6C45))
                part(25f, -22f, 8f, 8f, 5f, 5f, cc(0xFFEF6C45))
                part(11f, 7f, 22f, 2.4f, 2.4f, 7f, cc(0xFF212121))
                part(11f, -7f, 22f, 2.4f, 2.4f, 7f, cc(0xFF212121))
                part(0f, 0f, 21f, 12f, 12f, 4f, cc(0xFFFFC107))
                part(0f, 4f, 25f, 3f, 3f, 5f, cc(0xFFFFC107))
                part(0f, -4f, 25f, 3f, 3f, 5f, cc(0xFFFFC107))
                top = 36f
            }
            EType.COLOSSUS -> {
                val mc = cc(0xFF558B2F)
                val md = cc(0xFF33691E)
                val bob = if (e.st == 0) sin(e.anim * 4f) * 1.2f else 0f
                part(bob, 8f, 0f, 10f, 10f, 12f, md)
                part(-bob, -8f, 0f, 10f, 10f, 12f, md)
                part(0f, 0f, 12f, 18f, 26f, 22f, mc)
                part(9.2f, -5f, 20f, 0.8f, 2f, 12f, cc(0xFFCDDC39))
                part(9.2f, 6f, 16f, 0.8f, 2f, 10f, cc(0xFFCDDC39))
                part(0f, -17f, 12f, 9f, 9f, 26f, md)
                part(0f, 17f, 12f, 9f, 9f, 26f, md)
                part(0f, -17f, 36f, 11f, 11f, 5f, cc(0xFF9CCC65))
                part(0f, 17f, 36f, 11f, 11f, 5f, cc(0xFF9CCC65))
                part(0f, 0f, 34f, 14f, 14f, 12f, mc)
                part(0f, 0f, 46f, 15f, 15f, 3f, cc(0xFF9CCC65))
                part(7.2f, 3.5f, 39f, 0.8f, 3.5f, 3f, cc(0xFFFFEB3B))
                part(7.2f, -3.5f, 39f, 0.8f, 3.5f, 3f, cc(0xFFFFEB3B))
                top = 54f
            }
            EType.GOLEM -> {
                val ir = cc(0xFF5D4037)
                val dk = cc(0xFF3E2723)
                val glw = cc(0xFFFF6D00)
                val bob = if (e.st == 0) sin(e.anim * 5f) * 1.4f else 0f
                part(bob, 7f, 0f, 10f, 10f, 14f, dk)
                part(-bob, -7f, 0f, 10f, 10f, 14f, dk)
                part(0f, 0f, 14f, 18f, 28f, 22f, ir)
                part(9.2f, 0f, 18f, 0.8f, 12f, 10f, glw)
                part(9.2f, -9f, 22f, 0.8f, 3f, 8f, glw)
                part(9.2f, 9f, 22f, 0.8f, 3f, 8f, glw)
                part(0f, -19f, 14f, 10f, 10f, 24f, ir)
                part(0f, 19f, 14f, 10f, 10f, 24f, ir)
                part(2f, -19f, 36f, 13f, 12f, 8f, dk)
                part(2f, 19f, 36f, 13f, 12f, 8f, dk)
                part(0f, 0f, 36f, 14f, 15f, 12f, dk)
                part(7.2f, 0f, 41f, 0.8f, 9f, 3f, glw)
                part(0f, -9f, 47f, 3f, 3f, 6f, ir)
                part(0f, 9f, 47f, 3f, 3f, 6f, ir)
                glow(e.x, e.y, 24f, 22f, glw, 0.07f)
                top = 58f
            }
            EType.BOSS -> {
                val stunned = e.st == 3
                val body = if (stunned) cc(0xFFA58CCB) else cc(0xFF7A5CA8)
                val dk = cc(0xFF4A3470)
                val glowc = cc(0xFFFF6D00)
                val bob = if (e.st == 0) sin(e.anim * 6f) * 1.6f else 0f
                part(bob, 7f, 0f, 9f, 9f, 14f, dk)
                part(-bob, -7f, 0f, 9f, 9f, 14f, dk)
                part(0f, 0f, 14f, 16f, 28f, 22f, body)
                part(8.2f, -5f, 20f, 0.8f, 2f, 12f, glowc)
                part(8.2f, 6f, 16f, 0.8f, 2f, 12f, glowc)
                part(8.2f, 0f, 24f, 0.8f, 8f, 2f, glowc)
                part(0f, -18f, 14f, 9f, 9f, 24f, body)
                part(0f, 18f, 14f, 9f, 9f, 24f, body)
                part(0f, -18f, 36f, 10f, 10f, 5f, dk)
                part(0f, 18f, 36f, 10f, 10f, 5f, dk)
                part(0f, 0f, 36f, 15f, 15f, 14f, cc(0xFF8D6CC0))
                part(0f, -7f, 49f, 3f, 3f, 9f, dk)
                part(0f, 7f, 49f, 3f, 3f, 9f, dk)
                part(7.7f, 3.5f, 43f, 0.8f, 4f, 3f, cc(0xFFFFA000))
                part(7.7f, -3.5f, 43f, 0.8f, 4f, 3f, cc(0xFFFFA000))
                top = 60f
            }
        }
        flashOn = false
        if (e.burn > 0f) {
            val tt = g.time * 18f
            for (k in 0 until 3) {
                val ox = e.x + sin(tt + k * 2.1f) * r * 0.7f
                val oy = e.y + cos(tt * 0.8f + k * 1.7f) * r * 0.7f
                val col = if (((tt + k).toInt() and 1) == 0) cc(0xFFFF7043) else cc(0xFFFFD54F)
                box(ox, oy, top * 0.4f + k * 4f + (tt % 3f), 3f, 3f, 4f, 0f, col, 1f)
            }
        }
        if (e.stun > 0f) {
            for (k in 0 until 3) {
                val a = g.time * 6f + k * 2.0944f
                box(e.x + cos(a) * 9f, e.y + sin(a) * 9f, top + 4f, 2.6f, 2.6f, 2.6f, 0f, cc(0xFFFFEB3B), 1f)
            }
        }
        if (e.type.isBoss || e.type == EType.DUMMY) return
        if (e.hp < e.maxHp) hpBar(e.x, e.y, top + 6f, e.hp / e.maxHp, 24f * d)
    }

    // ------------------------------------------------------------------ terreno, decoracao e npcs

    private fun drawTerrain(
        tx: Int, ty: Int, tt: Int, xa: Float, ya: Float, xb: Float, yb: Float,
        fog: Float, th: Theme
    ) {
        val chk = ((tx + ty) and 1) == 0
        val hsh = ((tx * 73856093) xor (ty * 19349663)) and 0x7fffffff
        when (tt) {
            Game.T_SAND -> {
                flatQuad(xa, ya, xb, yb, 0f, shade(if (chk) cc(0xFFE6D29A) else cc(0xFFDFC98E), fog))
                if (hsh % 7 == 0) flatQuad(xa + 8f, ya + 10f, xa + 12f, ya + 12f, 0f, shade(cc(0xFFC2AA72), fog))
            }
            Game.T_WATER -> {
                val wv = 0.93f + 0.07f * sin(g.time * 2f + tx * 0.8f + ty * 0.6f)
                flatQuad(xa, ya, xb, yb, 0f, shade(cc(0xFF3A86D0), fog * wv))
                if ((hsh + (g.time * 1.5f).toInt()) % 6 == 0) {
                    val ox = xa + 6f + (hsh % 13)
                    val oy = ya + 8f + (hsh % 9)
                    flatQuad(ox, oy, ox + 9f, oy + 2f, 0f, shade(cc(0xFFB3E5FC), fog))
                }
            }
            Game.T_PLANK -> {
                flatQuad(xa, ya, xb, yb, 0f, shade(if (chk) cc(0xFFA67C4E) else cc(0xFF9A7045), fog))
                flatQuad(xa, ya + 15f, xb, ya + 17f, 0f, shade(cc(0xFF6E4B2A), fog))
                flatQuad(xa + 3f, ya + 3f, xa + 5f, ya + 5f, 0f, shade(cc(0xFF5A3C20), fog))
                flatQuad(xb - 5f, ya + 21f, xb - 3f, ya + 23f, 0f, shade(cc(0xFF5A3C20), fog))
            }
            Game.T_GRASS -> {
                flatQuad(xa, ya, xb, yb, 0f, shade(if (chk) cc(0xFF72B456) else cc(0xFF69AA4E), fog))
                if (hsh % 5 == 0) flatQuad(xa + 6f, ya + 9f, xa + 9f, ya + 14f, 0f, shade(cc(0xFF8CCB6B), fog))
                if (hsh % 11 == 0) flatQuad(xa + 18f, ya + 20f, xa + 21f, ya + 23f, 0f, shade(cc(0xFFF48FB1), fog))
            }
            Game.T_LAVA -> {
                val wv = 0.88f + 0.12f * sin(g.time * 3f + tx * 0.9f + ty * 0.7f)
                flatQuad(xa, ya, xb, yb, 0f, shade(cc(0xFFE65100), fog * wv))
                if ((hsh + (g.time * 2f).toInt()) % 4 == 0) {
                    val ox = xa + 5f + (hsh % 11)
                    val oy = ya + 6f + (hsh % 13)
                    flatQuad(ox, oy, ox + 10f, oy + 3f, 0f, shade(cc(0xFFFFCA28), fog))
                }
                if (hsh % 7 == 0) flatQuad(xa + 12f, ya + 14f, xa + 20f, ya + 19f, 0f, shade(cc(0xFF8E2A00), fog))
            }
            else -> {
                val base = if (chk) th.floorA else th.floorB
                flatQuad(xa, ya, xb, yb, 0f, shade(base, fog))
                if (hsh % 9 == 0) {
                    val ox = xa + 6f + (hsh % 11)
                    val oy = ya + 8f + (hsh % 7)
                    flatQuad(ox, oy, ox + 8f, oy + 4f, 0f, shade(base, fog * 0.78f))
                }
            }
        }
    }

    private fun drawDeco3D(tx: Int, ty: Int) {
        val t = Game.T
        val x = tx * t + t / 2f
        val y = ty * t + t / 2f
        val id = g.deco[ty * Game.MW + tx]
        val fog = fogAt(x, y)
        if (id != Game.D_FIRE) groundOval(x, y, 13f, 0x40000000)
        frame(x, y, 0f, fog)
        val wood = cc(0xFF8B5A2B)
        val dark = cc(0xFF4E342E)
        when (id) {
            Game.D_ROCK -> {
                part(0f, 0f, 0f, 22f, 20f, 11f, cc(0xFF8D8F94))
                part(-2f, 1f, 11f, 14f, 12f, 7f, cc(0xFF9EA0A6))
                part(3f, -3f, 0f, 8f, 8f, 16f, cc(0xFF7B7D82))
            }
            Game.D_PALM -> {
                val brown = cc(0xFF8D6E4A)
                part(0f, 0f, 0f, 5f, 5f, 9f, brown)
                part(1.5f, 0f, 9f, 5f, 5f, 9f, brown)
                part(3f, 1f, 18f, 5f, 5f, 9f, brown)
                val lx = x + 3f
                val ly = y + 1f
                val leaf = cc(0xFF3E9B3E)
                val leaf2 = cc(0xFF4FB04F)
                box(lx, ly, 26f, 24f, 5f, 2.5f, 0f, leaf, fog)
                box(lx, ly, 26.5f, 24f, 5f, 2.5f, 1.5708f, leaf, fog)
                box(lx, ly, 27f, 22f, 5f, 2.5f, 0.7854f, leaf2, fog)
                box(lx, ly, 27f, 22f, 5f, 2.5f, -0.7854f, leaf2, fog)
                box(lx, ly, 24f, 5f, 5f, 3f, 0f, cc(0xFF6D4C2F), fog)
            }
            Game.D_OAK -> {
                part(0f, 0f, 0f, 7f, 7f, 14f, cc(0xFF6D4C2F))
                part(0f, 0f, 12f, 26f, 26f, 15f, cc(0xFF3F8F3A))
                part(0f, 0f, 27f, 18f, 18f, 8f, cc(0xFF4FA847))
                part(-8f, 6f, 20f, 8f, 8f, 8f, cc(0xFF378032))
            }
            Game.D_TENT -> {
                part(0f, 0f, 0f, 26f, 30f, 9f, cc(0xFFC8553D))
                part(0f, 0f, 9f, 22f, 30f, 7f, cc(0xFFD9694F))
                part(0f, 0f, 16f, 12f, 30f, 5f, cc(0xFFE57A5F))
                part(13.2f, 0f, 0f, 0.8f, 10f, 9f, dark)
                part(0f, 13f, 0f, 20f, 0.8f, 8f, cc(0xFFF0E6D0))
            }
            Game.D_CRATE -> {
                part(0f, 0f, 0f, 16f, 16f, 14f, cc(0xFFA9703A))
                part(0f, 0f, 14f, 17f, 17f, 1.2f, cc(0xFF7A4C1E))
                part(0f, 0f, 6f, 16.6f, 16.6f, 1.2f, cc(0xFF7A4C1E))
            }
            Game.D_BARREL -> {
                part(0f, 0f, 0f, 12f, 12f, 16f, cc(0xFF7B5230))
                part(0f, 0f, 3f, 12.8f, 12.8f, 1.6f, cc(0xFF424242))
                part(0f, 0f, 11f, 12.8f, 12.8f, 1.6f, cc(0xFF424242))
            }
            Game.D_FENCE -> {
                part(-10f, 0f, 0f, 3f, 3f, 12f, wood)
                part(10f, 0f, 0f, 3f, 3f, 12f, wood)
                part(0f, 0f, 7f, 24f, 2f, 2f, cc(0xFFA9703A))
                part(0f, 0f, 3f, 24f, 2f, 2f, cc(0xFFA9703A))
            }
            Game.D_FIRE -> {
                val fl = g.time * 9f
                glow(x, y, 4f, 34f, cc(0xFFFFB74D), 0.10f + 0.04f * sin(fl))
                part(0f, 0f, 0f, 16f, 3f, 3f, dark)
                part(0f, 0f, 0f, 3f, 16f, 3f, dark)
                for (k in 0 until 8) {
                    val a = k * 0.7854f
                    box(x + cos(a) * 10f, y + sin(a) * 10f, 0f, 4f, 4f, 4f, 0f, cc(0xFF8D8F94), fog)
                }
                part(sin(fl) * 1.2f, cos(fl * 1.3f) * 1.2f, 3f, 7f, 7f, 9f + (sin(fl * 2f) + 1f) * 3f, cc(0xFFFF7043))
                part(0f, 0f, 3f, 4f, 4f, 13f + (sin(fl * 2.7f) + 1f) * 3f, cc(0xFFFFD54F))
            }
            Game.D_STALL -> {
                part(0f, 0f, 0f, 28f, 16f, 10f, wood)
                part(0f, 0f, 10f, 30f, 18f, 2f, cc(0xFFB07A3F))
                part(-13f, -7f, 10f, 3f, 3f, 16f, dark)
                part(13f, -7f, 10f, 3f, 3f, 16f, dark)
                part(-13f, 7f, 10f, 3f, 3f, 16f, dark)
                part(13f, 7f, 10f, 3f, 3f, 16f, dark)
                part(0f, 0f, 26f, 32f, 20f, 3f, cc(0xFFD84343))
                part(-10f, 0f, 26.6f, 6f, 20.4f, 3f, cc(0xFFF5EBDD))
                part(2f, 0f, 26.6f, 6f, 20.4f, 3f, cc(0xFFF5EBDD))
                part(-6f, 0f, 12f, 5f, 5f, 5f, cc(0xFFE53935))
                part(2f, 2f, 12f, 5f, 5f, 6f, cc(0xFF3DDC84))
                part(8f, -2f, 12f, 6f, 4f, 4f, cc(0xFFFFD54F))
            }
            Game.D_ANVIL -> {
                part(0f, 0f, 0f, 14f, 10f, 9f, cc(0xFF4A4A50))
                part(0f, 0f, 9f, 22f, 10f, 4f, cc(0xFF6B6B73))
                part(13f, 0f, 9f, 6f, 5f, 3f, cc(0xFF6B6B73))
                part(-3f, 0f, 13f, 5f, 4f, 1.5f, cc(0xFFFF7043))
            }
            Game.D_TABLE -> {
                part(-12f, -8f, 0f, 3f, 3f, 8f, dark)
                part(12f, -8f, 0f, 3f, 3f, 8f, dark)
                part(-12f, 8f, 0f, 3f, 3f, 8f, dark)
                part(12f, 8f, 0f, 3f, 3f, 8f, dark)
                part(0f, 0f, 8f, 30f, 22f, 3f, cc(0xFF9A6B3F))
                part(0f, 0f, 11f, 22f, 14f, 1f, cc(0xFFEFE2B8))
                part(-4f, 0f, 12f, 12f, 1f, 0.5f, cc(0xFF8B6B3A))
                part(10f, 6f, 11f, 2f, 2f, 18f, dark)
                part(10f, 6f, 24f, 2f, 8f, 6f, cc(0xFFD84343))
            }
            Game.D_TORCH -> {
                val fl = g.time * 10f + x
                part(0f, 0f, 0f, 3f, 3f, 22f, dark)
                part(0f, 0f, 22f, 5f, 5f, 4f + (sin(fl) + 1f), cc(0xFFFF9800))
                part(0f, 0f, 24f, 3f, 3f, 4f, cc(0xFFFFEB3B))
                glow(x, y, 26f, 14f, cc(0xFFFFB74D), 0.16f + 0.05f * sin(fl))
            }
            Game.D_DOOR0, Game.D_DOOR1, Game.D_DOOR2, Game.D_DOORL -> {
                val kc = when (id) {
                    Game.D_DOOR0 -> cc(0xFFE53935)
                    Game.D_DOOR1 -> cc(0xFF42A5F5)
                    Game.D_DOOR2 -> cc(0xFFFFC107)
                    else -> cc(0xFF90A4AE)
                }
                part(0f, 0f, 0f, 32f, 32f, 30f, cc(0xFF5D4037))
                part(0f, 0f, 30f, 32.5f, 32.5f, 5f, kc)
                part(0f, 0f, 8f, 33f, 6f, 5f, cc(0xFF3E2723))
                part(0f, 0f, 19f, 33f, 6f, 5f, cc(0xFF3E2723))
                if (id != Game.D_DOORL) part(0f, 0f, 12f, 33.5f, 9f, 9f, kc)
            }
            Game.D_LEVER -> {
                val sp = g.spots.firstOrNull { it.kind == 4 && floor(it.x / t).toInt() == tx && floor(it.y / t).toInt() == ty }
                val on = sp?.lit == true
                part(0f, 0f, 0f, 14f, 14f, 7f, cc(0xFF6B6B73))
                part(0f, 0f, 7f, 8f, 8f, 3f, cc(0xFF424248))
                part(if (on) 4f else -4f, 0f, 9f, 3f, 3f, 14f, if (on) cc(0xFF69F0AE) else cc(0xFFE53935))
            }
            Game.D_BRAZ -> {
                val sp = g.spots.firstOrNull { it.kind == 5 && floor(it.x / t).toInt() == tx && floor(it.y / t).toInt() == ty }
                val col = when (sp?.text) {
                    "Verde" -> cc(0xFF43A047)
                    "Azul" -> cc(0xFF1E88E5)
                    "Vermelho" -> cc(0xFFE53935)
                    else -> cc(0xFFFFC107)
                }
                part(0f, 0f, 0f, 12f, 12f, 12f, cc(0xFF616168))
                part(0f, 0f, 12f, 15f, 15f, 4f, col)
                part(0f, 0f, 16f, 11f, 11f, 1.5f, cc(0xFF212121))
                if (sp?.lit == true) {
                    val fl = g.time * 9f + x
                    glow(x, y, 18f, 26f, col, 0.15f + 0.05f * sin(fl))
                    part(0f, 0f, 17f, 7f, 7f, 8f + (sin(fl) + 1f) * 2f, col)
                    part(0f, 0f, 17f, 4f, 4f, 12f + (sin(fl * 1.7f) + 1f) * 2f, cc(0xFFFFF59D))
                }
            }
            Game.D_TABLET -> {
                part(0f, 0f, 0f, 16f, 6f, 20f, cc(0xFF9E9E9E))
                part(0f, 0f, 20f, 14f, 6f, 3f, cc(0xFF8D8D8D))
                part(3.2f, 0f, 14f, 0.8f, 8f, 1.6f, cc(0xFF455A64))
                part(3.2f, 0f, 10f, 0.8f, 8f, 1.6f, cc(0xFF455A64))
                part(3.2f, 0f, 6f, 0.8f, 5f, 1.6f, cc(0xFF455A64))
            }
            Game.D_MAST -> {
                part(0f, 0f, 0f, 5f, 5f, 64f, dark)
                box(x, y, 46f, 30f, 3f, 3f, 0.6f, cc(0xFF6D4C2F), fog)
                part(0f, 0f, 28f, 16f, 1.5f, 16f, cc(0xFFE8E0CC))
            }
        }
    }

    private fun drawNpc3D(sp: Spot) {
        val pl = g.player
        val ang = atan2(pl.y - sp.y, pl.x - sp.x)
        val fog = fogAt(sp.x, sp.y)
        groundOval(sp.x, sp.y, 9f, 0x55000000)
        frame(sp.x, sp.y, ang, fog)
        val skin = cc(0xFFF1C27D)
        val dk = cc(0xFF263238)
        val body = if (sp.kind == 0) cc(0xFF8E24AA) else cc(0xFF8D5524)
        val bob = sin(g.time * 2f + sp.x) * 0.6f
        part(0f, 3f, 0f, 4f, 4f, 10f, dk)
        part(0f, -3f, 0f, 4f, 4f, 10f, dk)
        part(0f, 0f, 10f, 6f, 11f, 12f, body)
        part(0f, -7.5f, 10f, 3.6f, 3.6f, 12f, body)
        part(0f, 7.5f, 10f, 3.6f, 3.6f, 12f, body)
        part(0f, 0f, 22f + bob, 8f, 8f, 8f, skin)
        if (sp.kind == 0) {
            part(0f, 0f, 29.5f + bob, 11f, 11f, 3f, cc(0xFFFFC107))
            part(0f, 0f, 32f + bob, 7f, 7f, 3f, cc(0xFFFFC107))
        } else {
            part(-0.3f, 0f, 28f + bob, 8.6f, 8.6f, 2.8f, cc(0xFF3E2723))
            part(3.4f, 0f, 12f, 1.4f, 10f, 11f, cc(0xFF4E342E))
        }
        part(4.1f, 2f, 25f + bob, 0.8f, 1.7f, 1.9f, dk)
        part(4.1f, -2f, 25f + bob, 0.8f, 1.7f, 1.9f, dk)
    }

    // ------------------------------------------------------------------ mapa-mundi

    private var selM = 0
    private var worldInit = false
    private val mapGo = RectF()
    private val mapBack = RectF()
    private val nodeX = floatArrayOf(0.30f, 0.50f, 0.70f, 0.87f)
    private val nodeY = floatArrayOf(0.36f, 0.68f, 0.34f, 0.62f)
    private val mDesc = arrayOf(
        "Tutorial: ilhas, pontes e o Rei Caranguejo. Aqui nasce o acampamento.",
        "Salão central, três alas trancadas e o Colosso de Musgo.",
        "Salões vulcânicos onde o ferro nunca esfria.",
        "O guardião espera no coração da montanha."
    )

    private fun nodePX(i: Int): Float = if (i < 0) 0.12f * width else nodeX[i] * width

    private fun nodePY(i: Int): Float {
        val my = height - 118f * d
        val f = if (i < 0) 0.66f else nodeY[i]
        return 24f * d + f * (my - 24f * d)
    }

    private fun drawIsland(
        c: Canvas, cx: Float, cy: Float, rx: Float, ry: Float, seed: Int,
        grass: Int, grass2: Int, sand: Int
    ) {
        val cell = 13f * d
        var gy = -ry
        var iy = 0
        while (gy <= ry) {
            var gx = -rx
            var ix = 0
            while (gx <= rx) {
                val nxn = gx / rx
                val nyn = gy / ry
                val hh = ((ix * 73856093) xor (iy * 19349663) xor (seed * 83492791)) and 0x7fffffff
                val noise = (hh % 100) / 100f * 0.35f
                val rr = nxn * nxn + nyn * nyn
                if (rr <= 0.55f + noise) {
                    val col = if (rr > 0.38f + noise * 0.5f) sand else if (hh % 4 == 0) grass2 else grass
                    fr(c, cx + gx, cy + gy, cx + gx + cell, cy + gy + cell, col)
                    fr(c, cx + gx, cy + gy, cx + gx + cell, cy + gy + cell * 0.3f, withA(white, 0.18f))
                    if (rr < 0.3f && hh % 6 == 0) {
                        fr(c, cx + gx + cell * 0.15f, cy + gy - cell * 0.3f, cx + gx + cell * 0.85f, cy + gy + cell * 0.6f, cc(0xFF2E7D32))
                    }
                }
                gx += cell
                ix++
            }
            gy += cell
            iy++
        }
    }

    private fun drawMap(c: Canvas, w: Int, h: Int) {
        val wf = w.toFloat()
        val hf = h.toFloat()
        if (!worldInit) {
            worldInit = true
            var s = 3
            for (i in 0 until min(4, g.unlockedCount)) {
                if (!g.done[i]) {
                    s = i
                    break
                }
            }
            selM = s
        }
        c.drawColor(cc(0xFF3D86C6))
        // ondas
        for (k in 0 until 36) {
            val hh = (k * 73856093) and 0x7fffffff
            val wx = (hh % 1000) / 1000f * wf
            val wy = ((hh / 1000) % 1000) / 1000f * hf
            val sh = 0.5f + 0.5f * sin(menuT * 1.5f + k)
            line(c, wx, wy, wx + 14f * d, wy, withA(white, 0.18f + 0.12f * sh), 2f * d)
        }
        // ilhas
        drawIsland(c, nodePX(-1), nodePY(-1), 52f * d, 42f * d, 11, cc(0xFF6FB154), cc(0xFF5FA047), cc(0xFFE6D29A))
        drawIsland(c, nodePX(0), nodePY(0), 84f * d, 60f * d, 3, cc(0xFF8DBB5E), cc(0xFF7FAE52), cc(0xFFEBD9A0))
        drawIsland(c, nodePX(1), nodePY(1), 84f * d, 54f * d, 5, cc(0xFF3F7F3A), cc(0xFF4D9145), cc(0xFF9AA89A))
        drawIsland(c, nodePX(2), nodePY(2), 84f * d, 60f * d, 7, cc(0xFF8F5B4A), cc(0xFF7A4A3B), cc(0xFFC97B4A))
        drawIsland(c, nodePX(3), nodePY(3), 72f * d, 58f * d, 9, cc(0xFF6A5F8F), cc(0xFF5A4F7F), cc(0xFF9C93B8))
        // trilhas pontilhadas
        for (i in -1..2) {
            val x0 = nodePX(i)
            val y0 = nodePY(i)
            val x1 = nodePX(i + 1)
            val y1 = nodePY(i + 1)
            val steps = (hypot(x1 - x0, y1 - y0) / (14f * d)).toInt()
            for (k in 1 until steps) {
                val f = k.toFloat() / steps
                circle(c, x0 + (x1 - x0) * f, y0 + (y1 - y0) * f, 2.6f * d, withA(white, 0.85f))
            }
        }
        // acampamento
        val cx0 = nodePX(-1)
        val cy0 = nodePY(-1)
        circle(c, cx0, cy0, 22f * d, cc(0xFF455A64))
        circle(c, cx0, cy0, 22f * d, white, 2f * d)
        path.reset()
        path.moveTo(cx0, cy0 - 12f * d)
        path.lineTo(cx0 + 12f * d, cy0 + 9f * d)
        path.lineTo(cx0 - 12f * d, cy0 + 9f * d)
        path.close()
        paint.style = Paint.Style.FILL
        paint.color = cc(0xFFFF8A65)
        c.drawPath(path, paint)
        txt(c, "Acampamento", cx0 + 1f, cy0 + 40f * d + 1f, 12f * d, cc(0xFF000000), Paint.Align.CENTER)
        txt(c, "Acampamento", cx0, cy0 + 40f * d, 12f * d, white, Paint.Align.CENTER)
        // missoes
        for (i in 0 until 4) {
            val px = nodePX(i)
            val py = nodePY(i)
            val locked = i >= g.unlockedCount
            val col = if (g.done[i]) cc(0xFF43A047) else if (locked) cc(0xFF607D8B) else cc(0xFFFFC107)
            if (i == selM) {
                val pu = 6f + 2f * sin(menuT * 5f)
                circle(c, px, py, 22f * d + pu * d, withA(white, 0.9f), 3f * d)
            }
            circle(c, px, py, 22f * d, col)
            circle(c, px, py, 22f * d, white, 2f * d)
            val mark = if (g.done[i]) "OK" else if (locked) "X" else (i + 1).toString()
            txt(c, mark, px, py + 6f * d, 17f * d, if (locked) white else cc(0xFF212121), Paint.Align.CENTER)
            val nm = Game.THEME_NAMES[i]
            txt(c, nm, px + 1f, py + 40f * d + 1f, 12f * d, cc(0xFF000000), Paint.Align.CENTER)
            txt(c, nm, px, py + 40f * d, 12f * d, white, Paint.Align.CENTER)
        }
        // titulo
        txt(c, "Mapa-múndi", 17f * d, 30f * d, 22f * d, cc(0xFF000000))
        txt(c, "Mapa-múndi", 15f * d, 28f * d, 22f * d, white)
        // painel
        val pl = 10f * d
        val pt = hf - 108f * d
        val pr = wf - 10f * d
        val pb = hf - 10f * d
        rf.set(pl, pt, pr, pb)
        paint.style = Paint.Style.FILL
        paint.color = cc(0xF0182018)
        c.drawRoundRect(rf, 10f * d, 10f * d, paint)
        mapGo.set(pr - 140f * d, pt + 10f * d, pr - 12f * d, pt + 48f * d)
        mapBack.set(pr - 140f * d, pt + 56f * d, pr - 12f * d, pt + 88f * d)
        val sm = selM.coerceIn(0, 3)
        val lockedSel = sm >= g.unlockedCount
        txt(c, Game.THEME_NAMES[sm], pl + 14f * d, pt + 28f * d, 18f * d, gold)
        txt(c, mDesc[sm], pl + 14f * d, pt + 48f * d, 12f * d, white)
        val status = if (lockedSel) "Bloqueada: conclua a missão anterior" else if (g.done[sm]) "Concluída" else "Disponível"
        txt(c, status, pl + 14f * d, pt + 66f * d, 11f * d, grey)
        txt(c, "Dificuldade", pl + 14f * d, pt + 88f * d, 11f * d, grey)
        for (k in 0 until 4) {
            val l = pl + 100f * d + k * 16f * d
            fr(c, l, pt + 78f * d, l + 12f * d, pt + 90f * d, if (k <= sm) cc(0xFFE53935) else cc(0xFF3A3F3A))
        }
        drawSimpleBtn(c, mapGo, if (lockedSel) "Bloqueada" else "Partir", !lockedSel)
        drawSimpleBtn(c, mapBack, "Voltar", true)
    }

    private fun worldTouch(x: Float, y: Float) {
        if (g.stateT < 0.25f) return
        if (mapBack.contains(x, y)) {
            g.closeWorldMap()
            return
        }
        if (mapGo.contains(x, y)) {
            if (selM in 0..3 && selM < g.unlockedCount) {
                releaseAll()
                g.startMission(selM)
            }
            return
        }
        for (i in 0 until 4) {
            if (hypot(x - nodePX(i), y - nodePY(i)) < 32f * d) {
                selM = i
                return
            }
        }
        if (hypot(x - nodePX(-1), y - nodePY(-1)) < 32f * d) g.closeWorldMap()
    }

    fun snapshot(): String? = if (g.started) g.save() else null

    fun restore(s: String?) {
        if (s != null) g.load(s)
    }


    // ------------------------------------------------------------------ cenas e objetivo

    private fun wrap(sx: String, maxChars: Int): List<String> {
        val out = ArrayList<String>()
        var line = StringBuilder()
        for (w in sx.split(" ")) {
            if (line.isNotEmpty() && line.length + 1 + w.length > maxChars) {
                out.add(line.toString())
                line = StringBuilder()
            }
            if (line.isNotEmpty()) line.append(' ')
            line.append(w)
        }
        if (line.isNotEmpty()) out.add(line.toString())
        return out
    }

    private fun drawCut(c: Canvas, w: Int, h: Int) {
        val sl = g.cut.getOrNull(g.cutIdx) ?: return
        val wf = w.toFloat()
        val hf = h.toFloat()
        fr(c, 0f, 0f, wf, hf, cc(0x55000000))
        fr(c, 0f, 0f, wf, hf * 0.12f, cc(0xF0000000))
        txt(c, "Missão ${g.mission + 1}: ${Game.THEME_NAMES[g.mission.coerceIn(0, 3)]}", wf / 2f, hf * 0.075f, 17f * d, gold, Paint.Align.CENTER)
        val pl = 24f * d
        val pr = wf - 24f * d
        val pt = hf * 0.60f
        val pb = hf - 16f * d
        rf.set(pl, pt, pr, pb)
        paint.style = Paint.Style.FILL
        paint.color = cc(0xF2121820)
        c.drawRoundRect(rf, 10f * d, 10f * d, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f * d
        paint.color = withA(gold, 0.8f)
        c.drawRoundRect(rf, 10f * d, 10f * d, paint)
        txt(c, sl.who, pl + 16f * d, pt + 26f * d, 16f * d, gold)
        val shown = min(sl.text.length, (g.cutT / 0.03f).toInt())
        val size = 15f * d
        val maxChars = ((pr - pl - 32f * d) / (size * 0.52f)).toInt().coerceAtLeast(20)
        val lines = wrap(sl.text.substring(0, shown), maxChars)
        var ly = pt + 52f * d
        for (ln in lines) {
            txt(c, ln, pl + 16f * d, ly, size, white)
            ly += 20f * d
        }
        if (shown >= sl.text.length) {
            val pulse = 0.5f + 0.5f * sin(g.cutT * 5f)
            val last = g.cutIdx >= g.cut.size - 1
            txt(c, if (last) "Toque para começar" else "Toque para continuar", pr - 16f * d, pb - 12f * d, 12f * d, withA(white, pulse), Paint.Align.RIGHT)
        }
    }

    private fun drawObjective(c: Canvas, wf: Float, hf: Float) {
        val p = g.player
        val l = 240f * d
        val r = wf - 158f * d
        if (r - l < 120f * d) return
        val done = g.objIdx >= g.objs.size
        val o = if (done) null else g.objs[g.objIdx]
        val txtMain = if (o == null) "Siga para o portal!" else o.text
        val prog = if (o != null && o.kind != 0) " (" + min(g.objProgress(o), o.need) + "/" + o.need + ")" else ""
        val maxChars = ((r - l - 16f * d) / (11f * d * 0.52f)).toInt().coerceAtLeast(16)
        val lines = wrap(txtMain + prog, maxChars)
        val hh = 20f * d + lines.size * 14f * d
        fr(c, l, 10f * d, r, 10f * d + hh, cc(0x99000000))
        txt(c, "OBJETIVO ${min(g.objIdx + 1, g.objs.size)}/${g.objs.size}", l + 8f * d, 22f * d, 9f * d, gold)
        var ly = 36f * d
        for (ln in lines) {
            txt(c, ln, l + 8f * d, ly, 11f * d, white)
            ly += 14f * d
        }
        // seta de direcao
        var tx = 0f
        var ty = 0f
        var has = false
        if (o != null && o.hx > 40f) {
            tx = o.hx
            ty = o.hy
            has = true
        } else if (o == null && g.exitOpen) {
            tx = g.exitX
            ty = g.exitY
            has = true
        }
        if (has) {
            val dist = hypot(tx - p.x, ty - p.y)
            if (dist > 5f * Game.T) {
                val px = projX(p.x, p.y)
                val py = projY(p.x, p.y, 0f)
                val ddx = projX(tx, ty) - px
                val ddy = projY(tx, ty, 0f) - py
                val dl = max(1f, hypot(ddx, ddy))
                val ux = ddx / dl
                val uy = ddy / dl
                val ax = px + ux * 56f * d
                val ay = py + uy * 56f * d - 14f * d
                path.reset()
                path.moveTo(ax + ux * 10f * d, ay + uy * 10f * d)
                path.lineTo(ax - ux * 6f * d - uy * 7f * d, ay - uy * 6f * d + ux * 7f * d)
                path.lineTo(ax - ux * 6f * d + uy * 7f * d, ay - uy * 6f * d - ux * 7f * d)
                path.close()
                paint.style = Paint.Style.FILL
                paint.color = withA(gold, 0.9f)
                c.drawPath(path, paint)
            }
        }
    }

    // ------------------------------------------------------------------ HUD

    private fun drawBtn(c: Canvas, b: Btn, label: String, col: Int, frac: Float, sub: String?) {
        circle(c, b.cx, b.cy, b.r, withA(col, 0.45f))
        if (frac > 0f) {
            paint.style = Paint.Style.FILL
            paint.color = cc(0x99000000)
            rf.set(b.cx - b.r, b.cy - b.r, b.cx + b.r, b.cy + b.r)
            c.drawArc(rf, -90f, 360f * frac.coerceIn(0f, 1f), true, paint)
        }
        circle(c, b.cx, b.cy, b.r, withA(white, 0.6f), 2 * d)
        val size = if (b.r > 40 * d) 15 * d else 11 * d
        txt(c, label, b.cx, b.cy + size * 0.35f, size, white, Paint.Align.CENTER)
        if (sub != null) {
            txt(c, sub, b.cx + b.r * 0.62f, b.cy - b.r * 0.5f, 12 * d, gold, Paint.Align.CENTER)
        }
    }

    private fun drawHud(c: Canvas, w: Int, h: Int) {
        val p = g.player
        val wf = w.toFloat()
        val hf = h.toFloat()

        val bx = 12 * d
        val by = 12 * d
        val bw = 170 * d
        fr(c, bx - 2 * d, by - 2 * d, bx + bw + 2 * d, by + 26 * d, cc(0x99000000))
        fr(c, bx, by, bx + bw * (p.hp / p.maxHp).coerceIn(0f, 1f), by + 14 * d, cc(0xFFE53935))
        txt(c, "${p.hp.toInt().coerceAtLeast(0)}/${p.maxHp.toInt()}", bx + 6 * d, by + 11.5f * d, 11 * d, white)
        fr(c, bx, by + 17 * d, bx + bw * (p.xp.toFloat() / p.xpNeed()).coerceIn(0f, 1f), by + 23 * d, cc(0xFF42A5F5))
        txt(c, "Nv ${p.level}", bx + bw + 10 * d, by + 14 * d, 14 * d, gold)
        txt(c, "Gemas ${p.gems}   Poções ${p.potions}   Flechas ${p.arrows}", bx, by + 42 * d, 11 * d, white)
        val wl = p.weapon.name + (if (p.weapon.affix > 0) " - " + p.weapon.affixName else "")
        txt(c, wl, bx, by + 57 * d, 11 * d, p.weapon.rarity.color)

        if (!g.inCamp) drawObjective(c, wf, hf)
        if (g.keys[0] + g.keys[1] + g.keys[2] > 0) {
            val kc = intArrayOf(cc(0xFFE53935), cc(0xFF42A5F5), cc(0xFFFFC107))
            var kx = bx
            for (k in 0 until 3) {
                if (g.keys[k] <= 0) continue
                circle(c, kx + 7 * d, by + 76 * d, 6 * d, kc[k])
                circle(c, kx + 7 * d, by + 76 * d, 6 * d, white, 1.5f * d)
                txt(c, "x" + g.keys[k], kx + 16 * d, by + 80 * d, 11 * d, white)
                kx += 40 * d
            }
        }
        if (g.bannerT > 0f) {
            val a = min(1f, g.bannerT)
            txt(c, g.banner, wf / 2f + 2 * d, hf * 0.22f + 2 * d, 22 * d, withA(cc(0xFF000000), a), Paint.Align.CENTER)
            txt(c, g.banner, wf / 2f, hf * 0.22f, 22 * d, withA(white, a), Paint.Align.CENTER)
        }

        val bs = g.boss
        if (bs != null && !bs.dead && bs.aggro) {
            val bwid = min(300 * d, wf * 0.35f)
            val l = wf / 2f - bwid / 2f
            val t = hf - 26 * d
            fr(c, l - 2 * d, t - 2 * d, l + bwid + 2 * d, t + 12 * d, cc(0xAA000000))
            fr(c, l, t, l + bwid * (bs.hp / bs.maxHp).coerceIn(0f, 1f), t + 10 * d, cc(0xFF8E24AA))
            txt(c, bs.type.label, wf / 2f, t - 5 * d, 11 * d, white, Paint.Align.CENTER)
        }

        // minimapa
        if (g.seenDirty) {
            g.seenDirty = false
            for (i in miniPix.indices) {
                miniPix[i] = if (!g.seen[i]) 0 else when (g.map[i].toInt()) {
                    Game.T_LAVA -> cc(0xCCFF5722)
                    0 -> cc(0x55222222)
                    Game.T_WATER -> cc(0xCC3A86D0)
                    Game.T_SAND -> cc(0xCCE6D29A)
                    Game.T_GRASS -> cc(0xCC72B456)
                    Game.T_PLANK -> cc(0xCCA67C4E)
                    else -> cc(0xCCB0BEC5)
                }
            }
            miniBmp.setPixels(miniPix, 0, Game.MW, 0, 0, Game.MW, Game.MH)
        }
        val ms = 84 * d
        val mr = wf - 56 * d - 8 * d
        val mt = 12 * d
        mrect.set(mr - ms, mt, mr, mt + ms)
        fr(c, mrect.left, mrect.top, mrect.right, mrect.bottom, cc(0x88000000))
        c.save()
        c.clipRect(mrect)
        c.translate(mrect.centerX(), mrect.centerY())
        c.rotate(deg(yaw))
        val unit = ms * 2f / 56f
        val pxm = (p.x / Game.T) * unit
        val pym = (p.y / Game.T) * unit
        c.translate(-pxm, -pym)
        rf.set(0f, 0f, unit * Game.MW, unit * Game.MH)
        c.drawBitmap(miniBmp, null, rf, bmpPaint)
        for (dr in g.doors) {
            if (dr.open || dr.kind == 5 || !g.seen[dr.ty * Game.MW + dr.tx]) continue
            val dc = when (dr.kind) {
                0 -> cc(0xFFE53935)
                1 -> cc(0xFF42A5F5)
                2 -> cc(0xFFFFC107)
                else -> cc(0xFFBCAAA4)
            }
            fr(c, dr.tx * unit, dr.ty * unit, dr.tx * unit + 3 * d, dr.ty * unit + 3 * d, dc)
        }
        val ob = if (g.objIdx < g.objs.size) g.objs[g.objIdx] else null
        if (ob != null && ob.hx > 40f) {
            val hx = ob.hx / Game.T * unit
            val hy = ob.hy / Game.T * unit
            fr(c, hx - 3 * d, hy - 3 * d, hx + 3 * d, hy + 3 * d, gold)
        }
        if (g.exitOpen && g.seen[idx(g.exitX, g.exitY)]) {
            val ex = (g.exitX / Game.T) * unit
            val ey = (g.exitY / Game.T) * unit
            fr(c, ex - 2 * d, ey - 2 * d, ex + 2 * d, ey + 2 * d, cc(0xFFB388FF))
        }
        c.restore()
        fr(c, mrect.centerX() - 2 * d, mrect.centerY() - 2 * d, mrect.centerX() + 2 * d, mrect.centerY() + 2 * d, white)

        if (g.state != State.PLAY) return

        drawBtn(c, bInv, "INV", cc(0xFF455A64), 0f, null)
        val nr = g.near
        if (nr != null) {
            val lab = when (nr.kind) {
                0 -> "Loja / mochila"
                1 -> "Abrir mapa-múndi"
                2 -> "Descansar"
                4 -> "Puxar"
                5 -> "Acender"
                6 -> "Ler"
                else -> "Afiar arma"
            }
            drawBtn(c, bAct, "AGIR", cc(0xFFF9A825), 0f, null)
            txt(c, nr.name + ": " + lab, bAct.cx, bAct.cy - bAct.r - 8 * d, 11 * d, gold, Paint.Align.CENTER)
        }
        drawBtn(c, bRotL, "<", cc(0xFF546E7A), 0f, null)
        drawBtn(c, bRotR, ">", cc(0xFF546E7A), 0f, null)
        val acd = p.weapon.wtype?.cooldown ?: 0.35f
        drawBtn(c, bAtk, "ATQ", cc(0xFFD32F2F), p.atkCd / acd, null)
        drawBtn(c, bRoll, "ROL", cc(0xFF1976D2), p.rollCd / 0.8f, null)
        drawBtn(c, bBow, "ARC", cc(0xFF6D4C41), if (p.arrows <= 0) 1f else p.bowCd / 0.45f, "${p.arrows}")
        drawBtn(c, bPot, "POC", cc(0xFF388E3C), if (p.potions <= 0 || p.hp >= p.maxHp) 1f else 0f, "${p.potions}")

        if (joyPtr != -1) {
            circle(c, joyBX, joyBY, 48 * d, withA(white, 0.12f))
            circle(c, joyBX, joyBY, 48 * d, withA(white, 0.35f), 2 * d)
            circle(c, joyX, joyY, 22 * d, withA(white, 0.45f))
        } else {
            circle(c, 90 * d, hf - 90 * d, 48 * d, withA(white, 0.10f), 2 * d)
        }
    }

    // ------------------------------------------------------------------ telas sobrepostas

    private fun drawSimpleBtn(c: Canvas, r: RectF, label: String, enabled: Boolean) {
        paint.style = Paint.Style.FILL
        paint.color = if (enabled) cc(0xFF2E7D32) else cc(0xFF3A3F3A)
        c.drawRoundRect(r, 6 * d, 6 * d, paint)
        txt(c, label, r.centerX(), r.centerY() + 4.5f * d, 13 * d, if (enabled) white else cc(0xFF78807A), Paint.Align.CENTER)
    }

    private fun drawInventory(c: Canvas, w: Int, h: Int) {
        val p = g.player
        fr(c, 0f, 0f, w.toFloat(), h.toFloat(), cc(0xAA000000))
        paint.style = Paint.Style.FILL
        paint.color = cc(0xF01B1F1B)
        c.drawRoundRect(invPanel, 10 * d, 10 * d, paint)
        txt(c, "Mochila", invPanel.left + 12 * d, invPanel.top + 30 * d, 20 * d, white)

        val lx = invPanel.left + 12 * d
        var ly = invPanel.top + 54 * d
        txt(c, "Arma equipada", lx, ly, 10 * d, grey)
        ly += 14 * d
        txt(c, p.weapon.name, lx, ly, 13 * d, p.weapon.rarity.color)
        ly += 14 * d
        txt(c, p.weapon.stat, lx, ly, 11 * d, white)
        if (p.weapon.affix > 0) {
            ly += 13 * d
            txt(c, p.weapon.affixName, lx, ly, 11 * d, gold)
        }
        ly += 20 * d
        txt(c, "Armadura", lx, ly, 10 * d, grey)
        ly += 14 * d
        val ar = p.armor
        if (ar != null) {
            txt(c, ar.name, lx, ly, 13 * d, ar.rarity.color)
            ly += 14 * d
            txt(c, ar.stat, lx, ly, 11 * d, white)
        } else {
            txt(c, "Nenhuma", lx, ly, 13 * d, grey)
            ly += 14 * d
        }
        ly += 18 * d
        txt(c, "Nível ${p.level}   Vida ${p.hp.toInt()}/${p.maxHp.toInt()}", lx, ly, 11 * d, white)
        ly += 15 * d
        txt(c, "Gemas ${p.gems}   Poções ${p.potions}/5", lx, ly, 11 * d, white)

        val bag = p.bag
        val valid = sel >= 0 && sel < bag.size
        drawSimpleBtn(c, invEquip, "Equipar", valid)
        drawSimpleBtn(c, invSell, if (valid) "Vender ${bag[sel].sellPrice}" else "Vender", valid)
        drawSimpleBtn(c, invBuy, if (g.inCamp) "Poção (30 gemas)" else "Poção: só no acampamento", g.inCamp && p.gems >= 30 && p.potions < 5)
        drawSimpleBtn(c, invMyst, if (g.inCamp) "Arma misteriosa (60)" else "Loja: só no acampamento", g.inCamp && p.gems >= 60 && bag.size < 12)
        drawSimpleBtn(c, invClose, "Continuar", true)

        txt(c, "Itens (${bag.size}/12)", cards[0].left, invPanel.top + 30 * d, 13 * d, grey)
        for (i in 0 until 12) {
            val r = cards[i]
            paint.style = Paint.Style.FILL
            if (i < bag.size) {
                val it = bag[i]
                paint.color = if (i == sel) cc(0xFF34403A) else cc(0xFF262B26)
                c.drawRoundRect(r, 6 * d, 6 * d, paint)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = if (i == sel) 3 * d else 1.5f * d
                paint.color = it.rarity.color
                c.drawRoundRect(r, 6 * d, 6 * d, paint)
                txt(c, it.title, r.left + 8 * d, r.top + 17 * d, 13 * d, it.rarity.color)
                txt(c, it.suffix, r.left + 8 * d, r.top + 31 * d, 11 * d, white)
                txt(c, it.stat, r.left + 8 * d, r.top + 44 * d, 10 * d, grey)
                if (it.affix > 0) txt(c, it.affixName, r.left + 8 * d, r.top + 57 * d, 10 * d, gold)
            } else {
                paint.color = cc(0xFF1F231F)
                c.drawRoundRect(r, 6 * d, 6 * d, paint)
            }
        }
    }

    private fun drawEnd(c: Canvas, w: Int, h: Int, win: Boolean) {
        val p = g.player
        val wf = w.toFloat()
        val hf = h.toFloat()
        fr(c, 0f, 0f, wf, hf, cc(0xAA000000))
        txt(
            c, if (win) "VITÓRIA!" else "VOCÊ CAIU!", wf / 2f, hf * 0.34f, 44 * d,
            if (win) gold else cc(0xFFEF5350), Paint.Align.CENTER
        )
        txt(
            c, "Missão ${g.mission + 1}   Nível ${p.level}   Gemas ${p.gems}   Inimigos ${p.kills}",
            wf / 2f, hf * 0.5f, 15 * d, white, Paint.Align.CENTER
        )
        if (g.stateT > 0.8f) {
            val pulse = 0.55f + 0.45f * sin(g.stateT * 3f)
            txt(c, "Toque para voltar ao acampamento", wf / 2f, hf * 0.68f, 18 * d, withA(white, pulse), Paint.Align.CENTER)
        }
    }
}
