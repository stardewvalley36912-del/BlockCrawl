package com.example.blockcrawl

import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

enum class State { MENU, PLAY, INV, DEAD, WIN }

enum class Rarity(val label: String, val color: Int, val mult: Float) {
    COMMON("Comum", 0xFFB8B8B8.toInt(), 1f),
    RARE("Raro", 0xFF4FA3FF.toInt(), 1.4f),
    UNIQUE("Único", 0xFFFFB02E.toInt(), 1.9f)
}

enum class WeaponType(
    val label: String,
    val baseDmg: Float,
    val range: Float,
    val halfArc: Float,
    val cooldown: Float,
    val knock: Float = 120f,
    val slam: Boolean = false,
    val ranged: Boolean = false
) {
    SWORD("Espada", 10f, 40f, 1.0f, 0.35f),
    AXE("Machado", 17f, 44f, 1.4f, 0.65f, 170f),
    SPEAR("Lança", 9f, 66f, 0.4f, 0.45f),
    DAGGER("Adaga", 6f, 30f, 0.9f, 0.18f, 60f),
    HAMMER("Martelo", 26f, 46f, 3.2f, 1.0f, 260f, slam = true),
    RAPIER("Rapieira", 7f, 62f, 0.28f, 0.22f, 50f),
    SCYTHE("Foice", 13f, 54f, 1.9f, 0.55f, 120f),
    CLAYMORE("Montante", 21f, 52f, 1.1f, 0.85f, 190f),
    HALBERD("Alabarda", 15f, 68f, 0.8f, 0.6f, 150f),
    MACE("Maça", 14f, 38f, 1.2f, 0.5f, 220f),
    STAFF("Cajado", 11f, 200f, 0.0f, 0.5f, 90f, ranged = true)
}

enum class EType(
    val label: String,
    val hp: Float,
    val speed: Float,
    val dmg: Float,
    val radius: Float,
    val xp: Int,
    val color: Int
) {
    MOSS("Mossling", 32f, 42f, 8f, 9f, 12, 0xFF4E7D3A.toInt()),
    ARCHER("Arqueiro de Lasca", 22f, 38f, 7f, 8f, 14, 0xFFD8D4C4.toInt()),
    GLOOP("Gloop", 16f, 88f, 6f, 7f, 8, 0xFF3FBFA0.toInt()),
    BOSS("Guardião de Obsidiana", 420f, 48f, 16f, 18f, 150, 0xFF54406E.toInt())
}

class Item(
    val wtype: WeaponType?,
    val title: String,
    val suffix: String,
    val rarity: Rarity,
    val value: Float,
    val affix: Int = 0
) {
    val isWeapon: Boolean get() = wtype != null
    /** 0 nenhum, 1 vampirico, 2 afiado, 3 flamejante */
    val affixName: String
        get() = when (affix) {
            1 -> "Vampírico"
            2 -> "Afiado"
            3 -> "Flamejante"
            else -> ""
        }
    val name: String get() = "$title $suffix"
    val sellPrice: Int
        get() = when (rarity) {
            Rarity.COMMON -> 6
            Rarity.RARE -> 18
            Rarity.UNIQUE -> 45
        }
    val stat: String
        get() {
            val w = wtype
            return if (w != null) "Dano ${value.toInt()}  Alc ${w.range.toInt()}" else "Defesa ${value.toInt()}"
        }
}

class Player {
    var x = 0f
    var y = 0f
    var hp = 100f
    var maxHp = 100f
    var level = 1
    var xp = 0
    var gems = 0
    var potions = 2
    var arrows = 8
    var kills = 0
    var facing = 0f
    var atkCd = 0f
    var atkAnim = 0f
    var atkDur = 0.2f
    var swingSign = 1f
    var rollCd = 0f
    var rolling = 0f
    var rdx = 0f
    var rdy = 0f
    var bowCd = 0f
    var arrowT = 0f
    var invuln = 0f
    var hurt = 0f
    var moving = false
    var weapon = Item(WeaponType.SWORD, "Espada", "de Madeira", Rarity.COMMON, 10f)
    var armor: Item? = null
    val bag = ArrayList<Item>()
    fun xpNeed(): Int = 30 + 20 * level
}

class Enemy(val type: EType, var x: Float, var y: Float, hpMult: Float, dmgMult: Float) {
    val maxHp = type.hp * hpMult
    var hp = maxHp
    val dmg = type.dmg * dmgMult
    var kx = 0f
    var ky = 0f
    var cd = 0.6f
    var contactCd = 0f
    var st = 0
    var stT = 0f
    var dx = 0f
    var dy = 0f
    var flash = 0f
    var anim = 0f
    var aggro = false
    var dead = false
    var summoned = false
    var hitDone = false
    var burn = 0f
    var burnTick = 0f
    var stun = 0f
}

class Projectile(
    var x: Float,
    var y: Float,
    val vx: Float,
    val vy: Float,
    val dmg: Float,
    val fromPlayer: Boolean,
    var life: Float,
    val radius: Float,
    val color: Int,
    /** 0 flecha do jogador, 1 flecha inimiga, 2 orbe magico, 3 orbe do chefe */
    val kind: Int = 0,
    var pierce: Int = 0
) {
    var lastHit: Enemy? = null
}

/** kind: 0 gema, 1 pocao, 2 flechas, 3 item */
class Pickup(var x: Float, var y: Float, val kind: Int, val amount: Int = 1, val item: Item? = null) {
    var t = 0f
    var dead = false
}

class Chest(val x: Float, val y: Float) {
    var opened = false
}

class FloatText(var x: Float, var y: Float, var z: Float, val text: String, val color: Int, var life: Float)

class Particle(
    var x: Float,
    var y: Float,
    var z: Float,
    var vx: Float,
    var vy: Float,
    var vz: Float,
    var life: Float,
    val color: Int,
    val size: Float
)

class Game {
    companion object {
        const val T = 32f
        const val MW = 56
        const val MH = 56
        const val MAX_LEVEL = 3
        val THEME_NAMES = arrayOf("Catacumbas Musgosas", "Forja Sombria", "Santuário de Obsidiana")
        private val PI_F = PI.toFloat()
        private val SUFFIX_COMMON = arrayOf("de Madeira", "de Pedra", "de Ferro Velho", "de Bronze")
        private val SUFFIX_RARE = arrayOf("de Cristal", "de Jade", "de Ferro Frio", "da Lua Pálida")
        private val SUFFIX_UNIQUE = arrayOf("do Abismo", "da Tempestade", "do Rei Esquecido", "das Brasas")
        private val ARMOR_TITLES = arrayOf("Couraça", "Manto", "Armadura")
    }

    val rng = Random()
    var state = State.MENU
    var map = IntArray(MW * MH)
    var seen = BooleanArray(MW * MH)
    var seenDirty = true
    var player = Player()
    val enemies = ArrayList<Enemy>()
    val projs = ArrayList<Projectile>()
    val pickups = ArrayList<Pickup>()
    val chests = ArrayList<Chest>()
    val texts = ArrayList<FloatText>()
    val parts = ArrayList<Particle>()
    var level = 1
    var exitX = 0f
    var exitY = 0f
    var exitOpen = true
    var time = 0f
    var shake = 0f
    var banner = ""
    var bannerT = 0f
    var moveX = 0f
    var moveY = 0f
    var attackHeld = false
    var stateT = 0f
    var boss: Enemy? = null

    private var ox = 0f
    private var oy = 0f
    private var lastTx = -1
    private var lastTy = -1

    // ------------------------------------------------------------------ fluxo

    fun startRun() {
        player = Player()
        level = 1
        moveX = 0f
        moveY = 0f
        attackHeld = false
        genLevel()
        state = State.PLAY
        stateT = 0f
    }

    fun toMenu() {
        state = State.MENU
        stateT = 0f
    }

    fun openInventory() {
        if (state == State.PLAY) {
            state = State.INV
            attackHeld = false
            moveX = 0f
            moveY = 0f
            stateT = 0f
        }
    }

    fun closeInventory() {
        if (state == State.INV) state = State.PLAY
    }

    // ------------------------------------------------------------------ mapa

    fun solid(tx: Int, ty: Int): Boolean =
        tx < 0 || ty < 0 || tx >= MW || ty >= MH || map[ty * MW + tx] == 0

    fun blocked(x: Float, y: Float, r: Float): Boolean {
        val x0 = floor((x - r) / T).toInt()
        val x1 = floor((x + r) / T).toInt()
        val y0 = floor((y - r) / T).toInt()
        val y1 = floor((y + r) / T).toInt()
        for (ty in y0..y1) {
            for (tx in x0..x1) {
                if (solid(tx, ty)) return true
            }
        }
        return false
    }

    private fun moveBy(x: Float, y: Float, dx: Float, dy: Float, r: Float) {
        var nx = x + dx
        if (blocked(nx, y, r)) nx = x
        var ny = y + dy
        if (blocked(nx, ny, r)) ny = y
        ox = nx
        oy = ny
    }

    private fun cxOf(r: IntArray): Float = (r[0] + r[2] / 2) * T + T / 2
    private fun cyOf(r: IntArray): Float = (r[1] + r[3] / 2) * T + T / 2

    private fun tryAddRoom(rooms: ArrayList<IntArray>, w: Int, h: Int): Boolean {
        val x = 2 + rng.nextInt(MW - w - 4)
        val y = 2 + rng.nextInt(MH - h - 4)
        for (r in rooms) {
            if (x < r[0] + r[2] + 2 && x + w + 2 > r[0] && y < r[1] + r[3] + 2 && y + h + 2 > r[1]) return false
        }
        rooms.add(intArrayOf(x, y, w, h))
        return true
    }

    private fun placeRooms(): ArrayList<IntArray> {
        val rooms = ArrayList<IntArray>()
        val bossLevel = level == MAX_LEVEL
        if (bossLevel) {
            var ok = false
            var k = 0
            while (!ok && k < 100) {
                k++
                ok = tryAddRoom(rooms, 14, 12)
            }
            if (!ok) return rooms
        }
        val target = 5 + level * 2
        var tries = 0
        while (rooms.size < target && tries < 500) {
            tries++
            tryAddRoom(rooms, 6 + rng.nextInt(7), 6 + rng.nextInt(6))
        }
        if (bossLevel && rooms.isNotEmpty()) {
            val b = rooms.removeAt(0)
            rooms.add(b)
        }
        return rooms
    }

    private fun carve(x: Int, y: Int) {
        if (x in 1 until MW - 1 && y in 1 until MH - 1) map[y * MW + x] = 1
    }

    private fun setWall(x: Int, y: Int) {
        if (x in 0 until MW && y in 0 until MH) map[y * MW + x] = 0
    }

    private fun carveRoom(r: IntArray) {
        for (ty in r[1] until r[1] + r[3]) {
            for (tx in r[0] until r[0] + r[2]) {
                map[ty * MW + tx] = 1
            }
        }
    }

    private fun carveCorridor(a: IntArray, b: IntArray) {
        var x = a[0] + a[2] / 2
        var y = a[1] + a[3] / 2
        val tx = b[0] + b[2] / 2
        val ty = b[1] + b[3] / 2
        while (x != tx) {
            carve(x, y)
            carve(x, y + 1)
            x += if (tx > x) 1 else -1
        }
        while (y != ty) {
            carve(x, y)
            carve(x + 1, y)
            y += if (ty > y) 1 else -1
        }
        carve(x, y)
        carve(x + 1, y)
        carve(x, y + 1)
        carve(x + 1, y + 1)
    }

    private fun randomType(): EType {
        val f = rng.nextFloat()
        return when {
            f < 0.45f -> EType.MOSS
            f < 0.75f -> EType.GLOOP
            else -> EType.ARCHER
        }
    }

    private fun spawnEnemy(r: IntArray, t: EType, hpM: Float, dmM: Float) {
        for (k in 0 until 20) {
            val tx = r[0] + 1 + rng.nextInt(max(1, r[2] - 2))
            val ty = r[1] + 1 + rng.nextInt(max(1, r[3] - 2))
            if (solid(tx, ty)) continue
            val e = Enemy(t, tx * T + T / 2, ty * T + T / 2, hpM, dmM)
            e.cd = 0.5f + rng.nextFloat()
            enemies.add(e)
            return
        }
    }

    private fun spawnChest(r: IntArray) {
        for (k in 0 until 20) {
            val tx = r[0] + 1 + rng.nextInt(max(1, r[2] - 2))
            val ty = r[1] + 1 + rng.nextInt(max(1, r[3] - 2))
            if (solid(tx, ty)) continue
            chests.add(Chest(tx * T + T / 2, ty * T + T / 2))
            return
        }
    }

    private fun genLevel() {
        var rooms: ArrayList<IntArray>
        do {
            rooms = placeRooms()
        } while (rooms.size < 4)

        map = IntArray(MW * MH)
        seen = BooleanArray(MW * MH)
        seenDirty = true
        lastTx = -1
        lastTy = -1
        enemies.clear()
        projs.clear()
        pickups.clear()
        chests.clear()
        texts.clear()
        parts.clear()
        boss = null

        for (r in rooms) carveRoom(r)
        for (i in 0 until rooms.size - 1) carveCorridor(rooms[i], rooms[i + 1])
        for (i in 1 until rooms.size) {
            val r = rooms[i]
            if (r[2] >= 9 && r[3] >= 8) {
                setWall(r[0] + 2, r[1] + 2)
                setWall(r[0] + r[2] - 3, r[1] + 2)
                setWall(r[0] + 2, r[1] + r[3] - 3)
                setWall(r[0] + r[2] - 3, r[1] + r[3] - 3)
            }
        }

        val last = rooms.size - 1
        val hpM = 1f + 0.4f * (level - 1)
        val dmM = 1f + 0.25f * (level - 1)
        val sr = rooms[0]
        val p = player
        p.x = cxOf(sr)
        p.y = cyOf(sr)
        val lr = rooms[last]
        exitX = cxOf(lr)
        exitY = cyOf(lr)
        exitOpen = level != MAX_LEVEL

        for (i in 1..last) {
            val r = rooms[i]
            if (i == last && level == MAX_LEVEL) {
                val b = Enemy(EType.BOSS, exitX, exitY, hpM, dmM)
                enemies.add(b)
                boss = b
                continue
            }
            val n = 2 + level + rng.nextInt(3) + (if (i == last) 2 else 0)
            for (k in 0 until n) spawnEnemy(r, randomType(), hpM, dmM)
            if (i == last || rng.nextFloat() < 0.5f) spawnChest(r)
        }
        if (rng.nextFloat() < 0.4f) spawnChest(sr)

        banner = "Fase $level - ${THEME_NAMES[level - 1]}"
        bannerT = 3f
        updateSeen()
    }

    // ------------------------------------------------------------------ itens

    private fun genItem(forced: Rarity? = null, bonus: Float = 0f): Item {
        val roll = rng.nextFloat() - bonus
        val rarity = forced ?: when {
            roll < 0.05f -> Rarity.UNIQUE
            roll < 0.30f -> Rarity.RARE
            else -> Rarity.COMMON
        }
        val suffixes = when (rarity) {
            Rarity.COMMON -> SUFFIX_COMMON
            Rarity.RARE -> SUFFIX_RARE
            Rarity.UNIQUE -> SUFFIX_UNIQUE
        }
        val suffix = suffixes[rng.nextInt(suffixes.size)]
        return if (rng.nextFloat() < 0.75f) {
            val types = WeaponType.values()
            val t = types[rng.nextInt(types.size)]
            val dmg = t.baseDmg * rarity.mult * (1f + 0.12f * (level - 1)) * (0.9f + rng.nextFloat() * 0.2f)
            val affix = when (rarity) {
                Rarity.COMMON -> 0
                Rarity.RARE -> if (rng.nextBoolean()) 1 + rng.nextInt(3) else 0
                Rarity.UNIQUE -> 1 + rng.nextInt(3)
            }
            Item(t, t.label, suffix, rarity, dmg, affix)
        } else {
            val title = ARMOR_TITLES[rng.nextInt(ARMOR_TITLES.size)]
            val v = (2f + level * 1.2f) * rarity.mult * (0.9f + rng.nextFloat() * 0.2f)
            Item(null, title, suffix, rarity, v)
        }
    }

    fun equip(i: Int) {
        val p = player
        if (i < 0 || i >= p.bag.size) return
        val item = p.bag[i]
        if (item.isWeapon) {
            val old = p.weapon
            p.weapon = item
            p.bag[i] = old
        } else {
            val old = p.armor
            p.armor = item
            if (old != null) p.bag[i] = old else p.bag.removeAt(i)
        }
    }

    fun sell(i: Int) {
        val p = player
        if (i < 0 || i >= p.bag.size) return
        p.gems += p.bag[i].sellPrice
        p.bag.removeAt(i)
    }

    fun buyPotion() {
        val p = player
        if (p.gems >= 30 && p.potions < 5) {
            p.gems -= 30
            p.potions++
        }
    }

    // ------------------------------------------------------------------ acoes do jogador

    fun doRoll() {
        val p = player
        if (state != State.PLAY || p.rollCd > 0f || p.rolling > 0f) return
        val len = hypot(moveX, moveY)
        if (len > 0.12f) {
            p.rdx = moveX / len
            p.rdy = moveY / len
        } else {
            p.rdx = cos(p.facing)
            p.rdy = sin(p.facing)
        }
        p.rolling = 0.26f
        p.rollCd = 0.8f
        p.invuln = 0.3f
    }

    fun shootBow() {
        val p = player
        if (state != State.PLAY || p.bowCd > 0f || p.arrows <= 0 || p.rolling > 0f) return
        val t = nearest(p.x, p.y, 280f)
        if (t != null) p.facing = atan2(t.y - p.y, t.x - p.x)
        val dmg = (9f + p.weapon.value * 0.3f) * (1f + 0.08f * (p.level - 1))
        projs.add(
            Projectile(
                p.x, p.y, cos(p.facing) * 270f, sin(p.facing) * 270f,
                dmg, true, 1.1f, 3f, 0xFFFFE082.toInt(), 0
            )
        )
        p.arrows--
        p.bowCd = 0.45f
    }

    fun usePotion() {
        val p = player
        if (state != State.PLAY || p.potions <= 0 || p.hp >= p.maxHp) return
        p.potions--
        val heal = p.maxHp * 0.45f
        p.hp = min(p.maxHp, p.hp + heal)
        addText(p.x, p.y, "+${heal.toInt()}", 0xFF69F0AE.toInt())
        burst(p.x, p.y, 0xFF69F0AE.toInt(), 10)
    }

    private fun nearest(x: Float, y: Float, range: Float): Enemy? {
        var best: Enemy? = null
        var bd = range
        for (e in enemies) {
            if (e.dead) continue
            val d = hypot(e.x - x, e.y - y)
            if (d < bd) {
                bd = d
                best = e
            }
        }
        return best
    }

    private fun angDiff(a: Float, b: Float): Float {
        var d = a - b
        while (d > PI_F) d -= 2f * PI_F
        while (d < -PI_F) d += 2f * PI_F
        return d
    }

    private fun doAttack() {
        val p = player
        val w = p.weapon.wtype ?: return
        val aff = p.weapon.affix
        val tgt = nearest(p.x, p.y, if (w.ranged) 260f else w.range * 2.4f + 20f)
        if (tgt != null) p.facing = atan2(tgt.y - p.y, tgt.x - p.x)
        p.atkCd = w.cooldown
        p.atkDur = if (w.slam) 0.34f else min(0.24f, w.cooldown * 0.85f)
        p.atkAnim = p.atkDur
        p.swingSign = -p.swingSign
        val base = p.weapon.value * (1f + 0.08f * (p.level - 1))
        if (w.ranged) {
            val dmg = base * (0.9f + rng.nextFloat() * 0.2f)
            projs.add(
                Projectile(
                    p.x, p.y, cos(p.facing) * 230f, sin(p.facing) * 230f,
                    dmg, true, 1.0f, 4f, 0xFFCE93D8.toInt(), 2, 1
                )
            )
            return
        }
        var hits = 0
        for (e in enemies) {
            if (e.dead) continue
            val dx = e.x - p.x
            val dy = e.y - p.y
            val d = hypot(dx, dy)
            if (d > w.range + e.type.radius) continue
            val ang = atan2(dy, dx)
            if (w.slam || abs(angDiff(ang, p.facing)) <= w.halfArc || d < e.type.radius + 8f) {
                val critChance = 0.12f + (if (aff == 2) 0.25f else 0f)
                val crit = rng.nextFloat() < critChance
                val dmg = base * (0.9f + rng.nextFloat() * 0.2f) * (if (crit) 1.8f else 1f)
                hitEnemy(e, dmg, ang, w.knock, crit)
                if (aff == 1) p.hp = min(p.maxHp, p.hp + dmg * 0.07f)
                if (aff == 3 && !e.dead) e.burn = 3f
                if (w.slam && !e.dead && e.type != EType.BOSS) e.stun = 0.9f
                hits++
            }
        }
        if (w.slam) {
            ring(p.x, p.y, w.range, 0xFFD7CCC8.toInt())
            shake = max(shake, 0.18f)
        }
        if (hits > 0) shake = max(shake, 0.06f)
    }

    // ------------------------------------------------------------------ dano e efeitos

    fun addText(x: Float, y: Float, s: String, color: Int) {
        texts.add(FloatText(x, y, 26f, s, color, 0.9f))
    }

    private fun burst(x: Float, y: Float, color: Int, n: Int, z: Float = 10f) {
        for (k in 0 until n) {
            val a = rng.nextFloat() * 2f * PI_F
            val s = 30f + rng.nextFloat() * 70f
            parts.add(
                Particle(
                    x, y, z, cos(a) * s, sin(a) * s, 50f + rng.nextFloat() * 90f,
                    0.45f + rng.nextFloat() * 0.35f, color, 2f + rng.nextFloat() * 2f
                )
            )
        }
    }

    private fun ring(x: Float, y: Float, radius: Float, color: Int) {
        for (k in 0 until 24) {
            val a = k * 2f * PI_F / 24f
            parts.add(
                Particle(
                    x + cos(a) * radius * 0.4f, y + sin(a) * radius * 0.4f, 2f,
                    cos(a) * radius * 1.6f, sin(a) * radius * 1.6f, 20f, 0.4f, color, 3f
                )
            )
        }
    }

    private fun hitEnemy(e: Enemy, dmg: Float, ang: Float, kb: Float, crit: Boolean) {
        e.hp -= dmg
        e.flash = 0.12f
        val k = if (e.type == EType.BOSS) kb * 0.1f else kb
        e.kx += cos(ang) * k
        e.ky += sin(ang) * k
        addText(e.x, e.y, dmg.toInt().toString() + (if (crit) "!" else ""), if (crit) 0xFFFFD54F.toInt() else 0xFFFFFFFF.toInt())
        burst(e.x, e.y, 0xFFFFE08A.toInt(), 4)
        if (e.hp <= 0f && !e.dead) killEnemy(e)
    }

    private fun hurtPlayer(dmg: Float) {
        val p = player
        if (p.invuln > 0f || p.rolling > 0f || state != State.PLAY) return
        val def = p.armor?.value ?: 0f
        val dd = max(1f, dmg * (1f - min(0.65f, def * 0.05f))).toInt().coerceAtLeast(1)
        p.hp -= dd.toFloat()
        p.invuln = 0.55f
        p.hurt = 0.25f
        shake = max(shake, 0.15f)
        addText(p.x, p.y, "-$dd", 0xFFFF5252.toInt())
        burst(p.x, p.y, 0xFFE53935.toInt(), 6)
    }

    private fun drop(x: Float, y: Float, kind: Int, amount: Int = 1, item: Item? = null) {
        pickups.add(Pickup(x + (rng.nextFloat() - 0.5f) * 22f, y + (rng.nextFloat() - 0.5f) * 22f, kind, amount, item))
    }

    private fun killEnemy(e: Enemy) {
        e.dead = true
        player.kills++
        addXp(e.type.xp)
        burst(e.x, e.y, e.type.color, 14)
        val gems = 1 + rng.nextInt(3)
        for (k in 0 until gems) drop(e.x, e.y, 0, 1 + level / 2)
        if (rng.nextFloat() < 0.12f) drop(e.x, e.y, 1)
        if (rng.nextFloat() < 0.25f) drop(e.x, e.y, 2, 4)
        if (rng.nextFloat() < 0.10f) drop(e.x, e.y, 3, 1, genItem())
        if (e.type == EType.BOSS) {
            for (k in 0 until 10) drop(e.x, e.y, 0, 3)
            drop(e.x, e.y, 3, 1, genItem(Rarity.UNIQUE))
            drop(e.x, e.y, 3, 1, genItem(Rarity.UNIQUE))
            drop(e.x, e.y, 1)
            exitOpen = true
            banner = "O portal se abriu!"
            bannerT = 3.5f
            shake = 0.5f
            // marca projeteis hostis para sumir (a remocao acontece no fim de updateProjectiles)
            for (q in projs) {
                if (!q.fromPlayer) q.life = -1f
            }
        }
    }

    private fun addXp(n: Int) {
        val p = player
        p.xp += n
        while (p.xp >= p.xpNeed()) {
            p.xp -= p.xpNeed()
            p.level++
            p.maxHp += 10f
            p.hp = min(p.maxHp, p.hp + p.maxHp * 0.4f)
            addText(p.x, p.y, "Nível ${p.level}!", 0xFFFFD54F.toInt())
            burst(p.x, p.y, 0xFFFFD54F.toInt(), 16)
        }
    }

    // ------------------------------------------------------------------ update

    fun update(dt: Float) {
        stateT += dt
        if (state != State.PLAY) return
        time += dt
        if (shake > 0f) shake -= dt
        if (bannerT > 0f) bannerT -= dt
        updatePlayer(dt)
        updateEnemies(dt)
        updateProjectiles(dt)
        updatePickups(dt)
        updateChests()
        updateFx(dt)
        updateSeen()
        checkExit()
        if (player.hp <= 0f && state == State.PLAY) {
            state = State.DEAD
            stateT = 0f
            attackHeld = false
            moveX = 0f
            moveY = 0f
        }
    }

    private fun updatePlayer(dt: Float) {
        val p = player
        p.atkCd -= dt
        p.rollCd -= dt
        p.bowCd -= dt
        p.invuln -= dt
        p.atkAnim -= dt
        p.hurt -= dt
        p.arrowT += dt
        if (p.arrowT >= 2.5f) {
            p.arrowT = 0f
            if (p.arrows < 12) p.arrows++
        }
        p.moving = false
        if (p.rolling > 0f) {
            p.rolling -= dt
            moveBy(p.x, p.y, p.rdx * 270f * dt, p.rdy * 270f * dt, 6f)
            p.x = ox
            p.y = oy
        } else {
            val len = hypot(moveX, moveY)
            if (len > 0.12f) {
                val k = min(len, 1f)
                moveBy(p.x, p.y, moveX / len * k * 95f * dt, moveY / len * k * 95f * dt, 6f)
                p.x = ox
                p.y = oy
                p.facing = atan2(moveY, moveX)
                p.moving = true
            }
            if (attackHeld && p.atkCd <= 0f) doAttack()
        }
    }

    private fun step(e: Enemy, dx: Float, dy: Float, speed: Float, dt: Float) {
        moveBy(e.x, e.y, dx * speed * dt, dy * speed * dt, e.type.radius)
        e.x = ox
        e.y = oy
    }

    private fun updateEnemies(dt: Float) {
        val p = player
        val n = enemies.size
        for (i in 0 until n) {
            val e = enemies[i]
            if (e.dead) continue
            e.anim += dt
            e.cd -= dt
            e.contactCd -= dt
            e.flash -= dt
            if (e.burn > 0f) {
                e.burn -= dt
                e.burnTick -= dt
                if (e.burnTick <= 0f) {
                    e.burnTick = 0.5f
                    hitEnemy(e, 2f + player.weapon.value * 0.12f, 0f, 0f, false)
                    if (e.dead) continue
                }
            }
            if (e.stun > 0f) {
                e.stun -= dt
                if (abs(e.kx) > 1f || abs(e.ky) > 1f) {
                    moveBy(e.x, e.y, e.kx * dt, e.ky * dt, e.type.radius)
                    e.x = ox
                    e.y = oy
                    val f0 = max(0f, 1f - 9f * dt)
                    e.kx *= f0
                    e.ky *= f0
                }
                continue
            }
            if (abs(e.kx) > 1f || abs(e.ky) > 1f) {
                moveBy(e.x, e.y, e.kx * dt, e.ky * dt, e.type.radius)
                e.x = ox
                e.y = oy
                val f = max(0f, 1f - 9f * dt)
                e.kx *= f
                e.ky *= f
            }
            val ddx = p.x - e.x
            val ddy = p.y - e.y
            val dist = max(0.001f, sqrt(ddx * ddx + ddy * ddy))
            val nx = ddx / dist
            val ny = ddy / dist
            if (!e.aggro) {
                val range = if (e.type == EType.BOSS) 230f else 170f
                if (dist < range) e.aggro = true else continue
            }
            when (e.type) {
                EType.MOSS -> mossAI(e, dt, dist, nx, ny)
                EType.GLOOP -> gloopAI(e, dt, dist, nx, ny)
                EType.ARCHER -> archerAI(e, dt, dist, nx, ny)
                EType.BOSS -> bossAI(e, dt, dist, nx, ny)
            }
            for (j in i + 1 until n) {
                val o = enemies[j]
                if (o.dead) continue
                val sx = o.x - e.x
                val sy = o.y - e.y
                val sd = hypot(sx, sy)
                val minD = e.type.radius + o.type.radius - 2f
                if (sd < minD && sd > 0.001f) {
                    val push = (minD - sd) * 0.5f
                    moveBy(o.x, o.y, sx / sd * push, sy / sd * push, o.type.radius)
                    o.x = ox
                    o.y = oy
                    moveBy(e.x, e.y, -sx / sd * push, -sy / sd * push, e.type.radius)
                    e.x = ox
                    e.y = oy
                }
            }
        }
        enemies.removeAll { it.dead }
    }

    private fun mossAI(e: Enemy, dt: Float, dist: Float, nx: Float, ny: Float) {
        when (e.st) {
            0 -> {
                if (dist > 22f) step(e, nx, ny, e.type.speed, dt)
                if (dist < 30f && e.cd <= 0f) {
                    e.st = 1
                    e.stT = 0.45f
                }
            }
            1 -> {
                e.stT -= dt
                if (e.stT <= 0f) {
                    if (dist < 38f) hurtPlayer(e.dmg)
                    e.st = 0
                    e.cd = 1.1f
                }
            }
        }
    }

    private fun gloopAI(e: Enemy, dt: Float, dist: Float, nx: Float, ny: Float) {
        val sp = e.type.speed * (0.65f + 0.45f * (0.5f + 0.5f * sin(e.anim * 6f)))
        step(e, nx, ny, sp, dt)
        if (dist < e.type.radius + 9f && e.contactCd <= 0f) {
            hurtPlayer(e.dmg)
            e.contactCd = 0.9f
            e.kx = -nx * 140f
            e.ky = -ny * 140f
        }
    }

    private fun archerAI(e: Enemy, dt: Float, dist: Float, nx: Float, ny: Float) {
        when (e.st) {
            0 -> {
                if (dist < 75f) step(e, -nx, -ny, e.type.speed, dt)
                else if (dist > 140f) step(e, nx, ny, e.type.speed, dt)
                if (dist < 190f && e.cd <= 0f) {
                    e.st = 1
                    e.stT = 0.4f
                }
            }
            1 -> {
                e.stT -= dt
                if (e.stT <= 0f) {
                    projs.add(Projectile(e.x, e.y, nx * 135f, ny * 135f, e.dmg, false, 3f, 4f, 0xFFFFF59D.toInt(), 1))
                    e.st = 0
                    e.cd = 1.6f + rng.nextFloat() * 0.6f
                }
            }
        }
    }

    private fun bossAI(e: Enemy, dt: Float, dist: Float, nx: Float, ny: Float) {
        if (!e.summoned && e.hp < e.maxHp * 0.5f) {
            e.summoned = true
            for (k in 0 until 2) {
                val sx = e.x + (if (k == 0) -34f else 34f)
                if (!blocked(sx, e.y, 7f)) {
                    val g = Enemy(EType.GLOOP, sx, e.y, 1f + 0.4f * (level - 1), 1f + 0.25f * (level - 1))
                    g.aggro = true
                    enemies.add(g)
                }
            }
            addText(e.x, e.y, "Reforços!", 0xFFFF6E6E.toInt())
        }
        val enraged = e.hp < e.maxHp * 0.3f
        when (e.st) {
            0 -> {
                if (dist > 30f) step(e, nx, ny, e.type.speed * (if (enraged) 1.4f else 1f), dt)
                if (dist < e.type.radius + 12f && e.contactCd <= 0f) {
                    hurtPlayer(e.dmg * 0.6f)
                    e.contactCd = 1f
                }
                if (e.cd <= 0f) {
                    e.dx = nx
                    e.dy = ny
                    if (dist > 120f || rng.nextBoolean()) {
                        e.st = 1
                        e.stT = 0.8f
                    } else {
                        e.st = 4
                        e.stT = 0.7f
                    }
                }
            }
            1 -> {
                e.stT -= dt
                if (e.stT > 0.35f) {
                    e.dx = nx
                    e.dy = ny
                }
                if (e.stT <= 0f) {
                    e.st = 2
                    e.stT = 0.6f
                    e.hitDone = false
                }
            }
            2 -> {
                e.stT -= dt
                val bx = e.x
                val by = e.y
                moveBy(e.x, e.y, e.dx * 240f * dt, e.dy * 240f * dt, e.type.radius)
                val moved = abs(ox - bx) + abs(oy - by)
                e.x = ox
                e.y = oy
                if (dist < e.type.radius + 10f && !e.hitDone) {
                    hurtPlayer(e.dmg * 1.2f)
                    e.hitDone = true
                }
                if (e.stT <= 0f || moved < 0.5f) {
                    e.st = 3
                    e.stT = 0.9f
                    shake = max(shake, 0.25f)
                }
            }
            3 -> {
                e.stT -= dt
                if (e.stT <= 0f) {
                    e.st = 0
                    e.cd = if (enraged) 1.0f else 1.6f
                }
            }
            4 -> {
                e.stT -= dt
                if (e.stT <= 0f) {
                    val count = 16
                    val off = rng.nextFloat() * 2f * PI_F
                    for (k in 0 until count) {
                        val a = off + k * 2f * PI_F / count
                        projs.add(Projectile(e.x, e.y, cos(a) * 100f, sin(a) * 100f, e.dmg * 0.6f, false, 3.5f, 5f, 0xFFFF8A65.toInt(), 3))
                    }
                    shake = max(shake, 0.2f)
                    e.st = 3
                    e.stT = 0.6f
                }
            }
        }
    }

    private fun updateProjectiles(dt: Float) {
        val p = player
        for (pr in projs) {
            pr.x += pr.vx * dt
            pr.y += pr.vy * dt
            pr.life -= dt
            if (pr.life <= 0f || blocked(pr.x, pr.y, 1f)) {
                pr.life = -1f
                continue
            }
            if (pr.fromPlayer) {
                for (e in enemies) {
                    if (e.dead || e === pr.lastHit) continue
                    if (hypot(e.x - pr.x, e.y - pr.y) < pr.radius + e.type.radius) {
                        hitEnemy(e, pr.dmg, atan2(pr.vy, pr.vx), 120f, false)
                        if (pr.pierce > 0) {
                            pr.pierce--
                            pr.lastHit = e
                        } else {
                            pr.life = -1f
                        }
                        break
                    }
                }
            } else if (p.rolling <= 0f && hypot(p.x - pr.x, p.y - pr.y) < pr.radius + 7f) {
                hurtPlayer(pr.dmg)
                pr.life = -1f
            }
        }
        projs.removeAll { it.life <= 0f }
    }

    private fun collect(pk: Pickup) {
        val p = player
        when (pk.kind) {
            0 -> {
                p.gems += pk.amount
                addText(pk.x, pk.y, "+${pk.amount}", 0xFF3DDC84.toInt())
            }
            1 -> {
                if (p.potions < 5) {
                    p.potions++
                    addText(pk.x, pk.y, "+Poção", 0xFFFF6B6B.toInt())
                } else {
                    p.gems += 10
                    addText(pk.x, pk.y, "+10", 0xFF3DDC84.toInt())
                }
            }
            2 -> {
                p.arrows = min(20, p.arrows + pk.amount)
                addText(pk.x, pk.y, "+${pk.amount} flechas", 0xFFFFE082.toInt())
            }
            3 -> {
                val item = pk.item ?: return
                if (p.bag.size < 12) {
                    p.bag.add(item)
                    addText(pk.x, pk.y, item.name, item.rarity.color)
                } else {
                    p.gems += item.sellPrice
                    addText(pk.x, pk.y, "Mochila cheia +${item.sellPrice}", 0xFFFFD54F.toInt())
                }
            }
        }
    }

    private fun updatePickups(dt: Float) {
        val p = player
        for (pk in pickups) {
            pk.t += dt
            val dx = p.x - pk.x
            val dy = p.y - pk.y
            val d = max(0.001f, hypot(dx, dy))
            if (pk.t > 0.3f && d < 60f) {
                pk.x += dx / d * 140f * dt
                pk.y += dy / d * 140f * dt
            }
            if (pk.t > 0.3f && d < 14f) {
                pk.dead = true
                collect(pk)
            }
        }
        pickups.removeAll { it.dead }
    }

    private fun updateChests() {
        val p = player
        for (c in chests) {
            if (!c.opened && hypot(p.x - c.x, p.y - c.y) < 24f) openChest(c)
        }
    }

    private fun openChest(c: Chest) {
        c.opened = true
        val gems = 3 + rng.nextInt(4)
        for (k in 0 until gems) drop(c.x, c.y, 0, 1 + level / 2)
        if (rng.nextFloat() < 0.75f) drop(c.x, c.y, 3, 1, genItem(null, 0.12f))
        if (rng.nextFloat() < 0.3f) drop(c.x, c.y, 1)
        if (rng.nextFloat() < 0.4f) drop(c.x, c.y, 2, 5)
        addText(c.x, c.y, "Baú!", 0xFFFFD54F.toInt())
        burst(c.x, c.y, 0xFFFFD54F.toInt(), 10)
    }

    private fun updateFx(dt: Float) {
        for (t in texts) {
            t.z += 22f * dt
            t.life -= dt
        }
        texts.removeAll { it.life <= 0f }
        for (q in parts) {
            q.x += q.vx * dt
            q.y += q.vy * dt
            q.z += q.vz * dt
            q.vz -= 300f * dt
            if (q.z < 0f) {
                q.z = 0f
                q.vz *= -0.3f
            }
            q.vx *= 0.92f
            q.vy *= 0.92f
            q.life -= dt
        }
        parts.removeAll { it.life <= 0f }
    }

    private fun updateSeen() {
        val tx = floor(player.x / T).toInt()
        val ty = floor(player.y / T).toInt()
        if (tx == lastTx && ty == lastTy) return
        lastTx = tx
        lastTy = ty
        val r = 8
        for (dy in -r..r) {
            for (dx in -r..r) {
                if (dx * dx + dy * dy > r * r + 4) continue
                val x = tx + dx
                val y = ty + dy
                if (x < 0 || y < 0 || x >= MW || y >= MH) continue
                val i = y * MW + x
                if (!seen[i]) {
                    seen[i] = true
                    seenDirty = true
                }
            }
        }
    }

    private fun checkExit() {
        val p = player
        if (exitOpen && hypot(p.x - exitX, p.y - exitY) < 20f) {
            if (level >= MAX_LEVEL) {
                state = State.WIN
                stateT = 0f
                attackHeld = false
                moveX = 0f
                moveY = 0f
            } else {
                level++
                p.hp = min(p.maxHp, p.hp + p.maxHp * 0.3f)
                genLevel()
                p.invuln = 1f
            }
        }
    }
}
