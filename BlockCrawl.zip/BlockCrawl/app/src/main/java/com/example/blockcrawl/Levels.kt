package com.example.blockcrawl

import kotlin.math.max
import kotlin.math.min

// Geradores das quatro missoes. Cada uma tem desenho proprio, puzzles proprios e um chefe.

private const val WL = Game.T_WALL
private const val ST = Game.T_STONE
private const val SA = Game.T_SAND
private const val WT = Game.T_WATER
private const val PK = Game.T_PLANK
private const val GR = Game.T_GRASS
private const val LV = Game.T_LAVA
private const val MWD = Game.MW

private fun Game.hm(): Float = 1f + 0.4f * (level - 1)
private fun Game.dm(): Float = 1f + 0.25f * (level - 1)

private fun Game.room(x: Int, y: Int, w: Int, h: Int, t: Int = ST) = fillT(x, y, x + w - 1, y + h - 1, t)

/** Corredor em L: horizontal primeiro, depois vertical. */
private fun Game.corr(x0: Int, y0: Int, x1: Int, y1: Int, t: Int = ST) {
    thickLine(x0, y0, x1, y0, 1, t)
    thickLine(x1, y0, x1, y1, 1, t)
}

/** Corredor em L: vertical primeiro, depois horizontal. */
private fun Game.corrV(x0: Int, y0: Int, x1: Int, y1: Int, t: Int = ST) {
    thickLine(x0, y0, x0, y1, 1, t)
    thickLine(x0, y1, x1, y1, 1, t)
}

private fun Game.pack(x0: Int, y0: Int, x1: Int, y1: Int, n: Int, vararg types: EType) {
    var c = 0
    var tries = 0
    val total = (n * 1.5f).toInt()
    while (c < total && tries < total * 40) {
        tries++
        val tx = x0 + rng.nextInt(max(1, x1 - x0 + 1))
        val ty = y0 + rng.nextInt(max(1, y1 - y0 + 1))
        if (tx !in 0 until MWD || ty !in 0 until Game.MH) continue
        if (solid(tx, ty) || map[ty * MWD + tx] == LV) continue
        spawnAt(tx, ty, types[rng.nextInt(types.size)], hm(), dm())
        c++
    }
}

private fun Game.decor(x0: Int, y0: Int, x1: Int, y1: Int, id: Int, n: Int, vararg ok: Int) {
    var c = 0
    var tries = 0
    while (c < n && tries < n * 30) {
        tries++
        val tx = x0 + rng.nextInt(max(1, x1 - x0 + 1))
        val ty = y0 + rng.nextInt(max(1, y1 - y0 + 1))
        if (tx !in 0 until MWD || ty !in 0 until Game.MH) continue
        val i = ty * MWD + tx
        if (deco[i] != 0 || map[i] !in ok) continue
        deco[i] = id
        c++
    }
}

private fun Game.addDoor(x: Int, y: Int, kind: Int, link: Int) {
    if (x !in 0 until MWD || y !in 0 until Game.MH) return
    if (map[y * MWD + x] == WL) return
    deco[y * MWD + x] = if (kind < 3) Game.D_DOOR0 + kind else Game.D_DOORL
    doors.add(Door(x, y, kind, link))
}

/** Portao de tres tiles. horiz = o corredor corre na horizontal (o portao se estende na vertical). */
private fun Game.gate(tx: Int, ty: Int, horiz: Boolean, kind: Int, link: Int) {
    for (k in -1..1) {
        if (horiz) addDoor(tx, ty + k, kind, link) else addDoor(tx + k, ty, kind, link)
    }
}

private fun Game.leverAt(tx: Int, ty: Int, link: Int) {
    deco[ty * MWD + tx] = Game.D_LEVER
    val sp = Spot(tx * Game.T + Game.T / 2, ty * Game.T + Game.T / 2, 4, "Alavanca", false)
    sp.link = link
    spots.add(sp)
}

private fun Game.brazierAt(tx: Int, ty: Int, link: Int, idx: Int, color: String) {
    deco[ty * MWD + tx] = Game.D_BRAZ
    val sp = Spot(tx * Game.T + Game.T / 2, ty * Game.T + Game.T / 2, 5, "Braseiro $color", false)
    sp.link = link
    sp.idx = idx
    sp.text = color
    spots.add(sp)
}

private fun Game.tabletAt(tx: Int, ty: Int, text: String) {
    deco[ty * MWD + tx] = Game.D_TABLET
    val sp = Spot(tx * Game.T + Game.T / 2, ty * Game.T + Game.T / 2, 6, "Tábua antiga", false)
    sp.text = text
    spots.add(sp)
}

private fun Game.plateAt(tx: Int, ty: Int, link: Int, hold: Float) {
    plates.add(Plate(tx, ty, link, hold))
}

private fun Game.keyAt(tx: Int, ty: Int, color: Int) {
    pickups.add(Pickup(tx * Game.T + Game.T / 2, ty * Game.T + Game.T / 2, 4, color))
}

private fun Game.obj(text: String, kind: Int, need: Int, hx: Int, hy: Int) {
    objs.add(Obj(text, kind, need, hx * Game.T + Game.T / 2, hy * Game.T + Game.T / 2))
}

private fun Game.arena(
    x: Int, y: Int, w: Int, h: Int, waves: Int, per: Int, types: Array<EType>,
    ent: Array<IntArray>, rx: Int, ry: Int
): Arena {
    val ar = Arena(x, y, x + w - 1, y + h - 1, waves, per, types)
    for (e in ent) {
        for (k in -1..1) {
            if (e[2] == 1) ar.doors.add(intArrayOf(e[0], e[1] + k)) else ar.doors.add(intArrayOf(e[0] + k, e[1]))
        }
    }
    ar.rewardX = rx
    ar.rewardY = ry
    arenas.add(ar)
    return ar
}

private fun Game.bossAt(tx: Int, ty: Int, t: EType) {
    val e = Enemy(t, tx * Game.T + Game.T / 2, ty * Game.T + Game.T / 2, hm(), dm())
    enemies.add(e)
    boss = e
    exitX = e.x
    exitY = e.y
}

private fun Game.start(tx: Int, ty: Int) {
    player.x = tx * Game.T + Game.T / 2
    player.y = ty * Game.T + Game.T / 2
}

private fun Game.pillars(r: IntArray) {
    if (r[2] >= 9 && r[3] >= 8) {
        for (p in arrayOf(
            intArrayOf(r[0] + 2, r[1] + 2), intArrayOf(r[0] + r[2] - 3, r[1] + 2),
            intArrayOf(r[0] + 2, r[1] + r[3] - 3), intArrayOf(r[0] + r[2] - 3, r[1] + r[3] - 3)
        )) {
            map[p[1] * MWD + p[0]] = WL
        }
    }
}

// ---------------------------------------------------------------------- ala de masmorra

private class Wing(val grid: Array<Array<IntArray>>)

private fun cx(r: IntArray) = r[0] + r[2] / 2
private fun cy(r: IntArray) = r[1] + r[3] / 2

private fun Game.wing(x0: Int, y0: Int, w: Int, h: Int, cols: Int, rows: Int, t: Int, minS: Int, maxS: Int): Wing {
    val cw = w / cols
    val ch = h / rows
    val grid = Array(rows) { r ->
        Array(cols) { c ->
            val rw = min(cw - 3, minS + rng.nextInt(maxS - minS + 1))
            val rh = min(ch - 3, minS + rng.nextInt(maxS - minS + 1))
            val rx = x0 + c * cw + 1 + rng.nextInt(max(1, cw - rw - 2))
            val ry = y0 + r * ch + 1 + rng.nextInt(max(1, ch - rh - 2))
            room(rx, ry, rw, rh, t)
            intArrayOf(rx, ry, rw, rh)
        }
    }
    for (r in 0 until rows) {
        for (c in 0 until cols - 1) corr(cx(grid[r][c]), cy(grid[r][c]), cx(grid[r][c + 1]), cy(grid[r][c + 1]), t)
    }
    for (r in 0 until rows - 1) {
        val c0 = if (r % 2 == 0) cols - 1 else 0
        corrV(cx(grid[r][c0]), cy(grid[r][c0]), cx(grid[r + 1][c0]), cy(grid[r + 1][c0]), t)
        for (c in 0 until cols) {
            if (c != c0 && rng.nextFloat() < 0.35f) {
                corrV(cx(grid[r][c]), cy(grid[r][c]), cx(grid[r + 1][c]), cy(grid[r + 1][c]), t)
            }
        }
    }
    return Wing(grid)
}

private fun Game.populate(wg: Wing, skipR: Int, skipC: Int, base: Int, vararg types: EType) {
    for (r in wg.grid.indices) {
        for (c in wg.grid[r].indices) {
            val rm = wg.grid[r][c]
            pillars(rm)
            if (r == skipR && c == skipC) continue
            pack(rm[0] + 1, rm[1] + 1, rm[0] + rm[2] - 2, rm[1] + rm[3] - 2, base + rng.nextInt(3), *types)
            if (rng.nextFloat() < 0.4f) chestAt(cx(rm) + 1, cy(rm) + 1)
        }
    }
}

// ---------------------------------------------------------------------- selecao

fun Game.genMission(i: Int) {
    when (i) {
        0 -> genCoastBig()
        1 -> genCatacombs()
        2 -> genForge()
        else -> genSanctum()
    }
    banner = Game.THEME_NAMES[i]
    bannerT = 3f
    lastSeenReset()
}

private fun Game.lastSeenReset() {
    updateSeen()
}

// ---------------------------------------------------------------------- missao 1: costa (tutorial)

private fun Game.genCoastBig() {
    themeIdx = 0
    fillT(0, 0, Game.MW - 1, Game.MH - 1, WT)
    fillEllipse(22f, 118f, 17f, 11f, SA)
    fillEllipse(18f, 116f, 8f, 5f, GR)
    fillEllipse(60f, 112f, 18f, 12f, SA)
    fillEllipse(104f, 112f, 18f, 11f, SA)
    fillEllipse(100f, 110f, 8f, 5f, GR)
    fillEllipse(112f, 76f, 16f, 12f, SA)
    fillEllipse(76f, 70f, 18f, 12f, SA)
    fillEllipse(72f, 68f, 9f, 5f, GR)
    fillEllipse(36f, 54f, 16f, 12f, SA)
    fillEllipse(76f, 22f, 22f, 14f, ST)

    corr(22, 118, 60, 112, PK)
    corr(60, 112, 104, 112, PK)
    corr(104, 112, 112, 76, PK)
    corr(112, 76, 76, 70, PK)
    corr(76, 70, 36, 54, PK)
    corr(36, 54, 76, 22, PK)

    // ruinas com a chave azul (porta temporizada)
    fillT(41, 49, 49, 57, WL)
    fillT(42, 50, 48, 56, ST)
    fillT(41, 53, 41, 53, ST)
    addDoor(41, 53, 3, 3)
    plateAt(24, 56, 3, 12f)
    plateAt(43, 53, 3, 12f)
    keyAt(46, 53, 1)

    // portoes
    gate(82, 112, true, 0, 100)
    gate(112, 95, false, 3, 1)
    gate(46, 70, true, 3, 2)
    gate(60, 54, true, 1, 101)

    leverAt(108, 106, 1)
    brazierAt(76, 60, 2, 1, "Verde")
    brazierAt(68, 64, 2, 2, "Azul")
    brazierAt(84, 64, 2, 3, "Vermelho")
    tabletAt(76, 78, "Tábua: acenda Verde, depois Azul, depois Vermelho")
    keyAt(66, 105, 0)

    arena(
        96, 64, 33, 25, 3, 5, arrayOf(EType.CRAB, EType.JELLY, EType.GLOOP),
        arrayOf(intArrayOf(112, 89, 0), intArrayOf(95, 76, 1)), 112, 70
    )

    // decoracao
    decor(6, 108, 38, 128, Game.D_PALM, 10, SA, GR)
    decor(44, 102, 76, 122, Game.D_PALM, 8, SA)
    decor(44, 102, 76, 122, Game.D_CRATE, 6, SA)
    decor(44, 102, 76, 122, Game.D_BARREL, 5, SA)
    decor(88, 102, 120, 122, Game.D_PALM, 8, SA, GR)
    decor(96, 64, 128, 88, Game.D_ROCK, 6, SA)
    decor(58, 58, 94, 82, Game.D_PALM, 6, SA, GR)
    decor(20, 44, 52, 64, Game.D_ROCK, 8, SA)
    decor(54, 8, 98, 36, Game.D_TORCH, 10, ST)
    deco[106 * MWD + 52] = Game.D_TENT
    deco[118 * MWD + 68] = Game.D_TENT
    deco[100 * MWD + 40] = 0

    // inimigos
    start(12, 118)
    pack(28, 114, 38, 122, 3, EType.CRAB)
    pack(40, 114, 48, 122, 2, EType.GLOOP)
    pack(46, 104, 74, 120, 8, EType.CRAB, EType.GLOOP, EType.ARCHER)
    pack(62, 102, 72, 108, 3, EType.CRAB)
    pack(84, 111, 100, 113, 3, EType.JELLY)
    pack(90, 102, 120, 122, 9, EType.CRAB, EType.JELLY, EType.ARCHER)
    pack(60, 58, 94, 82, 10, EType.CRAB, EType.ARCHER, EType.JELLY, EType.GLOOP)
    pack(48, 69, 58, 71, 3, EType.JELLY)
    pack(22, 46, 36, 62, 8, EType.CRAB, EType.GLOOP, EType.ARCHER)
    pack(62, 53, 76, 55, 3, EType.JELLY)
    pack(60, 12, 92, 32, 8, EType.CRAB, EType.JELLY, EType.ARCHER)

    chestAt(14, 122)
    chestAt(52, 116)
    chestAt(98, 118)
    chestAt(82, 76)
    chestAt(26, 48)
    chestAt(66, 18)

    bossAt(76, 20, EType.KCRAB)

    obj("Siga a praia para o leste (joystick esquerdo para andar)", 0, 0, 34, 118)
    obj("Derrote 3 inimigos com ATQ (a mira é automática)", 5, 3, 0, 0)
    obj("Chegue à vila dos pescadores", 0, 0, 60, 112)
    obj("Pegue a chave vermelha perto das cabanas (ROL desvia de golpes)", 1, 1, 66, 105)
    obj("Abra o portão do cais e chegue à praia de coral", 0, 0, 100, 112)
    obj("Puxe a alavanca da praia (botão AGIR) para baixar a ponte", 3, 1, 108, 106)
    obj("Cruze a ponte e vença a arena dos caranguejos", 2, 1, 112, 76)
    obj("Acenda os braseiros na ordem da tábua", 3, 2, 76, 70)
    obj("Pise na placa da ilha, corra até a ruína e pegue a chave azul", 1, 2, 24, 56)
    obj("Derrote o Rei Caranguejo", 4, 1, 76, 22)
}

// ---------------------------------------------------------------------- missao 2: catacumbas

private fun Game.genCatacombs() {
    themeIdx = 1
    val startRoom = intArrayOf(62, 126, 21, 14)
    room(62, 126, 21, 14)
    room(58, 58, 29, 29)
    thickLine(72, 126, 72, 86, 1, ST)

    val we = wing(106, 50, 36, 46, 3, 3, ST, 6, 9)
    val wn = wing(40, 4, 64, 40, 4, 2, ST, 7, 10)
    val ww = wing(4, 50, 42, 46, 3, 3, ST, 6, 9)

    // leste: arena no caminho
    room(90, 64, 15, 17)
    thickLine(86, 72, 90, 72, 1, ST)
    corr(105, 72, cx(we.grid[1][0]), cy(we.grid[1][0]))
    arena(
        90, 64, 15, 17, 2, 6, arrayOf(EType.MOSS, EType.GLOOP, EType.ARCHER),
        arrayOf(intArrayOf(89, 72, 1), intArrayOf(105, 72, 1)), 97, 66
    )
    // norte: gate vermelho
    corrV(72, 58, cx(wn.grid[1][2]), cy(wn.grid[1][2]))
    gate(72, 50, false, 0, 100)
    // oeste: gate azul
    corr(58, 72, cx(ww.grid[1][2]), cy(ww.grid[1][2]))
    gate(52, 72, true, 1, 101)
    // chefe: gate dourado
    room(100, 106, 38, 32)
    thickLine(82, 132, 100, 132, 1, ST)
    gate(90, 132, true, 2, 102)

    // cofre norte (alavanca)
    room(8, 8, 21, 17)
    val rN = wn.grid[0][0]
    corr(cx(rN), cy(rN), 18, 16)
    gate(34, cy(rN), true, 3, 5)
    val lr = wn.grid[1][3]
    leverAt(cx(lr), cy(lr) - 2, 5)
    keyAt(18, 16, 1)

    // cofre oeste (braseiros)
    room(8, 104, 21, 17)
    val rW = ww.grid[2][0]
    corrV(cx(rW), cy(rW), 18, 112)
    gate(cx(rW), 100, false, 3, 6)
    keyAt(18, 112, 2)
    brazierAt(cx(ww.grid[0][0]) + 2, cy(ww.grid[0][0]), 6, 1, "Azul")
    brazierAt(cx(ww.grid[0][2]) + 2, cy(ww.grid[0][2]), 6, 2, "Dourado")
    brazierAt(cx(ww.grid[2][1]) + 2, cy(ww.grid[2][1]), 6, 3, "Verde")
    brazierAt(cx(ww.grid[1][1]) + 2, cy(ww.grid[1][1]), 6, 4, "Vermelho")
    tabletAt(cx(ww.grid[2][2]) + 2, cy(ww.grid[2][2]), "Tábua: Azul, Dourado, Verde, Vermelho")

    // chave vermelha: sala final do leste, com placa extra para um bau
    val kE = we.grid[2][2]
    keyAt(cx(kE) + 1, cy(kE), 0)

    // conteudo
    pillars(startRoom)
    populate(we, 2, 2, 3, EType.MOSS, EType.GLOOP, EType.ARCHER)
    populate(wn, -1, -1, 3, EType.MOSS, EType.ARCHER, EType.GLOOP)
    populate(ww, -1, -1, 3, EType.MOSS, EType.GLOOP, EType.ARCHER)
    pack(60, 60, 84, 84, 14, EType.MOSS, EType.GLOOP, EType.ARCHER)
    pack(66, 92, 78, 122, 6, EType.MOSS, EType.GLOOP)
    pack(102, 108, 136, 136, 8, EType.MOSS, EType.ARCHER)
    pack(10, 10, 27, 23, 4, EType.GLOOP)
    pack(10, 106, 27, 119, 4, EType.GLOOP)
    chestAt(110, 112)
    chestAt(130, 130)
    chestAt(14, 12)
    chestAt(24, 116)
    for (p in arrayOf(intArrayOf(62, 62), intArrayOf(82, 62), intArrayOf(62, 82), intArrayOf(82, 82), intArrayOf(72, 66), intArrayOf(72, 78))) {
        map[p[1] * MWD + p[0]] = WL
    }
    map[72 * MWD + 72] = ST
    for (p in arrayOf(intArrayOf(104, 110), intArrayOf(133, 110), intArrayOf(104, 133), intArrayOf(133, 133))) {
        map[p[1] * MWD + p[0]] = WL
    }

    start(72, 134)
    bossAt(119, 122, EType.COLOSSUS)

    obj("Entre no salão central das catacumbas", 0, 0, 72, 72)
    obj("Vença a sala de provação do leste (ela se sela ao entrar)", 2, 1, 97, 72)
    obj("Pegue a chave vermelha no fundo da ala leste", 1, 1, cx(kE), cy(kE))
    obj("Abra o portão vermelho ao norte e puxe a alavanca da ala norte", 3, 1, cx(lr), cy(lr))
    obj("Pegue a chave azul no cofre do noroeste", 1, 2, 18, 16)
    obj("Abra o portão azul ao oeste e acenda os braseiros na ordem da tábua", 3, 2, 22, 88)
    obj("Pegue a chave dourada no cofre do sudoeste", 1, 3, 18, 112)
    obj("Abra o portão dourado e derrote o Colosso de Musgo", 4, 1, 119, 122)
}

// ---------------------------------------------------------------------- missao 3: forja

private fun Game.genForge() {
    themeIdx = 2
    // F1: inicio
    room(4, 112, 40, 28)
    fillEllipse(20f, 122f, 5f, 3f, LV)
    fillEllipse(34f, 131f, 4f, 3f, LV)
    // rio de lava com ponte que a alavanca cria
    fillT(4, 99, 43, 111, LV)
    for (y in 99..111) {
        for (x in 22..24) doors.add(Door(x, y, 5, 1))
    }
    // F2
    room(4, 66, 66, 33)
    for (p in arrayOf(intArrayOf(14, 72), intArrayOf(60, 72), intArrayOf(14, 92), intArrayOf(60, 92), intArrayOf(37, 82))) {
        fillT(p[0], p[1], p[0] + 1, p[1] + 1, WL)
    }
    thickLine(70, 82, 79, 82, 1, ST)
    gate(74, 82, true, 3, 2)
    plateAt(44, 88, 2, 12f)
    // F3: salao do magma
    room(78, 66, 56, 44)
    fillEllipse(106f, 92f, 17f, 9f, LV)
    fillT(104, 83, 108, 101, ST)
    fillT(89, 90, 123, 94, ST)
    // cripta dos fornos
    room(100, 114, 24, 20)
    thickLine(112, 110, 112, 114, 1, ST)
    gate(112, 112, false, 3, 3)
    brazierAt(84, 104, 3, 1, "Vermelho")
    brazierAt(84, 72, 3, 2, "Dourado")
    brazierAt(128, 72, 3, 3, "Azul")
    tabletAt(106, 70, "Tábua de ferro: Vermelho, Dourado, Azul")
    keyAt(112, 124, 1)
    // arena
    room(94, 40, 29, 19)
    thickLine(108, 65, 108, 59, 1, ST)
    gate(108, 62, false, 1, 101)
    arena(
        94, 40, 29, 19, 3, 6, arrayOf(EType.IMP, EType.ARCHER, EType.MOSS),
        arrayOf(intArrayOf(108, 59, 0), intArrayOf(108, 39, 0)), 0, 0
    )
    keyAt(108, 44, 0)
    // chefe
    room(84, 4, 48, 30)
    thickLine(108, 39, 108, 34, 1, ST)
    gate(108, 36, false, 0, 100)
    fillEllipse(108f, 18f, 18f, 10f, LV)
    fillT(106, 8, 110, 29, ST)
    fillT(90, 16, 126, 20, ST)
    fillT(104, 14, 112, 22, ST)

    leverAt(38, 118, 1)

    decor(8, 68, 68, 96, Game.D_ANVIL, 6, ST)
    decor(8, 68, 68, 96, Game.D_BARREL, 6, ST)
    decor(8, 114, 42, 138, Game.D_CRATE, 4, ST)
    decor(80, 68, 132, 108, Game.D_BARREL, 6, ST)
    decor(80, 68, 132, 108, Game.D_TORCH, 6, ST)
    for (k in 0 until 4) {
        decor(86, 6, 130, 32, Game.D_TORCH, 1, ST)
    }

    start(10, 126)
    pack(6, 114, 42, 138, 7, EType.IMP, EType.GLOOP)
    pack(6, 68, 68, 97, 28, EType.IMP, EType.ARCHER, EType.MOSS, EType.GLOOP)
    pack(80, 68, 132, 108, 32, EType.IMP, EType.ARCHER, EType.MOSS)
    pack(102, 116, 122, 132, 6, EType.IMP, EType.MOSS)
    pack(86, 6, 130, 32, 6, EType.IMP)
    chestAt(8, 136)
    chestAt(66, 70)
    chestAt(8, 70)
    chestAt(130, 104)
    chestAt(104, 128)
    chestAt(88, 28)

    bossAt(108, 18, EType.GOLEM)

    obj("Puxe a alavanca da forja (AGIR): a ponte sobre a lava surge", 3, 1, 38, 118)
    obj("Atravesse a ponte de pedra até o grande salão", 0, 0, 24, 82)
    obj("Pise na placa e corra até o portão de ferro antes que ele feche", 3, 2, 44, 88)
    obj("Entre no salão do magma", 0, 0, 100, 80)
    obj("Acenda os 3 fornos na ordem da tábua", 3, 3, 106, 76)
    obj("Pegue a chave azul na cripta de brasas", 1, 1, 112, 124)
    obj("Abra o portão azul e vença a sala de provação", 2, 1, 108, 50)
    obj("Pegue a chave vermelha da sala de provação", 1, 2, 108, 44)
    obj("Abra o portão vermelho e derrote o Golem da Forja", 4, 1, 108, 18)
}

// ---------------------------------------------------------------------- missao 4: santuario

private fun Game.genSanctum() {
    themeIdx = 3
    room(62, 128, 21, 12)
    thickLine(72, 128, 72, 100, 1, ST)
    fillEllipse(72f, 88f, 16f, 14f, ST)
    // chefe ao norte, atras de tres selos
    thickLine(72, 74, 72, 30, 1, ST)
    gate(72, 66, false, 0, 100)
    gate(72, 58, false, 1, 101)
    gate(72, 50, false, 2, 102)
    room(50, 4, 45, 26)
    // leste: arena
    thickLine(88, 88, 104, 88, 1, ST)
    room(104, 70, 35, 37)
    arena(
        104, 70, 35, 37, 3, 7, arrayOf(EType.WRAITH, EType.ARCHER, EType.IMP),
        arrayOf(intArrayOf(103, 88, 1)), 0, 0
    )
    keyAt(134, 100, 0)
    // oeste: braseiros
    thickLine(56, 88, 40, 88, 1, ST)
    room(6, 70, 34, 36)
    room(12, 56, 16, 10)
    thickLine(20, 66, 20, 69, 1, ST)
    gate(20, 67, false, 3, 6)
    brazierAt(10, 74, 6, 1, "Dourado")
    brazierAt(35, 74, 6, 2, "Azul")
    brazierAt(10, 101, 6, 3, "Vermelho")
    brazierAt(35, 101, 6, 4, "Verde")
    tabletAt(22, 88, "Tábua: Dourado, Azul, Vermelho, Verde")
    keyAt(20, 60, 1)
    // sudoeste: alavanca e placa
    thickLine(72, 118, 40, 118, 1, ST)
    room(6, 112, 34, 24)
    thickLine(40, 130, 44, 130, 1, ST)
    gate(42, 130, true, 3, 8)
    leverAt(10, 116, 8)
    room(44, 124, 15, 14)
    fillT(52, 124, 52, 137, WL)
    fillT(52, 129, 52, 131, ST)
    gate(52, 130, true, 3, 9)
    plateAt(45, 125, 9, 6f)
    keyAt(56, 130, 2)

    // decoracao
    for (a in 0 until 8) {
        val ang = a * 0.7853982f
        val px = 72 + (Math.cos(ang.toDouble()) * 10.0).toInt()
        val py = 88 + (Math.sin(ang.toDouble()) * 8.0).toInt()
        if (map[py * MWD + px] == ST && !(px == 72 && (py < 76 || py > 100))) deco[py * MWD + px] = Game.D_ROCK
    }
    decor(52, 6, 92, 28, Game.D_TORCH, 8, ST)
    decor(106, 72, 137, 105, Game.D_ROCK, 8, ST)
    decor(8, 72, 38, 104, Game.D_TORCH, 6, ST)

    start(72, 134)
    pack(58, 76, 86, 100, 12, EType.WRAITH, EType.ARCHER)
    pack(66, 104, 78, 126, 8, EType.WRAITH, EType.IMP)
    pack(8, 72, 38, 104, 18, EType.WRAITH, EType.ARCHER, EType.IMP, EType.MOSS)
    pack(8, 114, 38, 134, 14, EType.WRAITH, EType.IMP, EType.ARCHER)
    pack(46, 126, 51, 136, 3, EType.IMP)
    pack(68, 32, 76, 48, 8, EType.WRAITH, EType.ARCHER)
    pack(52, 6, 92, 28, 6, EType.WRAITH, EType.IMP)
    chestAt(136, 74)
    chestAt(8, 104)
    chestAt(8, 134)
    chestAt(20, 62)
    chestAt(56, 126)
    chestAt(72, 36)

    bossAt(72, 14, EType.BOSS)

    obj("Entre na rotunda do santuário", 0, 0, 72, 88)
    obj("Vença a provação do leste", 2, 1, 120, 88)
    obj("Pegue a chave vermelha no fundo da câmara leste", 1, 1, 134, 100)
    obj("Resolva o enigma dos braseiros da câmara oeste", 3, 1, 22, 88)
    obj("Pegue a chave azul no cofre do oeste", 1, 2, 20, 60)
    obj("Câmara sul: puxe a alavanca e use a placa temporizada", 3, 3, 10, 116)
    obj("Pegue a chave dourada no cofre do sul", 1, 3, 56, 130)
    obj("Abra os três selos e enfrente o Guardião de Obsidiana", 4, 1, 72, 14)
}

// ---------------------------------------------------------------------- historia

fun missionIntro(i: Int): List<Slide> = when (i) {
    0 -> listOf(
        Slide("Narrador", "Uma tempestade lançou seu navio contra os recifes da Costa das Marés. Você acorda sozinho na areia, com uma espada de madeira ao lado."),
        Slide("Narrador", "A costa é dominada pelo Rei Caranguejo, que cobra pedágio de tudo que a maré traz. Enquanto ele reinar, ninguém consegue montar um acampamento seguro aqui."),
        Slide("Objetivo", "Aprenda a lutar, abra o caminho pelas pontes e derrote o Rei Caranguejo. Depois disso o acampamento poderá ser erguido.")
    )
    1 -> listOf(
        Slide("Vigia", "Chefe, a água do acampamento ficou verde e fedorenta. O musgo vem das Catacumbas, debaixo da colina."),
        Slide("Narrador", "Um Colosso de Musgo despertou lá embaixo e espalha a praga. Portões selados guardam cada ala das catacumbas."),
        Slide("Objetivo", "Vença as provações, ache as chaves vermelha, azul e dourada e destrua o Colosso.")
    )
    2 -> listOf(
        Slide("Ferreiro", "A Forja Sombria foi abandonada com o fogo aceso. Um Golem de ferro tomou conta e queima tudo ao redor. Sem a forja, nada de armas novas."),
        Slide("Narrador", "Rios de lava cortam os salões. Pontes e portões só obedecem a alavancas, placas de pressão e aos fornos antigos."),
        Slide("Objetivo", "Atravesse a lava, acenda os fornos na ordem certa, pegue as duas chaves e derrote o Golem da Forja.")
    )
    else -> listOf(
        Slide("Narrador", "No Santuário de Obsidiana, o Guardião vigia um selo que prende a escuridão. Ele despertou e quer rompê-lo."),
        Slide("Vigia", "Três câmaras guardam as chaves dos três selos da porta do chefe. Cada uma tem seu próprio enigma."),
        Slide("Objetivo", "Reúna as chaves vermelha, azul e dourada, abra os selos e enfrente o Guardião de Obsidiana.")
    )
}

fun missionOutro(i: Int): List<Slide> = when (i) {
    0 -> listOf(
        Slide("Narrador", "O Rei Caranguejo caiu e a maré voltou a ser sua. Os sobreviventes saem dos recifes e se juntam a você na praia."),
        Slide("Mercador", "Salvei algumas mercadorias do naufrágio. Dá para montar uma loja aqui."),
        Slide("Ferreiro", "E eu acendo a bigorna. Traga gemas e eu afio a sua arma."),
        Slide("Narrador", "Nasce o acampamento. No mapa-múndi, uma nova missão se abre: as Catacumbas Musgosas.")
    )
    1 -> listOf(
        Slide("Narrador", "O Colosso desaba e o musgo seca. A água do acampamento volta a ficar limpa."),
        Slide("Ferreiro", "Esse calor vindo do leste... A velha Forja Sombria acordou. Precisamos dela de volta.")
    )
    2 -> listOf(
        Slide("Narrador", "O Golem se desfaz em brasas. A forja agora é de vocês."),
        Slide("Vigia", "Chefe, vimos uma luz roxa no horizonte. O Santuário de Obsidiana está acordando.")
    )
    else -> listOf(
        Slide("Narrador", "O Guardião tomba e o selo se fecha. A costa, a colina e a forja estão a salvo."),
        Slide("Narrador", "Sua lenda começa aqui.")
    )
}

fun bossIntro(i: Int): List<Slide> = when (i) {
    0 -> listOf(Slide("Rei Caranguejo", "Quem ousa atravessar meus recifes? Pague o pedágio... com a vida!"))
    1 -> listOf(Slide("Narrador", "O chão treme. O musgo se ergue em forma de gigante: o Colosso de Musgo."))
    2 -> listOf(Slide("Narrador", "Os olhos de brasa se acendem e o ferro range. O Golem da Forja avança."))
    else -> listOf(Slide("Guardião de Obsidiana", "Nenhum intruso passa dos selos. Volte ao pó."))
}
