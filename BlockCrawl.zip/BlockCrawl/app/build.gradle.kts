plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.blockcrawl"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.blockcrawl"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        // O jogo e 100% Kotlin/Canvas (sem bibliotecas nativas), entao roda em
        // aparelhos de 32 bits. O filtro abaixo garante que so ABI de 32 bits
        // (armeabi-v7a) seja empacotada caso alguma lib nativa seja adicionada no futuro.
        ndk {
            abiFilters += listOf("armeabi-v7a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
