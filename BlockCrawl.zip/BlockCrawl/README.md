# BlockCrawl

Dungeon crawler de blocos em 3D para Android, com câmera inclinada de cima (estilo isométrico).
Todo o código, nomes e visuais são originais (Kotlin + Canvas, sem engine e sem bibliotecas nativas).

## Como jogar

- **Lado esquerdo da tela**: joystick flutuante para mover (relativo à câmera)
- **Arrastar na metade direita da tela** ou botões **< >**: girar a câmera
- **ATQ**: ataca (mira automática no inimigo mais próximo)
- **ROL**: rolagem esquiva (invencível por um instante)
- **ARC**: atira uma flecha (recarrega com o tempo)
- **POC**: usa poção de vida
- **AGIR**: aparece perto de algo interativo no acampamento (mercador, ferreiro, fogueira, mapa-múndi)
- **INV**: mochila (equipar, vender; loja só no acampamento). Também funciona como pausa.

## Conteúdo

- Acampamento (hub) com mercador, ferreiro (melhora a arma), fogueira, boneco de treino e mapa-múndi
- Mapa-múndi com 4 missões que se desbloqueiam em ordem; o progresso é salvo no aparelho
- Costa das Marés: fase desenhada à mão (praia, cais, ilha do naufrágio, templo) com caranguejos e águas-vivas
- Outras missões geradas aleatoriamente; a última termina com o chefe Guardião de Obsidiana
- 11 tipos de arma: espada, machado, lança, adaga, martelo (golpe em área que atordoa), rapieira,
  foice, montante, alabarda, maça e cajado (dispara orbes mágicos que atravessam inimigos)
- Afixos nas armas raras e únicas: Vampírico (cura), Afiado (mais críticos) e Flamejante (queima)
- Raridades (Comum, Raro, Único), armaduras, baús, evolução de nível e minimapa que gira com a câmera

## 32 bits

O jogo é 100% Kotlin/Java, sem código nativo (.so). Por isso o APK roda em celulares
de 32 bits (armeabi-v7a) e também de 64 bits. `minSdk = 21` (Android 5.0 ou superior).

## Gerar o APK pelo celular (GitHub Actions)

1. No repositório do GitHub, envie o `BlockCrawl.zip` (sem extrair). Se já existir um com o mesmo
   nome, o novo substitui o antigo.
2. Crie o arquivo `.github/workflows/build.yml` com o workflow de build (uma vez só).
3. Cada envio do zip inicia a compilação sozinho. Abra a aba **Actions**, espere o check verde e
   baixe o artefato **BlockCrawl-APK** no fim da página da execução.
4. Extraia o zip do artefato e instale o `app-debug.apk`.

## Gerar o APK no PC

Abra esta pasta no Android Studio e use Build > Build APK(s), ou rode `gradle :app:assembleDebug`
(JDK 17 e Android SDK instalados). O arquivo fica em `app/build/outputs/apk/debug/`.
