# BlockCrawl

Dungeon crawler de blocos para Android, inspirado no estilo de jogos como Minecraft Dungeons.
Todo o código, nomes e visuais são originais (Kotlin + Canvas, sem engine e sem bibliotecas nativas).

## Como jogar

- **Lado esquerdo da tela**: joystick flutuante para mover
- **ATQ**: ataca (mira automática no inimigo mais próximo)
- **ROL**: rolagem esquiva (invencível por um instante)
- **ARC**: atira uma flecha (recarrega com o tempo)
- **POC**: usa poção de vida
- **INV**: abre a mochila (equipar, vender, comprar poção). Também funciona como pausa.

São 3 fases geradas aleatoriamente. A fase 3 termina com o chefe Guardião de Obsidiana.
Há loot com raridades (Comum, Raro, Único), 4 tipos de arma, armaduras, baús, evolução de nível e minimapa.

## 32 bits

O jogo é 100% Kotlin/Java, sem código nativo (.so). Por isso o APK roda em celulares
de 32 bits (armeabi-v7a) e também de 64 bits. `minSdk = 21` (Android 5.0 ou superior).

## Gerar o APK

### Opção A: pelo celular, com GitHub Actions (sem PC)

1. Crie uma conta gratuita no GitHub e um repositório novo.
2. Envie todos os arquivos desta pasta para o repositório (incluindo a pasta oculta `.github`).
3. Abra a aba **Actions**, escolha **Build APK** e toque em **Run workflow**.
4. Quando terminar (uns 3 a 6 minutos), abra a execução e baixe o artefato **BlockCrawl-debug-apk**.
5. Extraia o zip, abra o `app-debug.apk` no celular e permita "instalar de fontes desconhecidas".

### Opção B: Android Studio (PC)

1. Instale o Android Studio e abra esta pasta como projeto.
2. Aguarde a sincronização do Gradle.
3. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. O arquivo fica em `app/build/outputs/apk/debug/app-debug.apk`.

### Opção C: linha de comando

Com JDK 17 e Android SDK instalados (`ANDROID_HOME` configurado):

```
gradle :app:assembleDebug
```

## Aviso

Este código foi escrito sem poder compilar nem rodar em um aparelho. Se o build der erro ou algo
estiver estranho no jogo (balanceamento, controles), envie a mensagem de erro ou a descrição que eu corrijo.
