# BlockCrawl

Dungeon crawler de blocos em 3D para Android, com câmera inclinada de cima (estilo isométrico).
Todo o código, nomes e visuais são originais (Kotlin + Canvas, sem engine e sem bibliotecas nativas).

## Como jogar

- **Lado esquerdo da tela**: joystick flutuante para mover (relativo à câmera)
- **Arrastar na metade direita da tela** ou botões **< >**: girar a câmera
- **ATQ**: ataca (mira automática no inimigo mais próximo)
- **ROL**: rolagem esquiva (invencível por um instante)
- **ARC**: atira uma flecha (recarrega com o tempo)
- **POC**: usa poção de vida
- **AGIR**: aparece perto de algo interativo no acampamento (mercador, ferreiro, fogueira, mapa-múndi)
- **INV**: mochila (equipar, vender; loja só no acampamento). Também funciona como pausa.

## Conteúdo

- O jogo começa na **Costa das Marés** (tutorial). Só depois de derrotar o Rei Caranguejo o
  **acampamento** é montado (mercador, ferreiro, fogueira, boneco de treino, mapa-múndi)
- 4 missões grandes (mapas de 144x144 blocos), cada uma com cutscene de abertura, objetivos em etapas,
  seta de direção, cutscene do chefe e cutscene final:
  Costa das Marés (Rei Caranguejo), Catacumbas Musgosas (Colosso de Musgo),
  Forja Sombria (Golem da Forja) e Santuário de Obsidiana (Guardião de Obsidiana)
- Puzzles: portas com chaves coloridas, alavancas (inclusive ponte sobre lava), placas de pressão
  temporizadas, braseiros que precisam ser acesos na ordem da tábua e salas de arena com ondas
- Lava causa dano; a rolagem (ROL) deixa atravessar por instantes
- 11 tipos de arma, afixos (Vampírico, Afiado, Flamejante), raridades, baús e minimapa que gira
- Progresso salvo automaticamente no aparelho

## 32 bits

O jogo é 100% Kotlin/Java, sem código nativo (.so). Por isso o APK roda em celulares
de 32 bits (armeabi-v7a) e também de 64 bits. `minSdk = 21` (Android 5.0 ou superior).

## Gerar o APK pelo celular (GitHub Actions)

1. No repositório do GitHub, envie o `BlockCrawl.zip` (sem extrair). Se já existir um com o mesmo
   nome, o novo substitui o antigo.
2. Crie o arquivo `.github/workflows/build.yml` com o workflow de build (uma vez só).
3. Cada envio do zip inicia a compilação sozinho. Abra a aba **Actions**, espere o check verde e
   baixe o artefato **BlockCrawl-APK** no fim da página da execução.
4. Extraia o zip do artefato e instale o `app-debug.apk`.

## Gerar o APK no PC

Abra esta pasta no Android Studio e use Build > Build APK(s), ou rode `gradle :app:assembleDebug`
(JDK 17 e Android SDK instalados). O arquivo fica em `app/build/outputs/apk/debug/`.
